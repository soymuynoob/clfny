import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document, ObjectId, Types } from 'mongoose';

@Schema({ timestamps: true, versionKey: false, collection: 'employees' })
export class Employee extends Document {
  @Prop({ required: true, type: String, trim: true })
  Name: string;

  @Prop({ required: true, type: String, trim: true })
  LastName: string;

  @Prop({ required: true, type: String, trim: true })
  Email: string;

  @Prop({ required: true, type: String, trim: true })
  NumberPhone: string;

  @Prop({ required: true, type: Types.ObjectId, trim: true })
  BusinessID: ObjectId;

  @Prop({ required: true, type: Number, default: 0 })
  Balance: number;

  @Prop({ required: true, type: Boolean, default: false })
  IsArchived: boolean;
}
export const EmployeeSchema =
  SchemaFactory.createForClass(Employee);
