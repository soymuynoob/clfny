import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { MongooseModule } from '@nestjs/mongoose';
import { EmployeeUpdateModule } from './employee_update/employee_update.module';

@Module({
  imports: [
    MongooseModule.forRoot(
      'mongodb://root:kike123@localhost:27027/mic_employee?authSource=admin',
    ),
    EmployeeUpdateModule,


  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
