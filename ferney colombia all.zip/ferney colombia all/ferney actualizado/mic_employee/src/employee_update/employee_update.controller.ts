import { Controller, Body, Param, Put } from '@nestjs/common';
import { EmployeeUpdateService } from './employee_update.service';
import {
  EmployeeIDDto,
  UpdateEmployeeUpdateDto,
} from './dto/update-employee_update.dto';

@Controller()
export class EmployeeUpdateController {
  constructor(private readonly employeeUpdateService: EmployeeUpdateService) {}

  @Put('update/employee/:employeeID')
  update(
    @Param() params: EmployeeIDDto,
    @Body() props: UpdateEmployeeUpdateDto,
  ) {
    return this.employeeUpdateService.update({
      employeeID: params.employeeID,
      props,
    });
  }
}
