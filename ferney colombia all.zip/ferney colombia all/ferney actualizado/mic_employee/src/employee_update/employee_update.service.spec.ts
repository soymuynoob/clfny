import { Test, TestingModule } from '@nestjs/testing';
import { EmployeeUpdateService } from './employee_update.service';
import { getModelToken } from '@nestjs/mongoose';
import { Employee } from '../entities/employee.entity';
import { Model } from 'mongoose';
import { BadRequestException, InternalServerErrorException } from '@nestjs/common';
import { UpdateEmployeeUpdateDto } from './dto/update-employee_update.dto'; // Importa tu DTO

describe('EmployeeUpdateService', () => {
  let service: EmployeeUpdateService;
  let model: Model<Employee>;

  const mockEmployeeModel = {
    findById: jest.fn(),
    findByIdAndUpdate: jest.fn(),
  };

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        EmployeeUpdateService,
        {
          provide: getModelToken(Employee.name),
          useValue: mockEmployeeModel,
        },
      ],
    }).compile();

    service = module.get<EmployeeUpdateService>(EmployeeUpdateService);
    model = module.get<Model<Employee>>(getModelToken(Employee.name));
  });

  describe('update', () => {
    it('should successfully update an employee', async () => {
      const employeeID = '60e5e0f2f1d3a1c6e4e1f763';
      const updateProps: UpdateEmployeeUpdateDto = { // Asegúrate de usar el DTO aquí
        Name: 'John',
        LastName: 'Doe',
        Email: 'john.doe@example.com', // Proporcionar un valor para el email
        NumberPhone: '1234567890', // Proporcionar un valor para el número de teléfono
        Balance: 100, // Proporcionar un valor para el saldo
      };

      mockEmployeeModel.findById.mockResolvedValue({ _id: employeeID });
      mockEmployeeModel.findByIdAndUpdate.mockResolvedValue({
        _id: employeeID,
        ...updateProps,
      });

      const result = await service.update({ employeeID, props: updateProps });
      expect(result).toEqual({
        message: 'Empleado actualizado correctamente',
        data: { _id: employeeID, ...updateProps },
        state: true,
        stateCode: 200,
      });
    });

    it('should throw BadRequestException if employee not found', async () => {
      const employeeID = '60e5e0f2f1d3a1c6e4e1f763';
      const updateProps: UpdateEmployeeUpdateDto = { // Usar DTO aquí
        Name: 'John',
        LastName: 'Doe',
        Email: 'john.doe@example.com',
        NumberPhone: '1234567890',
        Balance: 100,
      };

      mockEmployeeModel.findById.mockResolvedValue(null);

      await expect(service.update({ employeeID, props: updateProps })).rejects.toThrow(BadRequestException);
    });

    it('should throw InternalServerErrorException on other errors', async () => {
      const employeeID = '60e5e0f2f1d3a1c6e4e1f763';
      const updateProps: UpdateEmployeeUpdateDto = { // Usar DTO aquí
        Name: 'John',
        LastName: 'Doe',
        Email: 'john.doe@example.com',
        NumberPhone: '1234567890',
        Balance: 100,
      };

      mockEmployeeModel.findById.mockImplementation(() => {
        throw new Error('Some error');
      });

      await expect(service.update({ employeeID, props: updateProps })).rejects.toThrow(InternalServerErrorException);
    });
  });
});
