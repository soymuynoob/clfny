import { BadRequestException, HttpStatus, Injectable, InternalServerErrorException } from '@nestjs/common';
import { UpdateEmployeeUpdateDto } from './dto/update-employee_update.dto';
import { Employee } from '../entities/employee.entity';
import { Model } from 'mongoose';
import { InjectModel } from '@nestjs/mongoose';
import { IEmployeeUpdate } from './interface/interface';

@Injectable()
export class EmployeeUpdateService {
  constructor(
    @InjectModel(Employee.name) private readonly employeeModel: Model<Employee>,
  ) {}

  async update({employeeID,props,}: { employeeID: string; props: UpdateEmployeeUpdateDto; }): Promise<IEmployeeUpdate> {
    try {
      const employee = await this.employeeModel.findById(employeeID);

      if (!employee) throw new BadRequestException({ message: 'Empleado no encontrado', state: false, stateCode: HttpStatus.BAD_REQUEST,});
      
      const updatedEmployee = await this.employeeModel.findByIdAndUpdate(employeeID,props,{ new: true },);

      return {message: 'Empleado actualizado correctamente',data: updatedEmployee,state: true,stateCode: HttpStatus.OK,};

    } catch (error) {
      if (error instanceof BadRequestException) throw error;

      throw new InternalServerErrorException('Ocurrió un error al actualizar el empleado');
    }
  }
}
