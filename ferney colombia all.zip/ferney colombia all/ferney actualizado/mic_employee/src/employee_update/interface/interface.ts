import { HttpStatus } from '@nestjs/common';
import { Employee } from 'src/entities/employee.entity';

export interface IEmployeeUpdate {
  message: string;
  data: Employee;
  state: boolean;
  stateCode: HttpStatus;
}
