import { useMediaQuery } from "@mui/material"
import { useTheme } from "@mui/material/styles"

export const useBreakpoints = () => {
    const theme = useTheme()
    const isDownSmall = useMediaQuery(theme.breakpoints.down("sm"))

    return {
        isDownSmall
    }
}