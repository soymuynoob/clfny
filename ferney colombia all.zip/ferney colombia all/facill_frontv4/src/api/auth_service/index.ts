import { auth_service } from '@api/index'
import { AccessToken, GoogleAccessToken, UserCredentials } from './interface/AuthService';

export const {

    useLoginWithGoogleServiceMutation,
    useLoginServiceMutation,
    useLogoutServiceMutation,

} = auth_service.injectEndpoints({
    endpoints: (build) => ({

        LoginWithGoogleService: build.mutation<AccessToken, GoogleAccessToken>({
            query: (body) => ({ method: "POST", url: "/secure/authenticate/google", body }),
            // invalidatesTags: [],
        }),

        LoginService: build.mutation<AccessToken, UserCredentials>({
            query: (body) => ({
                method: "POST",
                url: "/auth/auth/user",
                body,
                headers: {
                    'Content-Type': 'application/json',
                },
            }),
            // invalidatesTags: [],
        }),

        LogoutService: build.mutation<void, void>({
            query: () => ({
                method: "POST",
                url: "/auth/logout",
            }),
            // invalidatesTags: [],
        }),

    }),
    overrideExisting: false,
});