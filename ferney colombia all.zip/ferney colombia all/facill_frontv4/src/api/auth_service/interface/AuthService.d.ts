export interface GoogleAccessToken {
    token_google: string
}

export interface AccessToken {
    accessToken: string;
    data: any;
    message: string;
    state: boolean;
}

export interface UserCredentials {
    userEmail: string;
    password: string;
}