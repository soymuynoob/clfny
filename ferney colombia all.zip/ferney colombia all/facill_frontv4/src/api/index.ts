import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";
import GetEnv from "@util/getEnv";

/** API de Autenticación */
export const auth_service = createApi({
  reducerPath: "auth_service",
  baseQuery: fetchBaseQuery({ baseUrl: GetEnv("VITE_AUTH_SERVICE_URL") }),
  endpoints: () => ({}),
});

export const user_service = createApi({
  reducerPath: "user_service",
  baseQuery: fetchBaseQuery({ baseUrl: GetEnv("VITE_USER_SERVICE_URL") }),
  endpoints: () => ({}),
});
