import { user_service } from '@api/index'
import { IRegisterUser } from './interface';

export const EndPoints = user_service.injectEndpoints({
    endpoints: (build) => ({

        RegisterUser: build.mutation<void, IRegisterUser>({
            query: (body) => ({
                method: "POST",
                url: "/auth/register/user",
                body,
                headers: {
                    'Content-Type': 'application/json',
                },
            }),
        }),

    }),
    overrideExisting: false,
});

export const { useRegisterUserMutation } = EndPoints;