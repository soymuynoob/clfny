export interface IRegisterUser {
  Name: string;
  LastName: string;
  Email: string;
  PhoneNumber: string;
  Password: string;
  BusinessName: string;
}
