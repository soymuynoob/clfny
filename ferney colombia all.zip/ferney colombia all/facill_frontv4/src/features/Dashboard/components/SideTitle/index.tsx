import { Stack, Typography } from "@mui/material"
import { StoreIcon } from "lucide-react"

const SideTitle = () => {
    return (
        <Stack sx={{ color: "#000000" }} direction={'row'} alignItems={'center'} gap={1} >
            <StoreIcon />
            <Typography variant='h6' >
                Mi negocio
            </Typography>
        </Stack>
    )
}

export default SideTitle