import { styled } from '@mui/material/styles';
import { Box, Divider, Drawer as MuiDrawer, Stack, drawerClasses } from '@mui/material';
// import SelectContent from './SelectContent';
import MenuContent from './MenuContent';
import GoPointOfSale from '@component/GoPointOfSale';
import SideTitle from './SideTitle';

const drawerWidth = 240;

const Drawer = styled(MuiDrawer)({
  width: drawerWidth,
  flexShrink: 0,
  boxSizing: 'border-box',
  mt: 10,
  [`& .${drawerClasses.paper}`]: {
    width: drawerWidth,
    boxSizing: 'border-box',
  },
});

const SideMenu = () => {
  return (
    <Drawer variant="permanent"
      sx={{
        display: { xs: 'none', md: 'block' },
        [`& .${drawerClasses.paper}`]: {
          backgroundColor: 'background.paper',
        },
      }}
    >
      <Box sx={{ display: 'flex', mt: 'calc(var(--template-frame-height, 0px) + 4px)', p: 1.5 }} >
        {/* <SelectContent /> */}
        <SideTitle />
      </Box>
      <Divider />
      <MenuContent />
      <Stack
        direction="row"
        sx={{
          p: 2,
          gap: 1,
          alignItems: 'center',
          borderTop: '1px solid',
          borderColor: 'divider',
        }}
      >
        <GoPointOfSale buttonType='listItem' />
      </Stack>
    </Drawer>
  );
}

export default SideMenu