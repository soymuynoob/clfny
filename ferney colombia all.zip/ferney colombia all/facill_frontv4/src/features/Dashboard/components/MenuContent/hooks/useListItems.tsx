import { ArrowRightRounded, GroupsRounded } from "@mui/icons-material"
import { CircleDollarSign, HandCoins, Package, ShoppingCart, TrendingUp } from "lucide-react"
import { ReactNode, useCallback, useMemo } from "react"
import { useNavigate } from "react-router-dom"
import { getPath, PathParam } from "../utils/getPath"

export interface ListItems {
    name: string,
    icon: ReactNode,
    onClick: () => void,
    children?: ListItems[]
}

export const useListItems = () => {
    const navigate = useNavigate()
    const ChildDefaultIcon = useMemo(() => <ArrowRightRounded />, [])

    const navigateTo = useCallback((pathName:PathParam) => {
        const url = getPath(pathName)
        if( url.toString().trim() === "" ){
            alert("Ruta no disponible")
        }else{
            navigate(url)
        }
    }, [navigate])

    const mainListItems = useMemo(() => {
        const listItems: ListItems[] = [
            {
                name: "Compras",
                icon: <ShoppingCart className="MuiSvgIcon-root" />,
                onClick: () => null,
                children: [
                    { name: "Ingreso de compras", icon: ChildDefaultIcon, onClick: () => null },
                    { name: "Reporte de compras", icon: ChildDefaultIcon, onClick: () => null },
                ]
            },
            {
                name: "Efectivo y bancos",
                icon: <CircleDollarSign className="MuiSvgIcon-root" /> ,
                onClick: () => null,
                children: [
                    { name: "Caja principal", icon: ChildDefaultIcon, onClick: () => navigateTo("mainBox") },
                    { name: "Cajas punto de venta", icon: ChildDefaultIcon, onClick: () => null },
                    { name: "Bolsillos", icon: ChildDefaultIcon, onClick: () => navigateTo("pockets") },
                    { name: "Bancos", icon: ChildDefaultIcon, onClick: () => null },
                ]
            },
            {
                name: "Terceros",
                icon: <GroupsRounded />,
                onClick: () => null,
                children: [
                    { name: "Clientes", icon: ChildDefaultIcon, onClick: () => navigateTo("customers") },
                    { name: "Proveedores", icon: ChildDefaultIcon, onClick: () => navigateTo("suppliers") },
                    { name: "Equipo", icon: ChildDefaultIcon, onClick: () => navigateTo("team") },
                    { name: "Domiciliarios", icon: ChildDefaultIcon, onClick: () => navigateTo("deliveries") },
                    { name: "Transportistas", icon: ChildDefaultIcon, onClick: () => navigateTo("hauliers") },
                ]
            },
            {
                name: "Gastos",
                icon: <HandCoins className="MuiSvgIcon-root" />,
                onClick: () => null,
                children: [
                    { name: "Gastos fijos", icon: ChildDefaultIcon, onClick: () => navigateTo("expenseFixed") },
                    { name: "Gastos generales", icon: ChildDefaultIcon, onClick: () => navigateTo("overheads") },
                ]
            },
            {
                name: "Productos",
                icon: <Package className="MuiSvgIcon-root" />,
                onClick: () => null,
                children: [
                    { name: "Inventarios", icon: ChildDefaultIcon, onClick: () => navigateTo("inventory") },
                    { name: "Categorías", icon: ChildDefaultIcon, onClick: () => navigateTo("categories") },
                    { name: "Embalajes", icon: ChildDefaultIcon, onClick: () => navigateTo("packaging") },
                ]
            },
            {
                name: "Reportes",
                icon: <TrendingUp className="MuiSvgIcon-root" />,
                onClick: () => null,
                children: [
                    { name: "Créditos", icon: ChildDefaultIcon, onClick: () => navigateTo("credits") },
                    { name: "Entregas", icon: ChildDefaultIcon, onClick: () => navigateTo("delivery") },
                    { name: "Ventas", icon: ChildDefaultIcon, onClick: () => navigateTo("sales") },
                ]
            },
        ]
        return listItems
    }, [ChildDefaultIcon, navigateTo])

    return {
        mainListItems,
    }
}