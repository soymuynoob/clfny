import Stack from '@mui/material/Stack';
import { useListItems } from './hooks/useListItems';
import { List } from '@mui/material';
import { Fragment } from 'react/jsx-runtime';
import Item from './components/Item';


const MenuContent = () => {
  const { mainListItems } = useListItems()
  return (
    <Stack sx={{ flexGrow: 1, p: 1, justifyContent: 'space-between' }}>
      <List dense>
        {mainListItems.map((item, index) => (
          <Fragment key={index} >
            <Item {...item} />
          </Fragment>
        ))}
      </List>

      {/* <List dense>
        {secondaryListItems.map((item, index) => (
          <ListItem key={index} disablePadding sx={{ display: 'block' }}>
            <ListItemButton>
              <ListItemIcon>{item.icon}</ListItemIcon>
              <ListItemText primary={item.text} />
            </ListItemButton>
          </ListItem>
        ))}
      </List> */}
    </Stack>
  );
}

export default MenuContent