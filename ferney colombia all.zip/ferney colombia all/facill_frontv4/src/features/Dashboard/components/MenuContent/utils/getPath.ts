import { To } from "react-router-dom";

const APP_PATHS = [
  { name: "customers", path: "/customers" },
  { name: "inventory", path: "/inventory" },
  { name: "categories", path: "/categories" },
  { name: "packaging", path: "/packaging" },
  { name: "expenseFixed", path: "/expense-fixed" },
  { name: "overheads", path: "/overheads" },
  { name: "suppliers", path: "/suppliers" },
  { name: "team", path: "/team" },
  { name: "deliveries", path: "/deliveries" },
  { name: "hauliers", path: "/hauliers" },
  {name: "mainBox", path: '/main/box'},
  {name: "pockets", path: '/pockets'},
  {name: "credits", path: '/credits'},
  {name: "delivery", path: '/delivery'},
  {name: "sales", path: '/sales'},
];

export type PathParam =
  | "customers"
  | "inventory"
  | "categories"
  | "packaging"
  | "expenseFixed"
  | "overheads"
  | "suppliers"
  | "team"
  | "deliveries"
  | "hauliers"
  | "mainBox"
  | "pockets"
  | "credits"
  | "delivery"
  | "sales"

export const getPath = (pathName: PathParam): To => {
  const PathObject = APP_PATHS.find(({ name }) => name === pathName);
  if (!PathObject) {
    return "";
  } else {
    return PathObject["path"];
  }
};
