import { Fragment } from "react/jsx-runtime"
import { ListItems } from "../hooks/useListItems"
import { List, ListItem, ListItemButton, ListItemIcon, ListItemText, Popover } from "@mui/material"
import { FC, MouseEvent, useCallback, useState } from "react"
import { ChevronRightRounded } from "@mui/icons-material"

interface Props {
    index?: number
}

const Item: FC<ListItems & Props> = (props) => {
    const [anchorEl, setAnchorEl] = useState<Element | null>(null)
    const { icon = <></>, name = "", onClick = () => null, children = [] } = props
    const haveChildren: boolean = (Array.isArray(children) && (children.length >= 1))

    const handlePopoverClose = useCallback(() => setAnchorEl(null), [])

    const handleClickPrimaryButton = useCallback((event: MouseEvent<HTMLElement>) => {
        if( (haveChildren === true) ){
            setAnchorEl(event.currentTarget)
        } else {
            onClick()
        }
    },[haveChildren, onClick])

    const handleClickSecondaryButton = useCallback((childOnClick:()=>void) => {
        childOnClick()
        setAnchorEl(null)
    },[])

    return (
        <Fragment>
            <ListItem disablePadding sx={{ display: 'block', mb: 1 }} >
                <ListItemButton selected onClick={handleClickPrimaryButton} >
                    <ListItemIcon>{icon}</ListItemIcon>
                    <ListItemText primary={name} />
                    {haveChildren && <ChevronRightRounded />}
                </ListItemButton>
            </ListItem>
            {haveChildren &&
                <Popover open={Boolean(anchorEl)} anchorEl={anchorEl} onClose={handlePopoverClose}
                    anchorOrigin={{
                        vertical: 'top',
                        horizontal: 'right',
                    }}
                    transformOrigin={{
                        vertical: 'top',
                        horizontal: 'left',
                    }}
                >
                    {children.map((item, index) => {
                        return (
                            <Fragment key={index} >
                                <List dense>
                                <ListItem disablePadding sx={{ display: 'block' }} >
                                    <ListItemButton onClick={() => handleClickSecondaryButton(item.onClick)} >
                                        <ListItemIcon>{item.icon}</ListItemIcon>
                                        <ListItemText primary={item.name} />
                                    </ListItemButton>
                                </ListItem>
                                </List>
                            </Fragment>
                        )
                    })}
                </Popover>
            }
        </Fragment>
    )
}

export default Item