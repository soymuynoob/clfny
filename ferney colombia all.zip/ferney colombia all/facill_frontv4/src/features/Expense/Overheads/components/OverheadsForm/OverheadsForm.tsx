import React from "react";
import {
  Button,
  TextField,
  Typography,
} from "@mui/material";
import { Grid } from "@component/UI";
import Wrapper from "./components/Wrapper";

interface Props {
  isOpen?: boolean;
  onClose?: () => void;
}

const OverheadsForm: React.FC<Props> = (props) => {
  const { isOpen, onClose } = props;

  const [formValues, setFormValues] = React.useState({
    responsible: "",
    amount: "",
    outputCashbox: "",
    expense: "",
    description: "",
    registrationDate: "",
  });
  const [errors, setErrors] = React.useState<any>({});

  const handleChange = (
    event: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = event.target;
    setFormValues({ ...formValues, [name]: value });
  };

  const validateForm = () => {
    const newErrors: any = {};
    if (!formValues.responsible) {
      newErrors.responsible = "El campo Responsable es requerido.";
    }
    if (!formValues.amount) {
      newErrors.amount = "El campo Monto es requerido.";
    }
    if (!formValues.outputCashbox) {
      newErrors.outputCashbox = "El campo Caja de salida es requerido.";
    }
    if (!formValues.expense) {
      newErrors.expense = "El campo Gasto es requerido.";
    }
    if (!formValues.description) {
      newErrors.description = "El campo Descripción es requerido.";
    }
    if (!formValues.registrationDate) {
      newErrors.registrationDate = "El campo Fecha de registro es requerido.";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0; // Return true if no errors
  };

  return (
    <Wrapper isOpen={isOpen} onClose={onClose}>
      <Grid container spacing={1.5}>
        <Grid size={12}>
          <Typography variant="subtitle2">
            Información de Gasto General:
          </Typography>
        </Grid>
        <Grid size={12}>
          <TextField
            name="expense"
            label="Gasto"
            variant="outlined"
            fullWidth
            value={formValues.expense}
            onChange={handleChange}
            error={!!errors.expense}
            helperText={errors.expense}
          />
        </Grid>
        <Grid container spacing={2}>
          <Grid size={4}>
            <TextField
              name="amount"
              label="Monto"
              variant="outlined"
              fullWidth
              value={formValues.amount}
              onChange={handleChange}
              error={!!errors.amount}
              helperText={errors.amount}
            />
          </Grid>
          <Grid size={4}>
            <TextField
              name="registrationDate"
              label="Fecha de Registro"
              variant="outlined"
              fullWidth
              type="date"
              InputLabelProps={{
                shrink: true,
              }}
              value={formValues.registrationDate}
              onChange={handleChange}
              error={!!errors.registrationDate}
              helperText={errors.registrationDate}
            />
          </Grid>
          <Grid size={4}>
            <TextField
              name="responsible"
              label="Responsable"
              variant="outlined"
              fullWidth
              value={formValues.responsible}
              onChange={handleChange}
              error={!!errors.responsible}
              helperText={errors.responsible}
            />
          </Grid>
        </Grid>
        <Grid size={12}>
          <TextField
            name="outputCashbox"
            label="Caja de Salida"
            variant="outlined"
            fullWidth
            value={formValues.outputCashbox}
            onChange={handleChange}
            error={!!errors.outputCashbox}
            helperText={errors.outputCashbox}
          />
        </Grid>
        <Grid size={12}>
          <TextField
            name="description"
            label="Descripción"
            variant="outlined"
            fullWidth
            multiline
            rows={4}
            value={formValues.description}
            onChange={handleChange}
            error={!!errors.description}
            helperText={errors.description}
          />
        </Grid>

        <Grid size={12}>
          <Button variant="contained" fullWidth size="large">
            Guardar
          </Button>
        </Grid>
      </Grid>
    </Wrapper>
  );
};

export default OverheadsForm;
