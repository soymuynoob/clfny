import { HandCoins } from "lucide-react"
import { ReactNode, useMemo } from "react"

interface ListProps {
    id: number,
    name: string,
    icon: ReactNode,
    onClick: () => void
}

export const useMenuListOverheads= () => {
    
    const list = useMemo(() => {
        const data:ListProps[] = [
            { name: "Registrar nuevo gasto fijo", icon: <HandCoins />, onClick: () => null },
        ].map((item, index) => ({...item, id: (index+1)}))
        return data
    }, [])

    return { list }
}