import { Stack } from "@mui/material";

export const DesktopRegisterOverheadsButton = () => {
  return (
    <>
      <Stack direction={"row"} alignItems={"center"} gap={1}></Stack>
    </>
  );
};

const Desktop = () => {
  return (
    <>
      <Stack direction={"row"} gap={1}></Stack>
    </>
  );
};

export default Desktop;
