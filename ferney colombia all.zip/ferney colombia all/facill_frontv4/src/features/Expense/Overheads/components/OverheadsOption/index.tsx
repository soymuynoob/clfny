import { useBreakpoints } from "@hook/useBreakpoints"
import Mobile from "./components/Mobile"
import { useMemo } from "react"
import { Stack } from "@mui/material"
import { useMenuListOverheads } from "./hooks/useMenuListOverheads"
import Desktop, { DesktopRegisterOverheadsButton } from "./components/Desktop"

const OverheadsOption = () => {
    const { list } = useMenuListOverheads()
    const mobileList = useMemo(() => list.filter((item:any) => item.id !== 1 ), [list])

    const { isDownSmall } = useBreakpoints()

    if( isDownSmall ){
        return(
      <Stack justifyContent={"space-between"} direction={"row"}>
        <DesktopRegisterOverheadsButton />
        <Mobile list={mobileList} />
      </Stack>
        )
    }else{
        return(
            <>
                <Desktop />
            </>
        )
    }

}

export default OverheadsOption