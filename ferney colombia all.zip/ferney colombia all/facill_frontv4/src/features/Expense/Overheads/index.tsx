import { Grid } from "@component/UI";
import CardWrapper from "@component/CardWrapper";
import CustomizedDataGrid from "@component/CustomizedDataGrid";
import OverheadsOption from "./components/OverheadsOption";
import { HandCoins } from "lucide-react";
const Overheads = () => {
  return (
    <CardWrapper icon={<HandCoins />} title="Gastos generales">
      <Grid container spacing={1}>
        <Grid size={12}>
          <OverheadsOption />
        </Grid>

        <Grid size={12}>
          <CustomizedDataGrid
            columns={[
              { field: "____", headerName: "Responsable" },
              { field: "_____", headerName: "Monto" },
              { field: "______", headerName: "Gasto" },
              { field: "_______", headerName: "Caja de salida" },
              { field: "________", headerName: "Descripción" },
              { field: "_________", headerName: "Fecha de registro" },
            ]}
          />
        </Grid>
      </Grid>
    </CardWrapper>
  );
};

export default Overheads;
