import { useBreakpoints } from "@hook/useBreakpoints"
import Mobile from "./components/Mobile"
import { useMemo } from "react"
import { Stack } from "@mui/material"
import Desktop, { DesktopRegisterExpenseFixedButton } from "./components/Desktop"
import { useMenuListExpenseFixed } from "./hooks/useMenuListExpenseFixed"

const ExpenseFixedOption = () => {
    const { list } = useMenuListExpenseFixed()
    const mobileList = useMemo(() => list.filter((item:any) => item.id !== 1 ), [list])

    const { isDownSmall } = useBreakpoints()

    if( isDownSmall ){
        return(
            <Stack justifyContent={'space-between'} direction={'row'} >
                <DesktopRegisterExpenseFixedButton />
                <Mobile list={mobileList} />
            </Stack>
        )
    }else{
        return(
            <>
                <Desktop />
            </>
        )
    }

}

export default ExpenseFixedOption