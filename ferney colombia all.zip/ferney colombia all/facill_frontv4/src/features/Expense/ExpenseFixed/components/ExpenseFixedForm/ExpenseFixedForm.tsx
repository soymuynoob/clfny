import React from "react";
import {
  Button,
  Checkbox,
  FormControlLabel,
  MenuItem,
  TextField,
  Typography,
} from "@mui/material";
import { Grid } from "@component/UI";
import Wrapper from "./components/Wrapper";

interface Props {
  isOpen?: boolean;
  onClose?: () => void;
}

const ExpenseFixedForm: React.FC<Props> = (props) => {
  const { isOpen, onClose } = props;
  const [formValues, setFormValues] = React.useState({
    spent: "",
    amount: "",
    dateExpiration: "",
    tag: "",
    ajuste: "",
    seguimientoAutomatico: false,
  });
  const [errors, setErrors] = React.useState<any>({});

  const handleChange = (
    event: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = event.target;
    setFormValues({ ...formValues, [name]: value });
  };

  const validateForm = () => {
    const newErrors: any = {};
    if (!formValues.spent) {
      newErrors.spent = "El campo Gasto es requerido.";
    }
    if (!formValues.amount) {
      newErrors.amount = "El campo Monto es requerido.";
    }
    if (!formValues.dateExpiration) {
      newErrors.dateExpiration = "El campo Fecha de Expiración es requerido.";
    }
    if (!formValues.tag) {
      newErrors.tag = "El campo Etiqueta es requerido.";
    }
    if (!formValues.ajuste) {
      newErrors.ajuste = "El campo Ajustar a es requerido.";
    }
    if (!formValues.seguimientoAutomatico) {
      newErrors.seguimientoAutomatico =
        "El campo Seguimiento automático es requerido.";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0; // Return true if no errors
  };

  return (
    <Wrapper isOpen={isOpen} onClose={onClose}>
      <Grid container spacing={1.5}>
        <Grid size={12}>
          <Typography variant="subtitle2">
            Información de Gasto Fijo:
          </Typography>
        </Grid>

        <Grid size={12}>
          <TextField
            name="spent"
            label="Gasto"
            variant="outlined"
            fullWidth
            value={formValues.spent}
            onChange={handleChange}
            error={!!errors.spent}
            helperText={errors.spent}
          />
        </Grid>
        <Grid container spacing={2}>
          <Grid size={4}>
            <TextField
              name="amount"
              label="Monto"
              variant="outlined"
              fullWidth
              value={formValues.amount}
              onChange={handleChange}
              error={!!errors.amount}
              helperText={errors.amount}
            />
          </Grid>
          <Grid size={4}>
            <TextField
              name="dateExpiration"
              label="Fecha de Expiración"
              variant="outlined"
              fullWidth
              value={formValues.dateExpiration}
              onChange={handleChange}
              error={!!errors.dateExpiration}
              helperText={errors.dateExpiration}
            />
          </Grid>
          <Grid size={4}>
            <TextField
              name="tag"
              label="Etiqueta"
              variant="outlined"
              fullWidth
              value={formValues.tag}
              onChange={handleChange}
              error={!!errors.tag}
              helperText={errors.tag}
            />
          </Grid>
        </Grid>
        <Grid size={12}>
          <TextField
            select
            fullWidth
            variant="outlined"
            label="Seleccione un ajuste"
            name="ajuste"
            value={formValues.ajuste || ""}
            onChange={handleChange}
          >
            <MenuItem value="mensual">Ajustar mensual</MenuItem>
            <MenuItem value="quincenal">Ajustar quincenal</MenuItem>
          </TextField>
        </Grid>

        <Grid size={12}>
          <FormControlLabel
            control={
              <Checkbox
                checked={formValues.seguimientoAutomatico || false}
                onChange={handleChange}
                name="seguimientoAutomatico"
              />
            }
            label="Seguimiento automático"
          />
        </Grid>

        <Grid size={12}>
          <Button variant="contained" fullWidth size="large">
            Guardar
          </Button>
        </Grid>
      </Grid>
    </Wrapper>
  );
};

export default ExpenseFixedForm;
