import { Button, Stack } from "@mui/material"
import { useState } from "react"
import ExpenseFixedForm from "../../ExpenseFixedForm/ExpenseFixedForm";
import AddCardRoundedIcon from '@mui/icons-material/AddCardRounded';
export const DesktopRegisterExpenseFixedButton = () => {
  const [isModalOpen, setModalOpen] = useState<boolean>(false);

  const openModal = () => setModalOpen(true);
  const closeModal = () => setModalOpen(false);

    return (
        <>
            <Stack direction={"row"} alignItems={"center"} gap={1}>
              <Button size="small" variant="contained" startIcon={<AddCardRoundedIcon />} onClick={openModal} >
                Registrar gasto
              </Button>
              <ExpenseFixedForm isOpen={isModalOpen} onClose={closeModal} />
            </Stack>
        </>
    )
}

const Desktop = () => {
    return (
        <>
            <Stack direction={'row'} gap={1} >
                <DesktopRegisterExpenseFixedButton />
            </Stack>
        </>
    )
}

export default Desktop