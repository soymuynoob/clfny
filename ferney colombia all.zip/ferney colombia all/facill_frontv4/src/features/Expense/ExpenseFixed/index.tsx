import { Grid } from "@component/UI";
import { HandCoins } from "lucide-react";
import CardWrapper from "@component/CardWrapper";
import CustomizedDataGrid from "@component/CustomizedDataGrid";
import ExpenseFixedOption from "./components/ExpenseFixedOption";

const ExpenseFixed = () => {
  return (
    <CardWrapper icon={<HandCoins />} title="Gastos fijos">
      <Grid container spacing={1}>
        <Grid size={12}>
          <ExpenseFixedOption />
        </Grid>

        <Grid size={12}>
          <CustomizedDataGrid
            columns={[
              { field: "_", headerName: "Gasto" },
              { field: "__", headerName: "Monto" },
              { field: "___", headerName: "Vencimiento" },
              { field: "____", headerName: "Etiqueta" },
              { field: "_____", headerName: "Seguimiento" },
              { field: "______", headerName: "Ajustar a" },

            ]}
          />
        </Grid>
      </Grid>
    </CardWrapper>
  );
};

export default ExpenseFixed;
