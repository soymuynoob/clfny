import { IFormButtoms } from "../interface/FormFields";
import { Button } from "@component/UI";
import { Stack } from "@mui/material";
import { RootState } from "@redux/store";
import { FC } from "react";
import { useSelector } from "react-redux";

const FormButtons: FC<IFormButtoms> = ({ onLogin, onRegisterNavigation }) => {
  const loading = useSelector((state: RootState) => state.register.loading);

  return (
    <>
      <Stack gap={1} mt={5} direction={"row"} justifyContent={"space-between"}>
        <Button
          variant="text"
          disableElevation
          size="large"
          onClick={onRegisterNavigation}
        >
          Regresar
        </Button>
        <Button
          variant="contained"
          disableElevation
          type="submit"
          loading={loading}
          size="large"
          onClick={onLogin}
        >
          Registrarse
        </Button>
      </Stack>
    </>
  );
};

export default FormButtons;
