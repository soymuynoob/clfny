import { ChangeEvent, FC, useState } from "react";
import { Grid } from "@component/UI";
import {
  FormControl,
  FormHelperText,
  IconButton,
  InputAdornment,
  InputLabel,
  OutlinedInput,
  TextField,
} from "@mui/material";
import { PatternFormat } from "react-number-format";
import { Props } from "../interface/FormFields";
import Visibility from "@mui/icons-material/Visibility";
import VisibilityOff from "@mui/icons-material/VisibilityOff";

const FormFields: FC<Props> = ({
  onChangeName,
  onChangeSurname,
  onChangeCompanyIdentifier,
  onChangeEmail,
  onChangePassword,
  onChangePasswordDuplicate,
  onChangeNumber,
  errors,
  isError,
}) => {
  const [showPassword, setShowPassword] = useState(false);

  const handleClickShowPassword = () => setShowPassword((show) => !show);

  const handleMouseDownPassword = (
    event: React.MouseEvent<HTMLButtonElement>
  ) => {
    event.preventDefault();
  };

  const handleMouseUpPassword = (
    event: React.MouseEvent<HTMLButtonElement>
  ) => {
    event.preventDefault();
  };

  const handleKeyDown = (event: React.KeyboardEvent<HTMLInputElement>) => {
    if (event.key === " ") {
      event.preventDefault(); // Avoid spaces in text input
    }
  };

  return (
    <Grid container spacing={1.5}>
      <Grid size={6}>
        <TextField
          autoFocus
          fullWidth
          label="Nombres"
          type="text"
          error={errors?.name && isError}
          helperText={errors?.name && errors?.name}
          onChange={(event: ChangeEvent<HTMLInputElement>) =>
            onChangeName(event.target.value)
          }
        />
      </Grid>
      <Grid size={6}>
        <TextField
          fullWidth
          label="Apellidos"
          type="text"
          onChange={(event: ChangeEvent<HTMLInputElement>) =>
            onChangeSurname(event.target.value)
          }
        />
      </Grid>
      <Grid size={12}>
        <TextField
          fullWidth
          label="Razón social"
          type="text"
          error={errors?.companyIdentifier && isError}
          helperText={errors?.companyIdentifier && errors?.companyIdentifier}
          onChange={(event: ChangeEvent<HTMLInputElement>) =>
            onChangeCompanyIdentifier(event.target.value)
          }
        />
      </Grid>
      <Grid size={12}>
        <PatternFormat
          format="(+57) - ### ### ## ##"
          mask=" "
          type="tel"
          error={errors?.number && isError}
          helperText={errors?.number && errors?.number}
          customInput={TextField}
          allowEmptyFormatting
          valueIsNumericString
          fullWidth
          variant="outlined"
          label="Número de teléfono"
          onChange={(event: any) => onChangeNumber(event.target.value)}
        />
      </Grid>
      <Grid size={12}>
        <TextField
          fullWidth
          label="Correo electrónico"
          type="email"
          error={errors?.email && isError}
          helperText={errors?.email && errors?.email}
          onChange={(event: ChangeEvent<HTMLInputElement>) =>
            onChangeEmail(event.target.value)
          }
          onKeyDown={handleKeyDown}
        />
      </Grid>
      <Grid size={6}>
        <FormControl variant="outlined" fullWidth>
          <InputLabel htmlFor="outlined-adornment-password">
            Contraseña
          </InputLabel>
          <OutlinedInput
            id="outlined-adornment-password"
            type={showPassword ? "text" : "password"}
            error={errors?.password && isError}
            onChange={(event: ChangeEvent<HTMLInputElement>) =>
              onChangePassword(event.target.value)
            }
            onKeyDown={handleKeyDown}
            endAdornment={
              <InputAdornment position="end">
                <IconButton
                  aria-label="toggle password visibility"
                  onClick={handleClickShowPassword}
                  onMouseDown={handleMouseDownPassword}
                  onMouseUp={handleMouseUpPassword}
                  edge="end"
                >
                  {showPassword ? <VisibilityOff /> : <Visibility />}
                </IconButton>
              </InputAdornment>
            }
            label="Contraseña"
          />
          {errors?.password && (
            <FormHelperText error={isError}>{errors?.password}</FormHelperText>
          )}
        </FormControl>
      </Grid>
      <Grid size={6}>
        <FormControl variant="outlined" fullWidth>
          <InputLabel htmlFor="outlined-adornment-password">
            Repetir Contraseña
          </InputLabel>
          <OutlinedInput
            id="outlined-adornment-password"
            type={showPassword ? "text" : "password"}
            error={errors?.passwordDuplicate && isError}
            onChange={(event: ChangeEvent<HTMLInputElement>) =>
              onChangePasswordDuplicate(event.target.value)
            }
            onKeyDown={handleKeyDown}
            endAdornment={
              <InputAdornment position="end">
                <IconButton
                  aria-label="toggle password visibility"
                  onClick={handleClickShowPassword}
                  onMouseDown={handleMouseDownPassword}
                  onMouseUp={handleMouseUpPassword}
                  edge="end"
                >
                  {showPassword ? <VisibilityOff /> : <Visibility />}
                </IconButton>
              </InputAdornment>
            }
            label="Repetir Contraseña"
          />
          {errors?.passwordDuplicate && (
            <FormHelperText error={isError}>{errors?.passwordDuplicate}</FormHelperText>
          )}
        </FormControl>
      </Grid>
    </Grid>
  );
};

export default FormFields;
