interface IValues {
  name?: string;
  surname?: string;
  companyIdentifier?: string;
  email?: string;
  password?: string;
  passwordDuplicate?: string;
  number?: string;
}

type PropsValidator = {
  values: IValues;
};

export const ValidatorRegister = ({ values }: PropsValidator) => {
  const cleanNumber: any =
    values.number && values?.number?.replace(/[^\d]/g, "").replace(/^57/, "");
  const errors: IValues = {};

  if (!values.name) {
    errors.name = "El nombre es un campo requerido.";
  }

  if (!values.companyIdentifier) {
    errors.companyIdentifier = "La razón social es un campo requerido.";
  }

  if (!values.email) {
    errors.email = "El correo electrónico es requerido.";
  } else if (!/\S+@\S+\.\S+/.test(values.email)) {
    errors.email = "El correo electrónico no es válido.";
  }

  if (!values.password) {
    errors.password = "La contraseña es requerida.";
  } else if (values.password.length < 8) {
    errors.password = "La contraseña debe tener al menos 8 caracteres.";
  }

  if (values.password !== values.passwordDuplicate) {
    errors.passwordDuplicate = "Las contraseñas no coinciden.";
  }

  if (!/^\d{10}$/.test(cleanNumber)) {
    errors.number = "El número de teléfono debe contener 10 dígitos.";
  }

  return errors;
};
