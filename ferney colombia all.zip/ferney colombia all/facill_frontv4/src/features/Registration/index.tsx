import { useState } from "react";
import { Grid } from "@component/UI";
import { useBreakpoints } from "@hook/useBreakpoints";
import {
  Box,
  Card,
  CardContent,
  Container as ContainerMUI,
  FormHelperText,
  Alert,
} from "@mui/material";
import { styled } from "@mui/material/styles";
import { useNavigate } from "react-router-dom";
import FormFields from "./components/FormFields";
import FormButtons from "./components/FormButtoms";
import { ValidatorRegister } from "./utils/validation";
import HeaderForm from "@feature/Authentication/components/HeaderForm";
import { useRegisterUserMutation } from "@api/user_service";
import { useDispatch } from "react-redux";
import {
  registerFailure,
  registerRequest,
  registerSuccess,
} from "@redux/features/registration/registerSlice";
import { login } from "@redux/features/auth/authSlice";

const Container = styled(ContainerMUI)(() => ({
  width: "100%",
  height: "100%",
  display: "flex",
  flexDirection: "column",
  justifyContent: "center",
}));

const Registration = () => {
  const [registerUser] = useRegisterUserMutation();
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { isDownSmall } = useBreakpoints();
  const [name, setName] = useState<string>("");
  const [number, setNumber] = useState<string>("");
  const [surname, setSurname] = useState<string>("");
  const [companyIdentifier, setCompanyIdentifier] = useState<string>("");
  const [email, setEmail] = useState<string>("");
  const [password, setPassword] = useState<string>("");
  const [passwordDuplicate, setPasswordDuplicate] = useState<string>("");
  const [error, setError] = useState<boolean>(false);
  const [helperText, setHelperText] = useState<any>({});
  const [generalError, setGeneralError] = useState<string>("");

  const onSubmitLogin = async () => {
    const values: any = {
      name,
      surname,
      companyIdentifier,
      email,
      password,
      passwordDuplicate,
      number,
    };
    const validationErrors = ValidatorRegister({ values });
    if (Object.keys(validationErrors).length > 0) {
      setError(true);
      setHelperText(validationErrors);
      setGeneralError("");
    } else {
      setError(false);
      setHelperText({});
      setGeneralError("");

      dispatch(registerRequest());

      try {
        const response: any = await registerUser({
          Email: email,
          Name: name,
          LastName: surname,
          BusinessName: companyIdentifier,
          Password: password,
          PhoneNumber: number
        }).unwrap();
        dispatch(registerSuccess(response.data));
        if (response.accessToken) {
          dispatch(login(response.accessToken))
          navigate('/');
        }
      } catch (error: any) {
        console.error(error);
        const errorMessage = error?.data?.message || error?.message || "Error en el registro";
        setGeneralError(errorMessage);
        dispatch(registerFailure(errorMessage));
      }
    }
  };

  return (
    <>
      <Container maxWidth="sm">
        <Card elevation={isDownSmall ? 0 : 1}>
          <CardContent>
            <HeaderForm />
            <Box
              textAlign={"center"}
              fontWeight={"bold"}
              textTransform={"uppercase"}
              fontSize={isDownSmall ? "1rem" : "1.2rem"}
              mb={4}
            >
              Registro
            </Box>
            {generalError && (
              <Alert severity="error" sx={{ mb: 2 }}>
                {generalError}
              </Alert>
            )}
            <FormFields
              onChangeName={setName}
              onChangeSurname={setSurname}
              onChangeCompanyIdentifier={setCompanyIdentifier}
              onChangeEmail={setEmail}
              onChangePassword={setPassword}
              onChangePasswordDuplicate={setPasswordDuplicate}
              onChangeNumber={setNumber}
              isError={error}
              errors={helperText}
            />
            <Grid size={12}>
              <FormButtons
                onLogin={onSubmitLogin}
                onRegisterNavigation={() => navigate("/login")}
              />
            </Grid>
          </CardContent>
        </Card>
      </Container>
    </>
  );
};

export default Registration;
