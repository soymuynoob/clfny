export interface Props {
    onChangeName: (event: string) => void;
    onChangeSurname: (event: string) => void;
    onChangeCompanyIdentifier: (event: string) => void;
    onChangeEmail: (event: string) => void;
    onChangePassword: (event: string) => void;
    onChangePasswordDuplicate: (event: string) => void;
    onChangeNumber: (event: string) => void;
    isError: boolean;
    errors: any;
}

export interface IFormButtoms {
    onLogin?: () => void;
    onRegisterNavigation?: () => void;
}
