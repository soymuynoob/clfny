import { Button, Stack } from "@mui/material"
import { FileDown, FileUp, PackagePlusIcon } from "lucide-react"
import { useState } from "react"
import PackagingForm from "../../PackagingForm/PackagingForm";

export const DesktopRegisterPackagingButton = () => {
  const [isModalOpen, setModalOpen] = useState<boolean>(false);

  const openModal = () => setModalOpen(true);
  const closeModal = () => setModalOpen(false);

    return (
        <>
            <Stack direction={"row"} alignItems={"center"} gap={1}>
              <Button size="small" variant="contained" startIcon={<PackagePlusIcon />} onClick={openModal} >
                Registrar nueva categoría
              </Button>
              <PackagingForm isOpen={isModalOpen} onClose={closeModal} />
            </Stack>
        </>
    )
}

const Desktop = () => {
    return (
        <>
            <Stack direction={'row'} gap={1} >
                <DesktopRegisterPackagingButton />
                <Button variant="contained" disableElevation size="small" startIcon={<FileUp />} >
                    Importar embalajes
                </Button>
                <Button variant="contained" disableElevation size="small" startIcon={<FileDown />} >
                    Exportar embalajes
                </Button>
            </Stack>
        </>
    )
}

export default Desktop