import { FileDown, FileUp, PackagePlusIcon } from "lucide-react"
import { ReactNode, useMemo } from "react"

interface ListProps {
    id: number,
    name: string,
    icon: ReactNode,
    onClick: () => void
}

export const useMenuListPackaging= () => {

    const list = useMemo(() => {
        const data:ListProps[] = [
            { name: "Registrar nuevo embalaje", icon: <PackagePlusIcon />, onClick: () => null },
            { name: "Importar embalajes", icon: <FileUp />, onClick: () => null },
            { name: "Exportar embalajes", icon: <FileDown />, onClick: () => null },
        ].map((item, index) => ({...item, id: (index+1)}))
        return data
    }, [])

    return { list }
}