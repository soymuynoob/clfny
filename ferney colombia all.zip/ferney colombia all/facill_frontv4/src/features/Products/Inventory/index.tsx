import {  Stack, Box } from "@mui/material";
import {  Package } from "lucide-react";
import CardWrapper from "@component/CardWrapper";
import InventoryOption from "./components/InventoryOption";
import CustomizedDataGrid from "@component/CustomizedDataGrid";
import FilterButton from "@component/FilterButton";
import FilterContent from "./components/InventoryForm/FilterContent";
import { useRef, useState, useEffect } from "react";
import Wrapper from "./components/InventoryForm/components/Wrapper";
import { useBreakpoints } from "@hook/useBreakpoints";
import { SummaryResults } from "./components/inventorySummary";

const Inventory = () => {
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const filterButtonRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        isFilterOpen &&
        filterButtonRef.current &&
        !filterButtonRef.current.contains(event.target as Node) &&
        !(event.target as HTMLElement).closest(".MuiSlide-root") &&
        !(event.target as HTMLElement).closest(".MuiSelect-root") &&
        !(event.target as HTMLElement).closest(".MuiMenuItem-root")
      ) {
        setIsFilterOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [isFilterOpen]);
  const { isDownSmall } = useBreakpoints();

  return (
    <Box ref={containerRef}>
      <CardWrapper icon={<Package />} title="Inventario">
        <Stack direction="row" sx={{ width: "100%" }}>
          <Stack direction="column" gap={1} sx={{ width: { xs: '100%', md: isFilterOpen ? "calc(100% - 300px)" : "100%" } }}>
            <Stack direction="row" gap={1} justifyContent="space-between">
              <InventoryOption setIsFilterOpen={setIsFilterOpen} isFilterOpen={isFilterOpen} />
              
            </Stack>
            <SummaryResults />
            <Stack direction="row" gap={1}>
              <CustomizedDataGrid
                columns={[
                  { field: "_", headerName: "Nombre" },
                  { field: "__", headerName: "Stock" },
                  { field: "___", headerName: "Costo" },
                  { field: "____", headerName: "Precio de venta" },
                  { field: "_____", headerName: "Ganancia" },
                  { field: "______", headerName: "Margen" },
                  { field: "_______", headerName: "Código de barras" },
                  { field: "________", headerName: "Código de SKU" },
                  { field: "_________", headerName: "Consecutivo" },
                ]}
              />
            </Stack>
          </Stack>
        </Stack>
      </CardWrapper>
      {isDownSmall ? (
        <Wrapper isOpen={isFilterOpen} onClose={() => setIsFilterOpen(false)}>
          <FilterContent />
        </Wrapper>
      ) : (
        isFilterOpen && (
          <Box ref={filterButtonRef}>
            <FilterButton
              content={<FilterContent />}
              isOpen={isFilterOpen}
              onClose={() => setIsFilterOpen(false)}
              containerRef={containerRef}
            />
          </Box>
        )
      )}
    </Box>
  );
};

export default Inventory;
