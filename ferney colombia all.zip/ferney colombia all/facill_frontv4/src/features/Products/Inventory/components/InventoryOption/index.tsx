import { useBreakpoints } from "@hook/useBreakpoints"
import Desktop, { DesktopRegisterProductButton } from "./components/Desktop"
import Mobile from "./components/Mobile"
import { useMenuListProduct } from "./hooks/useMenuListProduct"
import { useMemo } from "react"
import { Button, Stack } from "@mui/material"
import { ListFilter } from "lucide-react"

const InventoryOption = ({setIsFilterOpen, isFilterOpen}:{setIsFilterOpen: (value: boolean) => void, isFilterOpen: boolean}) => {
    const { list } = useMenuListProduct()
    const mobileList = useMemo(() => list.filter((item) => item.id !== 1 ), [list])
    const { isDownSmall } = useBreakpoints()

    if (isDownSmall) {
        return (
            <Stack justifyContent={'space-between'} direction={'row'} sx={{ width: '100%' }}>
                <DesktopRegisterProductButton />
                <Stack direction={'row'} gap={1} sx={{alignItems: 'center'}}>
                    <Mobile list={mobileList} />
                    <Button variant="outlined" size="small" onClick={() => setIsFilterOpen(!isFilterOpen)} sx={{ minWidth: 0, padding: '6px' }} >
                        <ListFilter />
                    </Button>
                </Stack>
            </Stack>
        )
    }else{
        return(
            <>
                <Desktop />
                <Button variant="outlined" size="small" onClick={() => setIsFilterOpen(!isFilterOpen)} sx={{ minWidth: 0, padding: '6px' }} >
                    <ListFilter />
                </Button>
            </>
        )
    }
}

export default InventoryOption