import React from "react";
import {
  TextField,
  Select,
  MenuItem,
  InputLabel,
  FormControl,
  Typography,
  Chip,
  OutlinedInput,
  SelectChangeEvent,
  Button,
} from "@mui/material";
import { Grid } from "@component/UI";
import { NumericFormat } from "react-number-format";
import { ArrowDropDown } from "@mui/icons-material";
import Wrapper from "./components/Wrapper";

interface Props {
  isOpen?: boolean,
  onClose?: () => void
}

const ProductForm: React.FC<Props> = (props) => {
  const { isOpen, onClose } = props
  const [selectedChips, setSelectedChips] = React.useState<string[]>([]);
  const [formValues, setFormValues] = React.useState({
    nombre: "",
    stock: "",
    costo: "",
    etiquetaPrecio: "",
    precios: [{ precioVenta: "", ganancia: "", margen: "" }],
  });
  const [errors, setErrors] = React.useState<any>({});

  const handleChange = (
    event: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = event.target;
    setFormValues({ ...formValues, [name]: value });
  };

  const handlePriceChange = (index: number, name: string, value: string) => {
    const updatedPrices: any = [...formValues.precios];
    updatedPrices[index][name] = value;
    setFormValues({ ...formValues, precios: updatedPrices });

    calculateValues(updatedPrices, index);
  };

  const calculateValues = (prices: any[], index: number) => {
    const costo = Number(formValues.costo);
    const currentPrice = Number(prices[index].precioVenta);

    if (costo) {
      if (currentPrice) {
        const ganancia = currentPrice - costo;
        const margen = (ganancia / currentPrice) * 100;

        prices[index].ganancia = ganancia.toFixed(2).toString();
        prices[index].margen = margen.toFixed(2).toString();
      }
    }

    setFormValues({ ...formValues, precios: prices });
  };

  const validateForm = () => {
    const newErrors: any = {};
    if (!formValues.nombre) {
      newErrors.nombre = "El campo Nombre es requerido.";
    }
    if (formValues.stock && Number(formValues.stock) < 0) {
      newErrors.stock = "El Stock no puede ser negativo.";
    }
    if (formValues.costo && Number(formValues.costo) < 0) {
      newErrors.costo = "El Costo no puede ser negativo.";
    }
    if (!formValues.etiquetaPrecio) {
      newErrors.etiquetaPrecio = "La Etiqueta de precio es requerida.";
    }
    for (let price of formValues.precios) {
      if (price.precioVenta && Number(price.precioVenta) < 0) {
        newErrors.precioVenta = "El Precio de venta no puede ser negativo.";
      }
      if (price.ganancia && Number(price.ganancia) < 0) {
        newErrors.ganancia = "La Ganancia no puede ser negativa.";
      }
      if (
        price.margen &&
        (Number(price.margen) < 0 || Number(price.margen) > 100)
      ) {
        newErrors.margen = "El Margen debe estar entre 0 y 100%.";
      }
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0; // Return true if no errors
  };

  const handleChipChange = (event: SelectChangeEvent<string[]>) => {
    const value = event.target.value as string[];
    setSelectedChips(value);
  };

  const handleDeleteChip = (chipToDelete: string) => () => {
    setSelectedChips((chips) => chips.filter((chip) => chip !== chipToDelete));
  };

  return (
    <Wrapper isOpen={isOpen} onClose={onClose} >
      <Grid container spacing={1.5}>
        <Grid size={12}>
        <Typography variant="subtitle2">Información de Producto:</Typography>
      </Grid>

      <Grid size={12}>
        <TextField
          name="nombre"
          label="Nombre"
          variant="outlined"
          fullWidth
          value={formValues.nombre}
          onChange={handleChange}
          error={!!errors.nombre}
          helperText={errors.nombre}
        />
      </Grid>

      <Grid size={{ xs: 12, sm: 6 }}>
        <FormControl variant="outlined" fullWidth>
          <InputLabel>Categoría</InputLabel>
          <Select
            label="Categoría"
            IconComponent={ArrowDropDown}
            input={<OutlinedInput label="Categoría" />}
          >
            <MenuItem value={1}>Categoría 1</MenuItem>
            <MenuItem value={2}>Categoría 2</MenuItem>
          </Select>
        </FormControl>
      </Grid>

      <Grid size={{ xs: 12, sm: 6 }}>
        <FormControl variant="outlined" fullWidth>
          <InputLabel>Embalaje de Compra</InputLabel>
          <Select
            label="Embalaje de Compra"
            IconComponent={ArrowDropDown}
            input={<OutlinedInput label="Embalaje de Compra" />}
          >
            <MenuItem value={1}>Embalaje 1</MenuItem>
            <MenuItem value={2}>Embalaje 2</MenuItem>
          </Select>
        </FormControl>
      </Grid>

      <Grid size={12}>
        <FormControl variant="outlined" fullWidth>
          <InputLabel>Proveedor</InputLabel>
          <Select
            label="Proveedor"
            IconComponent={ArrowDropDown}
            input={<OutlinedInput label="Proveedor" />}
          >
            <MenuItem value={1}>Proveedor 1</MenuItem>
            <MenuItem value={2}>Proveedor 2</MenuItem>
          </Select>
        </FormControl>
      </Grid>

      <Grid size={{ xs: 12, sm: 4 }}>
        <TextField
          name="stock"
          label="Stock"
          variant="outlined"
          fullWidth
          value={formValues.stock}
          onChange={handleChange}
          error={!!errors.stock}
          helperText={errors.stock}
        />
      </Grid>

      <Grid size={{ xs: 12, sm: 4 }}>
        <TextField label="Alerta Stock Bajo" variant="outlined" fullWidth />
      </Grid>

      <Grid size={{ xs: 12, sm: 4 }}>
        <TextField label="Código SKU" variant="outlined" fullWidth />
      </Grid>

      <Grid size={{ xs: 12, sm: 6 }}>
        <TextField label="Código de Barras" variant="outlined" fullWidth />
      </Grid>

      <Grid size={{ xs: 12, sm: 6 }}>
        <FormControl variant="outlined" fullWidth>
          <InputLabel>Impuestos</InputLabel>
          <Select
            label="Impuestos"
            IconComponent={ArrowDropDown}
            input={<OutlinedInput label="Impuestos" />}
          >
            <MenuItem value={1}>Impuesto 1</MenuItem>
            <MenuItem value={2}>Impuesto 2</MenuItem>
          </Select>
        </FormControl>
      </Grid>

      <Grid size={12}>
        <FormControl variant="outlined" fullWidth>
          <InputLabel>Habilitar en</InputLabel>
          <Select
            multiple
            value={selectedChips}
            onChange={handleChipChange}
            input={<OutlinedInput label="Habilitar en" />}
            IconComponent={ArrowDropDown}
            renderValue={(selected) => (
              <div>
                {selected.map((value) => (
                  <Chip
                    color="primary"
                    style={{ marginLeft: 5 }}
                    key={value}
                    size="small"
                    label={value}
                    onDelete={handleDeleteChip(value)}
                  />
                ))}
              </div>
            )}
          >
            <MenuItem value="Opción 1">Opción 1</MenuItem>
            <MenuItem value="Opción 2">Opción 2</MenuItem>
            <MenuItem value="Opción 3">Opción 3</MenuItem>
          </Select>
        </FormControl>
      </Grid>
      <Grid size={12}>
        <Typography variant="subtitle2">Información de Precios:</Typography>
      </Grid>
      <Grid size={12}>
        <NumericFormat
          name="costo"
          label="Costo"
          variant="outlined"
          fullWidth
          customInput={TextField}
          value={formValues.costo}
          onValueChange={({ value }) => {
            setFormValues({ ...formValues, costo: value });
            calculateValues(formValues.precios, 0);
          }}
          thousandSeparator
          decimalScale={2}
          fixedDecimalScale
          prefix="$ "
          error={!!errors.costo}
          helperText={errors.costo}
        />
      </Grid>
      {formValues.precios.map((price, index) => (
        <Grid container spacing={2} key={index} >
        <Grid size={{ xs: 12, md: 3 }}>
          <TextField
            name="etiquetaPrecio"
            label="Etiqueta de precio"
            variant="outlined"
            fullWidth
            value={formValues.etiquetaPrecio}
            onChange={handleChange}
            error={!!errors.etiquetaPrecio}
            helperText={errors.etiquetaPrecio}
          />
        </Grid>
          <Grid size={{ xs: 12, md: 3 }}>
            <NumericFormat
              label={`Precio de venta ${index + 1}`}
              variant="outlined"
              fullWidth
              customInput={TextField}
              value={price.precioVenta}
              onValueChange={({ value }) =>
                handlePriceChange(index, "precioVenta", value)
              }
              thousandSeparator
              prefix="$ "
              decimalScale={2}
              fixedDecimalScale
            />
          </Grid>
          <Grid size={{ xs: 12, md: 3 }}>
            <NumericFormat
              label="Ganancia"
              variant="outlined"
              fullWidth
              prefix="$ "
              customInput={TextField}
              value={price.ganancia}
              onValueChange={({ value }) =>
                handlePriceChange(index, "ganancia", value)
              }
              thousandSeparator
              decimalScale={2}
              fixedDecimalScale
            />
          </Grid>
          <Grid size={{ xs: 12, md: 3 }}>
            <NumericFormat
              label="Margen (%)"
              variant="outlined"
              fullWidth
              customInput={TextField}
              value={price.margen}
              onValueChange={({ value }) =>
                handlePriceChange(index, "margen", value)
              }
              decimalScale={2}
              fixedDecimalScale
              suffix=" %"
            />
          </Grid>
          <Grid size={12} >
            <Button variant="contained" fullWidth size="large" >
              Guardar
            </Button>
          </Grid>     
        </Grid>
        ))}
      </Grid>
    </Wrapper>
  );
};

export default ProductForm;
