import { Button, Stack } from "@mui/material"
import { FileDown, FileUp, Package } from "lucide-react"
import { useState } from "react"
import ProductForm from "../../InventoryForm/ProductForm";

export const DesktopRegisterProductButton = () => {
  const [isModalOpen, setModalOpen] = useState<boolean>(false);

  const openModal = () => setModalOpen(true);
  const closeModal = () => setModalOpen(false);

    return (
        <>
            <Stack direction={"row"} alignItems={"center"} gap={1}>
              <Button size="small" variant="contained" startIcon={<Package />} onClick={openModal} >
                Registrar producto
              </Button>
              <ProductForm isOpen={isModalOpen} onClose={closeModal} />
            </Stack>
        </>
    )
}

const Desktop = () => {
    return (
        <Stack>
        <Stack direction={'row'} gap={1} >
            <DesktopRegisterProductButton />
                <Button variant="outlined" disableElevation size="small" startIcon={<FileUp />} >
                    Importar Productos
                </Button>
                <Button variant="outlined" disableElevation size="small" startIcon={<FileDown />} >
                    Exportar Productos
                </Button>
        </Stack>
        

        </Stack>
    )
}

export default Desktop