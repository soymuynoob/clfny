import React, { ReactNode, useState } from 'react';
import { Button, FormControl, InputLabel, MenuItem, Select, SelectChangeEvent, Stack } from '@mui/material';

interface FilterOptions {
  mostrarProducto: string;
  categoria: string;
  proveedor: string;
  agruparPor: string;
}

const FilterContent: React.FC = () => {
  const [filterOptions, setFilterOptions] = useState<FilterOptions>({
    mostrarProducto: '',
    categoria: '',
    proveedor: '',
    agruparPor: '',
  });

  const handleChange = (event: SelectChangeEvent<string>) => {
    const name = event.target.name as keyof FilterOptions;
    setFilterOptions({
      ...filterOptions,
      [name]: event.target.value as string,
    });
  };

  const handleLimpiar = () => {
    setFilterOptions({
      mostrarProducto: '',
      categoria: '',
      proveedor: '',
      agruparPor: '',
    });
  };

  const handleFiltrar = () => {
    // Aquí puedes implementar la lógica para aplicar los filtros
    console.log('Filtros aplicados:', filterOptions);
  };

  return (
    
      <Stack spacing={2} mt={5}>
        <FormControl fullWidth>
          <InputLabel>Mostrar Producto</InputLabel>
          <Select
            name="mostrarProducto"
            value={filterOptions.mostrarProducto}
            onChange={(event: SelectChangeEvent<string>, child: ReactNode) => handleChange(event as any)}
          >
            <MenuItem value="todos">Todos</MenuItem>
            <MenuItem value="activos">Activos</MenuItem>
            <MenuItem value="inactivos">Inactivos</MenuItem>
          </Select>
        </FormControl>

        <FormControl fullWidth>
          <InputLabel>Categorías</InputLabel>
          <Select
            name="categoria"
            value={filterOptions.categoria}
            onChange={(event: SelectChangeEvent<string>, child: ReactNode) => handleChange(event as any)}
          >
            <MenuItem value="categoria1">Categoría 1</MenuItem>
            <MenuItem value="categoria2">Categoría 2</MenuItem>
            <MenuItem value="categoria3">Categoría 3</MenuItem>
          </Select>
        </FormControl>

        <FormControl fullWidth>
          <InputLabel>Proveedores</InputLabel>
          <Select
            name="proveedor"
            value={filterOptions.proveedor}
            onChange={(event: SelectChangeEvent<string>, child: ReactNode) => handleChange(event as any)}
          >
            <MenuItem value="proveedor1">Proveedor 1</MenuItem>
            <MenuItem value="proveedor2">Proveedor 2</MenuItem>
            <MenuItem value="proveedor3">Proveedor 3</MenuItem>
          </Select>
        </FormControl>

        <FormControl fullWidth>
          <InputLabel>Agrupar Por</InputLabel>
          <Select
            name="agruparPor"
            value={filterOptions.agruparPor}
            onChange={(event: SelectChangeEvent<string>, child: ReactNode) => handleChange(event as any)}
          >
            <MenuItem value="categoria">Categoría</MenuItem>
            <MenuItem value="proveedor">Proveedor</MenuItem>
            <MenuItem value="estado">Estado</MenuItem>
          </Select>
        </FormControl>

        <Stack direction="row" spacing={2} justifyContent={'space-between'}>
          <Button variant="outlined" onClick={handleLimpiar}>
            Restablecer
          </Button>
          <Button variant="contained" onClick={handleFiltrar}>
            Filtrar
          </Button>
        </Stack>
      </Stack>
    
  );
};

export default FilterContent;
