import { FileDown, FileUp, Package } from "lucide-react"
import { ReactNode, useMemo } from "react"

interface ListProps {
    id: number,
    name: string,
    icon: ReactNode,
    onClick: () => void
}

export const useMenuListProduct= () => {

    const list = useMemo(() => {
        const data:ListProps[] = [
            { name: "Registrar nuevo producto", icon: <Package />, onClick: () => null },
            { name: "Importar productos", icon: <FileUp />, onClick: () => null },
            { name: "Exportar productos", icon: <FileDown />, onClick: () => null },
        ].map((item, index) => ({...item, id: (index+1)}))
        return data
    }, [])

    return { list }
}