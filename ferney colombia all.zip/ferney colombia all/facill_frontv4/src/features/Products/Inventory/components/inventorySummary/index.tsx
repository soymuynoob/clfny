import { Grid } from "@component/UI";
import { Card, CardContent, Stack, Typography } from "@mui/material";

export const SummaryResults = () => {
  return (
    <Grid size={12}>
      <Stack gap={1} fontSize={".800rem"} direction={"row"}>
        <Stack direction={"row"}>
          <Card variant="outlined" sx={{ minWidth: 200 }} style={{alignSelf: 'center', paddingBottom: 7}}>
            <CardContent>
              <Typography variant="caption"> Costo total del inventario </Typography>
              <Typography variant="subtitle2"> $ 300.000 </Typography>
            </CardContent>
          </Card>
        </Stack>
        <Stack direction={"row"}>
          <Card variant="outlined" sx={{ minWidth: 200 }} style={{alignSelf: 'center', paddingBottom: 7}}>
            <CardContent>
              <Typography variant="caption"> Productos simples inventariados </Typography>
              <Typography variant="subtitle2"> $ 300.000 </Typography>
            </CardContent>
          </Card>
        </Stack>
        <Stack direction={"row"}>
          <Card variant="outlined" sx={{ minWidth: 200 }} style={{alignSelf: 'center', paddingBottom: 7}}>
            <CardContent>
              <Typography variant="caption"> Productos compuestos inventariados </Typography>
              <Typography variant="subtitle2"> $ 300.000 </Typography>
            </CardContent>
          </Card>
        </Stack>
      </Stack>
    </Grid>
  );
};
