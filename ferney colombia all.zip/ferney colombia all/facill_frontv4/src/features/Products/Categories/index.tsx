import { Grid } from "@component/UI";
import { Typography } from "@mui/material";
import { Package } from "lucide-react";
import CardWrapper from "@component/CardWrapper";
import CustomizedDataGrid from "@component/CustomizedDataGrid";
import CategoryOption from "./components/CategoriesOption";

const Categories = () => {
  return (
    <CardWrapper icon={<Package />} title="Categorías">
      <Grid container spacing={1}>
        <Grid size={9}>
          <Typography mb={1} variant="subtitle2">
            Categorías:
          </Typography>
        </Grid>
        <Grid size={12}>
          <CategoryOption />
        </Grid>

        <Grid size={12}>
          <CustomizedDataGrid
            columns={[
              { field: "_", headerName: "Nombre" },
              { field: "__", headerName: "Descripción" },
            ]}
          />
        </Grid>
      </Grid>
    </CardWrapper>
  );
};

export default Categories;
