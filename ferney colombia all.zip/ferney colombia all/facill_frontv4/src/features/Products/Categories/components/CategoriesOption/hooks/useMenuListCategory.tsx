import { FileDown, FileUp, PackagePlusIcon } from "lucide-react"
import { ReactNode, useMemo } from "react"

interface ListProps {
    id: number,
    name: string,
    icon: ReactNode,
    onClick: () => void
}

export const useMenuListCategory= () => {

    const list = useMemo(() => {
        const data:ListProps[] = [
            { name: "Registrar nueva categoría", icon: <PackagePlusIcon />, onClick: () => null },
            { name: "Importar categorías", icon: <FileUp />, onClick: () => null },
            { name: "Exportar categorías", icon: <FileDown />, onClick: () => null },
        ].map((item, index) => ({...item, id: (index+1)}))
        return data
    }, [])

    return { list }
}