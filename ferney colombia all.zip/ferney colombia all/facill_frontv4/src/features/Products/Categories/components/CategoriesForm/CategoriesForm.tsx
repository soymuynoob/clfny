import React from "react";
import { Button, TextField, Typography } from "@mui/material";
import { Grid } from "@component/UI";
import Wrapper from "./components/Wrapper";

interface Props {
  isOpen?: boolean;
  onClose?: () => void;
}

const CategoryForm: React.FC<Props> = (props) => {
  const { isOpen, onClose } = props;
  const [formValues, setFormValues] = React.useState({
    nombre: "",
    descripcion: "",
  });
  const [errors, setErrors] = React.useState<any>({});

  const handleChange = (
    event: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = event.target;
    setFormValues({ ...formValues, [name]: value });
  };

  const validateForm = () => {
    const newErrors: any = {};
    if (!formValues.nombre) {
      newErrors.nombre = "El campo Nombre es requerido.";
    }
    // if (formValues.descripcion && Number(formValues.descripcion) < 0) {
    //   newErrors.stock = "El campo Descripción no puede ser vacio";
    // }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0; // Return true if no errors
  };

  return (
    <Wrapper isOpen={isOpen} onClose={onClose}>
      <Grid container spacing={1.5}>
        <Grid size={12}>
          <Typography variant="subtitle2">Información de Categoria:</Typography>
        </Grid>

        <Grid size={12}>
          <TextField
            name="nombre"
            label="Nombre"
            variant="outlined"
            fullWidth
            value={formValues.nombre}
            onChange={handleChange}
            error={!!errors.nombre}
            helperText={errors.nombre}
          />
        </Grid>
        <Grid size={12}>
          <TextField
            fullWidth
            multiline
            rows={3}
            label="Descripción"
            value={formValues.descripcion}
            onChange={handleChange}
            error={!!errors.descripcion}
            helperText={errors.descripcion}
          />
        </Grid>
        <Grid size={12}>
          <Button variant="contained" fullWidth size="large">
            Guardar
          </Button>
        </Grid>
      </Grid>
    </Wrapper>
  );
};

export default CategoryForm;
