import { Grid } from "@component/UI";
import CardWrapper from "@component/CardWrapper";
import CustomizedDataGrid from "@component/CustomizedDataGrid";
import SuppliersOption from "./components/SuppliersOption";
import { Users } from "lucide-react";
const Suppliers = () => {
  return (
    <CardWrapper icon={<Users />} title="Proveedores">
      <Grid container spacing={1}>
        <Grid size={12}>
          <SuppliersOption />
        </Grid>

        <Grid size={12}>
          <CustomizedDataGrid
            columns={[
              { field: "proveedor", headerName: "Proveedor" },
              { field: "representante", headerName: "Representante" },
              { field: "nit", headerName: "NIT" },
              { field: "codigoProveedor", headerName: "Código de proveedor" },
              { field: "ciudad", headerName: "Ciudad" },
              { field: "direccion", headerName: "Dirección" },
              { field: "telefono", headerName: "Teléfono" },
              { field: "impuestos", headerName: "Impuestos" },
              { field: "banco", headerName: "Banco" },
              { field: "tipoCuenta", headerName: "Tipo de cuenta" },
              { field: "numeroCuenta", headerName: "Número de cuenta" },
              { field: "numeroAcuerdo", headerName: "Número de acuerdo" },
            ]}
          />
        </Grid>
      </Grid>
    </CardWrapper>
  );
};

export default Suppliers;
