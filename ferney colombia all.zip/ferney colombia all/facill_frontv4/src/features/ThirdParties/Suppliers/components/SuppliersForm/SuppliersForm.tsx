import React from "react";
import {
  Button,
  FormControl,
  FormHelperText,
  InputLabel,
  MenuItem,
  Select,
  TextField,
  Typography,
} from "@mui/material";
import { Grid } from "@component/UI";
import Wrapper from "./components/Wrapper";

interface Props {
  isOpen?: boolean;
  onClose?: () => void;
}

const SuppliersForm: React.FC<Props> = (props) => {
  const { isOpen, onClose } = props;

  const [formValues, setFormValues] = React.useState({
    supplier: "",
    representative: "",
    nit: "",
    supplierCode: "",
    city: "",
    address: "",
    phone: "",
    taxes: "",
    bank: "",
    accountType: "",
    accountNumber: "",
    agreementNumber: ""
  });
  const [errors, setErrors] = React.useState<any>({});

  const handleChange = (
    event: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = event.target;
    setFormValues({ ...formValues, [name]: value });
  };

  const validateForm = () => {
    const newErrors: any = {};
    if (!formValues.supplier) {
      newErrors.supplier = "El campo Proveedor es requerido.";
    }
    if (!formValues.representative) {
      newErrors.representative = "El campo Representante es requerido.";
    }
    if (!formValues.nit) {
      newErrors.nit = "El campo NIT es requerido.";
    }
    if (!formValues.supplierCode) {
      newErrors.supplierCode = "El campo Código de proveedor es requerido.";
    }
    if (!formValues.city) {
      newErrors.city = "El campo Ciudad es requerido.";
    }
    if (!formValues.address) {
      newErrors.address = "El campo Dirección es requerido.";
    }
    if (!formValues.phone) {
      newErrors.phone = "El campo Teléfono es requerido.";
    }
    if (!formValues.taxes) {
      newErrors.taxes = "El campo Impuestos es requerido.";
    }
    if (!formValues.bank) {
      newErrors.bank = "El campo Banco es requerido.";
    }
    if (!formValues.accountType) {
      newErrors.accountType = "El campo Tipo de cuenta es requerido.";
    }
    if (!formValues.accountNumber) {
      newErrors.accountNumber = "El campo Número de cuenta es requerido.";
    }
    if (!formValues.agreementNumber) {
      newErrors.agreementNumber = "El campo Número de acuerdo es requerido.";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0; // Return true if no errors
  };

  return (
    <Wrapper isOpen={isOpen} onClose={onClose}>
      <Grid container spacing={1.5}>
        <Grid size={12}>
          <Typography variant="subtitle2">
            Información de Proveedor:
          </Typography>
        </Grid>
        <Grid container spacing={2}>
          <Grid size={6}>
            <TextField
              name="supplier"
              label="Proveedor"
              variant="outlined"
              fullWidth
              value={formValues.supplier}
              onChange={handleChange}
              error={!!errors.supplier}
              helperText={errors.supplier}
            />
          </Grid>
          <Grid size={6}>
            <TextField
              name="representative"
              label="Representante"
              variant="outlined"
              fullWidth
              value={formValues.representative}
              onChange={handleChange}
              error={!!errors.representative}
              helperText={errors.representative}
            />
          </Grid>
          <Grid size={6}>
            <TextField
              name="nit"
              label="NIT"
              variant="outlined"
              fullWidth
              value={formValues.nit}
              onChange={handleChange}
              error={!!errors.nit}
              helperText={errors.nit}
            />
          </Grid>
          <Grid size={6}>
            <TextField
              name="supplierCode"
              label="Código de proveedor"
              variant="outlined"
              fullWidth
              value={formValues.supplierCode}
              onChange={handleChange}
              error={!!errors.supplierCode}
              helperText={errors.supplierCode}
            />
          </Grid>
          <Grid size={6}>
            <TextField
              name="city"
              label="Ciudad"
              variant="outlined"
              fullWidth
              value={formValues.city}
              onChange={handleChange}
              error={!!errors.city}
              helperText={errors.city}
            />
          </Grid>
          <Grid size={6}>
            <TextField
              name="address"
              label="Dirección"
              variant="outlined"
              fullWidth
              value={formValues.address}
              onChange={handleChange}
              error={!!errors.address}
              helperText={errors.address}
            />
          </Grid>
          <Grid size={6}>
            <TextField
              name="phone"
              label="Teléfono"
              variant="outlined"
              fullWidth
              value={formValues.phone}
              onChange={handleChange}
              error={!!errors.phone}
              helperText={errors.phone}
            />
          </Grid>
          <Grid size={6}>
            <FormControl fullWidth variant="outlined" error={!!errors.taxes}>
              <InputLabel id="taxes-label">Impuestos</InputLabel>
              <Select
                labelId="taxes-label"
                name="taxes"
                value={formValues.taxes}
                // onChange={handleChange}
                label="Impuestos"
              >
                <MenuItem value="IVA">IVA</MenuItem>
                <MenuItem value="ICA">ICA</MenuItem>
                <MenuItem value="Retefuente">Retefuente</MenuItem>
              </Select>
              {errors.taxes && <FormHelperText>{errors.taxes}</FormHelperText>}
            </FormControl>
          </Grid>
          <Grid size={6}>
            <TextField
              name="bank"
              label="Banco"
              variant="outlined"
              fullWidth
              value={formValues.bank}
              onChange={handleChange}
              error={!!errors.bank}
              helperText={errors.bank}
            />
          </Grid>
          <Grid size={6}>
            <TextField
              name="accountType"
              label="Tipo de cuenta"
              variant="outlined"
              fullWidth
              value={formValues.accountType}
              onChange={handleChange}
              error={!!errors.accountType}
              helperText={errors.accountType}
            />
          </Grid>
          <Grid size={6}>
            <TextField
              name="accountNumber"
              label="Número de cuenta"
              variant="outlined"
              fullWidth
              value={formValues.accountNumber}
              onChange={handleChange}
              error={!!errors.accountNumber}
              helperText={errors.accountNumber}
            />
          </Grid>
          <Grid size={6}>
            <TextField
              name="agreementNumber"
              label="Número de acuerdo"
              variant="outlined"
              fullWidth
              value={formValues.agreementNumber}
              onChange={handleChange}
              error={!!errors.agreementNumber}
              helperText={errors.agreementNumber}
            />
          </Grid>
        </Grid>

        <Grid size={12}>
          <Button variant="contained" fullWidth size="large">
            Guardar
          </Button>
        </Grid>
      </Grid>
    </Wrapper>
  );
};

export default SuppliersForm;
