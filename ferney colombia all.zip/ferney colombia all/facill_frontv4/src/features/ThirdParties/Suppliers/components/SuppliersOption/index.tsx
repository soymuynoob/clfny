import { useBreakpoints } from "@hook/useBreakpoints";
import Mobile from "./components/Mobile";
import { useMemo } from "react";
import { Stack } from "@mui/material";
import { useMenuListSuppliers } from "./hooks/useMenuListSuppliers";
import Desktop, { DesktopRegisterSuppliersButton } from "./components/Desktop";

const SuppliersOption = () => {
  const { list } = useMenuListSuppliers();
  const mobileList = useMemo(
    () => list.filter((item: any) => item.id !== 1),
    [list]
  );

  const { isDownSmall } = useBreakpoints();

  if (isDownSmall) {
    return (
      <Stack justifyContent={"space-between"} direction={"row"}>
        <DesktopRegisterSuppliersButton />
        <Mobile list={mobileList} />
      </Stack>
    );
  } else {
    return (
      <>
        <Desktop />
      </>
    );
  }
};

export default SuppliersOption;
