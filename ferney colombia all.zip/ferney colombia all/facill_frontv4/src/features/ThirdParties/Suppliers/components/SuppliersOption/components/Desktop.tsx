import { Button, Stack } from "@mui/material";
import { useState } from "react";
import SuppliersForm from "../../SuppliersForm/SuppliersForm";
import { UserRoundPlus } from "lucide-react";

export const DesktopRegisterSuppliersButton = () => {
  const [isModalOpen, setModalOpen] = useState<boolean>(false);

  const openModal = () => setModalOpen(true);
  const closeModal = () => setModalOpen(false);

  return (
    <>
      <Stack direction={"row"} alignItems={"center"} gap={1}>
        <Button
          size="small"
          variant="contained"
          startIcon={<UserRoundPlus />}
          onClick={openModal}
        >
          Registrar proveedor
        </Button>
        <SuppliersForm isOpen={isModalOpen} onClose={closeModal} />
      </Stack>
    </>
  );
};

const Desktop = () => {
  return (
    <>
      <Stack direction={"row"} gap={1}>
        <DesktopRegisterSuppliersButton />
      </Stack>
    </>
  );
};

export default Desktop;
