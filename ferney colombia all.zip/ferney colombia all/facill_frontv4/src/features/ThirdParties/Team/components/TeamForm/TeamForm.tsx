import React from "react";
import {
  Button,
  TextField,
  Typography,
} from "@mui/material";
import { Grid } from "@component/UI";
import Wrapper from "./components/Wrapper";

interface Props {
  isOpen?: boolean;
  onClose?: () => void;
}

const TeamForm: React.FC<Props> = (props) => {
  const { isOpen, onClose } = props;

  const [formValues, setFormValues] = React.useState({
    name: "",
    email: "",
    lastName: "",
    phone: "",
  });
  const [errors, setErrors] = React.useState<any>({});

  const handleChange = (
    event: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = event.target;
    setFormValues({ ...formValues, [name]: value });
  };

  const validateForm = () => {
    const newErrors: any = {};
    if (!formValues.name) {
      newErrors.name = "El campo Nombre es requerido.";
    }
    if (!formValues.email) {
      newErrors.email = "El campo Correo electrónico es requerido.";
    }
    if (!formValues.lastName) {
      newErrors.lastName = "El campo Apellido es requerido.";
    }
    if (!formValues.phone) {
      newErrors.phone = "El campo Teléfono es requerido.";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0; // Return true if no errors
  };

  return (
    <Wrapper isOpen={isOpen} onClose={onClose}>
      <Grid container spacing={1.5}>
        <Grid size={12}>
          <Typography variant="subtitle2">
            Información de Equipo:
          </Typography>
        </Grid>
        <Grid container spacing={2}>
          <Grid size={6}>
            <TextField
              name="name"
              label="Nombres"
              variant="outlined"
              fullWidth
              value={formValues.name}
              onChange={handleChange}
              error={!!errors.name}
              helperText={errors.name}
            />
          </Grid>
          <Grid size={6}>
            <TextField
              name="lastName"
              label="Apellidos"
              variant="outlined"
              fullWidth
              value={formValues.lastName}
              onChange={handleChange}
              error={!!errors.lastName}
              helperText={errors.lastName}
            />
          </Grid>
          <Grid size={6}>
            <TextField
              name="email"
              label="Correo electrónico"
              variant="outlined"
              fullWidth
              value={formValues.email}
              onChange={handleChange}
              error={!!errors.email}
              helperText={errors.email}
            />
          </Grid>
          <Grid size={6}>
            <TextField
              name="phone"
              label="Teléfono"
              variant="outlined"
              fullWidth
              value={formValues.phone}
              onChange={handleChange}
              error={!!errors.phone}
              helperText={errors.phone}
            />
          </Grid>
        </Grid>

        <Grid size={12}>
          <Button variant="contained" fullWidth size="large">
            Guardar
          </Button>
        </Grid>
      </Grid>
    </Wrapper>
  );
};

export default TeamForm;
