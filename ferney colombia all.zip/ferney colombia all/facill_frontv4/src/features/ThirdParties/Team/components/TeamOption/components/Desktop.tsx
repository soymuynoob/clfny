import { Button, Stack } from "@mui/material";
import TeamForm from "../../TeamForm/TeamForm";
import { UserRoundPlus } from "lucide-react";
import { useState } from "react";

export const DesktopRegisterTeamButton = () => {
  const [isModalOpen, setModalOpen] = useState<boolean>(false);

  const openModal = () => setModalOpen(true);
  const closeModal = () => setModalOpen(false);

  return (
    <>
      <Stack direction={"row"} alignItems={"center"} gap={1}>
        <Button
          size="small"
          variant="contained"
          startIcon={<UserRoundPlus />}
          onClick={openModal}
        >
          Registrar integrante
        </Button>
        <TeamForm isOpen={isModalOpen} onClose={closeModal} />
      </Stack>
    </>
  );
};

const Desktop = () => {
  return (
    <>
      <Stack direction={"row"} gap={1}>
        <DesktopRegisterTeamButton />
      </Stack>
    </>
  );
};

export default Desktop;
