import { Grid } from "@component/UI";
import CardWrapper from "@component/CardWrapper";
import CustomizedDataGrid from "@component/CustomizedDataGrid";
import TeamOption from "./components/TeamOption";
import { Users } from "lucide-react";
const Team = () => {
  return (
    <CardWrapper icon={<Users />} title="Equipo">
      <Grid container spacing={1}>
        <Grid size={12}>
          <TeamOption />
        </Grid>

        <Grid size={12}>
          <CustomizedDataGrid
            columns={[
              { field: "_", headerName: "Nombres" },
              { field: "__", headerName: "Apellidos" },
              { field: "___", headerName: "Email" },
              { field: "____", headerName: "Teléfono" },
              { field: "_____", headerName: "Estado" },
              { field: "______", headerName: "Última conexión" },
              { field: "_______", headerName: "Fecha de registro" },
            ]}
          />
        </Grid>
      </Grid>
    </CardWrapper>
  );
};

export default Team;
