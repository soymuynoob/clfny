import Modal from "@component/Modal"
import { useBreakpoints } from "@hook/useBreakpoints"
import { FC, ReactNode } from "react"

interface Props {
    children: ReactNode,
    isOpen?: boolean,
    onClose?: () => void
}

const Wrapper:FC<Props> = (props) => {
    const { children, isOpen=false, onClose } = props
    const { isDownSmall } = useBreakpoints()
    return(
        <Modal isOpen={isOpen} onClose={() => (onClose !== undefined) ? onClose() : undefined} title="Registrar domiciliario" fullScreen={isDownSmall} >
            {children}
        </Modal>
    )
}

export default Wrapper