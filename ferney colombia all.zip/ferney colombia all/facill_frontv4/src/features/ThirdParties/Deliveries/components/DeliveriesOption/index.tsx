import { useBreakpoints } from "@hook/useBreakpoints"
import Mobile from "./components/Mobile"
import { useMemo } from "react"
import { Stack } from "@mui/material"
import { useMenuListDeliveries } from "./hooks/useMenuListDeliveries"
import Desktop, { DesktopRegisterDeliveriesButton } from "./components/Desktop"

const DeliveriesOption = () => {
    const { list } = useMenuListDeliveries()
    const mobileList = useMemo(() => list.filter((item:any) => item.id !== 1 ), [list])

    const { isDownSmall } = useBreakpoints()

    if( isDownSmall ){
        return(
            <Stack justifyContent={'space-between'} direction={'row'} >
                <DesktopRegisterDeliveriesButton />
                <Mobile list={mobileList} />
            </Stack>
        )
    }else{
        return(
            <>
                <Desktop />
            </>
        )
    }

}

export default DeliveriesOption