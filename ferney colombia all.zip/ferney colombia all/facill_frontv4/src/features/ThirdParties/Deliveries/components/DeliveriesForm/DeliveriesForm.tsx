import React from "react";
import { Button, TextField, Typography } from "@mui/material";
import { Grid } from "@component/UI";
import Wrapper from "./components/Wrapper";

interface Props {
  isOpen?: boolean;
  onClose?: () => void;
}

const DeliveriesForm: React.FC<Props> = (props) => {
  const { isOpen, onClose } = props;

  const [formValues, setFormValues] = React.useState({
    address: "",
    dateRegister: "",
  });
  const [errors, setErrors] = React.useState<any>({});

  const handleChange = (
    event: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = event.target;
    setFormValues({ ...formValues, [name]: value });
  };

  const validateForm = () => {
    const newErrors: any = {};
    if (!formValues.address) {
      newErrors.address = "El campo Dirección es requerido.";
    }
    if (!formValues.dateRegister) {
      newErrors.dateRegister = "El campo Fecha de registro es requerido.";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0; // Return true if no errors
  };

  return (
    <Wrapper isOpen={isOpen} onClose={onClose}>
      <Grid container spacing={1.5}>
        <Grid size={12}>
          <Typography variant="subtitle2">Información de domiciliario:</Typography>
        </Grid>
        <Grid size={12}>
          <TextField
            name="address"
            label="Dirección"
            variant="outlined"
            fullWidth
            value={formValues.address}
            onChange={handleChange}
            error={!!errors.address}
            helperText={errors.address}
          />
        </Grid>
        <Grid size={12}>
          <TextField
            name="dateRegister"
            // label="Fecha de Registro"
            variant="outlined"
            fullWidth
            type="date"
            value={formValues.dateRegister}
            onChange={handleChange}
            error={!!errors.dateRegister}
            helperText={errors.dateRegister}
          />
        </Grid>

        <Grid size={12}>
          <Button variant="contained" fullWidth size="large">
            Guardar
          </Button>
        </Grid>
      </Grid>
    </Wrapper>
  );
};

export default DeliveriesForm;
