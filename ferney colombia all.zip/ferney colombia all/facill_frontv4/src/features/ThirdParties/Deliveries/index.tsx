import { Grid } from "@component/UI";
import CardWrapper from "@component/CardWrapper";
import CustomizedDataGrid from "@component/CustomizedDataGrid";
import DeliveriesOption from "./components/DeliveriesOption";
import { Users } from "lucide-react";
const Deliveries = () => {
  return (
    <CardWrapper icon={<Users />} title="Domicilios">
      <Grid container spacing={1}>
        <Grid size={12}>
          <DeliveriesOption />
        </Grid>

        <Grid size={12}>
          <CustomizedDataGrid
            columns={[
              { field: "_", headerName: "Domicilio" },
              { field: "__", headerName: "Fecha de registro" },
            ]}
          />
        </Grid>
      </Grid>
    </CardWrapper>
  );
};

export default Deliveries;
