import { UserRoundPlus } from "lucide-react";
import { ReactNode, useMemo } from "react";

interface ListProps {
  id: number;
  name: string;
  icon: ReactNode;
  onClick: () => void;
}

export const useMenuListHauliers = () => {
  const list = useMemo(() => {
    const data: ListProps[] = [
      { name: "Registrar transportista", icon: <UserRoundPlus />, onClick: () => null },
    ].map((item, index) => ({ ...item, id: index + 1 }));
    return data;
  }, []);

  return { list };
};
