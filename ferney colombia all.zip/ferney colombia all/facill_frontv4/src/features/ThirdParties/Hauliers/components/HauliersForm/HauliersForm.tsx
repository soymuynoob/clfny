import React from "react";
import { Button, TextField, Typography } from "@mui/material";
import { Grid } from "@component/UI";
import Wrapper from "./components/Wrapper";

interface Props {
  isOpen?: boolean;
  onClose?: () => void;
}

const CarriersForm: React.FC<Props> = (props) => {
  const { isOpen, onClose } = props;

  const [formValues, setFormValues] = React.useState({
    carrier: "",
    registrationDate: "",
  });
  const [errors, setErrors] = React.useState<any>({});

  const handleChange = (
    event: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = event.target;
    setFormValues({ ...formValues, [name]: value });
  };

  const validateForm = () => {
    const newErrors: any = {};
    if (!formValues.carrier) {
      newErrors.carrier = "El campo Transportista es requerido.";
    }
    if (!formValues.registrationDate) {
      newErrors.registrationDate = "El campo Fecha de registro es requerido.";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0; // Return true if no errors
  };

  return (
    <Wrapper isOpen={isOpen} onClose={onClose}>
      <Grid container spacing={1.5}>
        <Grid size={12}>
          <Typography variant="subtitle2">
            Información de Transportista:
          </Typography>
        </Grid>
        <Grid size={12}>
          <TextField
            name="carrier"
            label="Transportista"
            variant="outlined"
            fullWidth
            value={formValues.carrier}
            onChange={handleChange}
            error={!!errors.carrier}
            helperText={errors.carrier}
          />
        </Grid>
        <Grid size={12}>
          <TextField
            name="registrationDate"
              // label="Fecha de Registro"
              variant="outlined"
              fullWidth
              type="date"
              value={formValues.registrationDate}
              onChange={handleChange}
              error={!!errors.registrationDate}
            helperText={errors.registrationDate}
            />
        </Grid>

        <Grid size={12}>
          <Button variant="contained" fullWidth size="large">
            Guardar
          </Button>
        </Grid>
      </Grid>
    </Wrapper>
  );
};

export default CarriersForm;
