import { useBreakpoints } from "@hook/useBreakpoints";
import Mobile from "./components/Mobile";
import { useMemo } from "react";
import { Stack } from "@mui/material";
import { useMenuListHauliers } from "./hooks/useMenuListHauliers";
import Desktop, { DesktopRegisterHauliersButton } from "./components/Desktop";

const HauliersOption = () => {
  const { list } = useMenuListHauliers();
  const mobileList = useMemo(
    () => list.filter((item: any) => item.id !== 1),
    [list]
  );

  const { isDownSmall } = useBreakpoints();

  if (isDownSmall) {
    return (
      <Stack justifyContent={"space-between"} direction={"row"}>
        <DesktopRegisterHauliersButton />
        <Mobile list={mobileList} />
      </Stack>
    );
  } else {
    return (
      <>
        <Desktop />
      </>
    );
  }
};

export default HauliersOption;
