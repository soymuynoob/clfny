import { Button, Stack } from "@mui/material";
import { useState } from "react";
import HauliersForm from "../../HauliersForm/HauliersForm";
import { UserRoundPlus } from "lucide-react";

export const DesktopRegisterHauliersButton = () => {
  const [isModalOpen, setModalOpen] = useState<boolean>(false);

  const openModal = () => setModalOpen(true);
  const closeModal = () => setModalOpen(false);

  return (
    <>
      <Stack direction={"row"} alignItems={"center"} gap={1}>
        <Button
          size="small"
          variant="contained"
          startIcon={<UserRoundPlus />}
          onClick={openModal}
        >
          Registrar transportista
        </Button>
        <HauliersForm isOpen={isModalOpen} onClose={closeModal} />
      </Stack>
    </>
  );
};

const Desktop = () => {
  return (
    <>
      <Stack direction={"row"} gap={1}>
        <DesktopRegisterHauliersButton />
      </Stack>
    </>
  );
};

export default Desktop;
