import { Grid } from "@component/UI";
import CardWrapper from "@component/CardWrapper";
import CustomizedDataGrid from "@component/CustomizedDataGrid";
import HauliersOption from "./components/HauliersOption";
import { Users } from "lucide-react";
const Hauliers = () => {
  return (
    <CardWrapper icon={<Users />} title="Transportistas">
      <Grid container spacing={1}>
        <Grid size={12}>
          <HauliersOption />
        </Grid>

        <Grid size={12}>
          <CustomizedDataGrid
            columns={[
              { field: "_", headerName: "Transportista" },
              { field: "__", headerName: "Fecha de registro" },
            ]}
          />
        </Grid>
      </Grid>
    </CardWrapper>
  );
};

export default Hauliers;
