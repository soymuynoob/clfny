import { FileDown, FileUp, UserRoundPlus } from "lucide-react"
import { ReactNode, useMemo } from "react"

interface ListProps {
    id: number,
    name: string,
    icon: ReactNode,
    onClick: () => void
}

export const useMenuListCustomer= () => {

    const list = useMemo(() => {
        const data:ListProps[] = [
            { name: "Registrar nuevo cliente", icon: <UserRoundPlus />, onClick: () => null },
            { name: "Importar clientes", icon: <FileUp />, onClick: () => null },
            { name: "Exportar clientes", icon: <FileDown />, onClick: () => null },
        ].map((item, index) => ({...item, id: (index+1)}))
        return data
    }, [])

    return { list }
}