import { Button, Grid } from "@component/UI"
import { TextField } from "@mui/material"
import Wrapper from "./components/Wrapper"
import { FC } from "react"

interface Props {
    isOpen?: boolean,
    onClose?: () => void
}

const CustomerForm:FC<Props> = (props) => {
    const { isOpen, onClose } = props
    return(
        <Wrapper isOpen={isOpen} onClose={onClose} >
            <Grid container spacing={1.5} >
                <Grid size={12} >
                    <TextField
                        fullWidth
                        label="Nombre"
                        slotProps={{
                            input: {
                                style: {
                                    fontWeight: 'bold'
                                }
                            }
                        }}
                    />
                </Grid>
                <Grid size={12} >
                    <TextField
                        fullWidth
                        label="Razón social"
                    />
                </Grid>
                <Grid size={{ xs: 12, sm: 12, xl: 6 }} >
                    <TextField
                        fullWidth
                        label="Tipo de documento"
                    />
                </Grid>
                <Grid size={{ xs: 12, sm: 12, xl: 6 }} >
                    <TextField
                        fullWidth
                        label="Numero de documento"
                    />
                </Grid>
                <Grid size={{ xs: 12, sm: 12, xl: 6 }} >
                    <TextField
                        fullWidth
                        label="Correo electrónico"
                    />
                </Grid>
                <Grid size={{ xs: 12, sm: 12, xl: 6 }} >
                    <TextField
                        fullWidth
                        label="Numero de teléfono"
                    />
                </Grid>
                <Grid size={12} >
                    <TextField
                        fullWidth
                        multiline
                        rows={3}
                        label="Dirección"
                    />
                </Grid>
                <Grid size={12} >
                    <Button variant="contained" fullWidth size="large" >
                        Guardar
                    </Button>
                </Grid>
            </Grid>
        </Wrapper>
    )
}

export default CustomerForm