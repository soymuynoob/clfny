import { Button, Stack } from "@mui/material"
import { FileDown, FileUp, UserRoundPlus, Users } from "lucide-react"
import CustomerForm from "../../CustomerForm"
import { useState } from "react"

export const DesktopRegisterCustomerButton = () => {
    const [toggle, setToggle] = useState<boolean>(false)

    return (
        <>
            <Button variant="contained" disableElevation size="small" startIcon={<UserRoundPlus  />} onClick={() => setToggle(true)} >
                Registrar cliente
            </Button>
            <CustomerForm isOpen={toggle} onClose={() => setToggle(false)} />
        </>
    )
}

const Desktop = () => {
    return (
        <>
            <Stack direction={'row'} gap={1} >
                <DesktopRegisterCustomerButton />
                <Button variant="outlined" disableElevation size="small" startIcon={<FileUp />} >
                    Importar clientes
                </Button>
                <Button variant="outlined" disableElevation size="small" startIcon={<FileDown />} >
                    Exportar clientes
                </Button>
            </Stack>
        </>
    )
}

export default Desktop