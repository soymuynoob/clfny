import { useBreakpoints } from "@hook/useBreakpoints"
import Desktop, { DesktopRegisterCustomerButton } from "./components/Desktop"
import Mobile from "./components/Mobile"
import { useMenuListCustomer } from "./hooks/useMenuListCustomer"
import { useMemo } from "react"
import { Stack } from "@mui/material"

const CustomersOption = () => {
    const { list } = useMenuListCustomer()
    const mobileList = useMemo(() => list.filter((item) => item.id !== 1 ), [list])

    const { isDownSmall } = useBreakpoints()

    if( isDownSmall ){
        return(
            <Stack justifyContent={'space-between'} direction={'row'} >
                <DesktopRegisterCustomerButton />
                <Mobile list={mobileList} />
            </Stack>
        )
    }else{
        return(
            <>
                <Desktop />
            </>
        )
    }

}

export default CustomersOption