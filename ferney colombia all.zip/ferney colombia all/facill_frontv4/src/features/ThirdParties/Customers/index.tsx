import CustomizedDataGrid from "@component/CustomizedDataGrid"
import { Grid } from "@component/UI"
import CustomersOption from "./components/CustomersOption"
import CardWrapper from "@component/CardWrapper"
import CustomerForm from "./components/CustomerForm"
import { Users } from "lucide-react"

const Customers = () => {
    return(
        <CardWrapper icon={<Users />} title="Clientes" >
            <Grid container spacing={1} >
                <Grid size={12} >
                    <CustomersOption />
                </Grid>
                <Grid size={12} >
                    <CustomizedDataGrid
                        columns={[
                            { field: "_", headerName: "Cliente" },
                            { field: "__", headerName: "Anticipo" },
                            { field: "___", headerName: "Dirección" },
                            { field: "____", headerName: "Razón social" },
                            { field: "_____", headerName: "N° Teléfono" },
                        ]}
                    />
                </Grid>
            </Grid>
            <CustomerForm />
        </CardWrapper>
    )
}

export default Customers