import CustomizedDataGrid from "@component/CustomizedDataGrid"
import { Grid } from "@component/UI"
import CardWrapper from "@component/CardWrapper"
import { TrendingUp } from "lucide-react"
import TotalMovements from "./components/TotalMovements"
import CreditsOption from "./components/CreditsOption"

const Credits = () => {
    return(
        <CardWrapper icon={<TrendingUp />} title="Créditos" >
            <Grid container spacing={1} >
                <Grid size={12} >
                    <TotalMovements />
                </Grid>
                <Grid size={12} >
                    <CreditsOption />
                </Grid>
                <Grid size={12} >
                    <CustomizedDataGrid
                        columns={[
                            { field: "_", headerName: "Nombre" },
                            { field: "__", headerName: "#FACT" },
                            { field: "___", headerName: "Venta" },
                            { field: "____", headerName: "Pagos" },
                            { field: "_____", headerName: "Saldo" },
                            { field: "_____", headerName: "Vendedor" },
                            { field: "_____", headerName: "Fecha de facturación" },
                        ]}
                    />
                </Grid>
            </Grid>
        </CardWrapper>
    )
}

export default Credits