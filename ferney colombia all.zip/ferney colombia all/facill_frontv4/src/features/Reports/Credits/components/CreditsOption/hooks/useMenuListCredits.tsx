import { FileDown } from "lucide-react"
import { ReactNode, useMemo } from "react"

interface ListProps {
    id: number,
    name: string,
    icon: ReactNode,
    onClick: () => void
}

export const useMenuListCredits = () => {

    const list = useMemo(() => {
        const data:ListProps[] = [
            { name: "Exportar créditos", icon: <FileDown />, onClick: () => null },
        ].map((item, index) => ({...item, id: (index+1)}))
        return data
    }, [])

    return { list }
}