import { Button, Stack } from "@mui/material";
import { FileDown } from "lucide-react";

export const DesktopRegisterExpenseFixedButton = () => {
  return (
    <>
      <Stack direction={"row"} alignItems={"center"} gap={1}></Stack>
    </>
  );
};

const Desktop = () => {
  return (
    <>
      <Stack direction={"row"} gap={1}>
        <DesktopRegisterExpenseFixedButton />

        <Button
          variant="outlined"
          disableElevation
          size="small"
          startIcon={<FileDown />}
        >
          Exportar créditos
        </Button>
      </Stack>
    </>
  );
};

export default Desktop;
