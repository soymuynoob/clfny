import CustomizedDataGrid from "@component/CustomizedDataGrid"
import { Grid } from "@component/UI"
import CardWrapper from "@component/CardWrapper"
import { TrendingUp } from "lucide-react"

const Sales = () => {
    return(
        <CardWrapper icon={<TrendingUp />} title="Ventas" >
            <Grid container spacing={1} >
                
                <Grid size={12} >
                    <CustomizedDataGrid
                        columns={[
                            { field: "_", headerName: "Fecha" },
                            { field: "__", headerName: "Total" },
                            { field: "___", headerName: "$" },
                            { field: "____", headerName: "%" },
                        ]}
                    />
                </Grid>
            </Grid>
        </CardWrapper>
    )
}

export default Sales