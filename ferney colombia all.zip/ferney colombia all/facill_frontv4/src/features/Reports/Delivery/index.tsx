import CustomizedDataGrid from "@component/CustomizedDataGrid"
import { Grid } from "@component/UI"
import CardWrapper from "@component/CardWrapper"
import { TrendingUp } from "lucide-react"

const Delivery = () => {
    return(
        <CardWrapper icon={<TrendingUp />} title="Domicilios" >
            <Grid container spacing={1} >
                <Grid size={12} >
                    <CustomizedDataGrid
                        columns={[
                            { field: "_", headerName: "Nombre" },
                            { field: "__", headerName: "Domicilio" },
                            { field: "____", headerName: "Valor del domicilio" },
                            { field: "_____", headerName: "Tipo de pago de domicilio" },
                            { field: "________", headerName: "#FAC" },
                            { field: "_________", headerName: "Venta" },
                            { field: "__________", headerName: "Pagos" },
                            { field: "___________", headerName: "Saldo" },
                            { field: "____________", headerName: "Vendedor" },
                            { field: "_____________", headerName: "Fecha de facturación" },
                        ]}
                    />
                </Grid>
            </Grid>
        </CardWrapper>
    )
}

export default Delivery