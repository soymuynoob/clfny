import Menu from "@component/Menu"
import { IconButton, ListItemIcon, MenuItem } from "@mui/material"
import { MenuIcon } from "lucide-react"
import { FC, ReactNode, useState } from "react"

interface Props {
    list: {
        name: string,
        icon: ReactNode,
        onClick: () => void
    }[]
}

const Mobile:FC<Props> = (props) => {
    const { list } = props
    const [anchorElem, setAnchorElem] = useState<Element | null>(null)
    return(
        <>
            <IconButton onClick={({ currentTarget }) => setAnchorElem(currentTarget)} >
                <MenuIcon />
            </IconButton>
            <Menu anchorEl={anchorElem} onClose={ () => setAnchorElem(null) } >
                {list.map((item, index) => {
                    return(
                        <MenuItem key={index} onClick={item.onClick} >
                            <ListItemIcon>
                                {item.icon}
                            </ListItemIcon>
                            {item.name}
                        </MenuItem>
                    )
                })}
            </Menu>
        </>
    )
}

export default Mobile