import { Card, CardContent, Stack, Typography } from "@mui/material"

const AvailableBalance = () => {
    return (
        <>
            <Card sx={{ maxWidth: 4000, minWidth: 350 }} >
                <CardContent>
                    <Stack>
                        <Typography variant="h6" mb={1} > Saldo </Typography>
                        <Typography variant="h4" sx={{ WebkitTextStroke: .7 }} > $ 12.525.396 </Typography>
                        <Typography variant="subtitle2" > Disponible </Typography>
                    </Stack>
                </CardContent>
            </Card>
        </>
    )
}

export default AvailableBalance