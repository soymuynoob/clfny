import { Stack } from "@mui/material"
import MovementDescription from "./components/MovementDescription"

const TotalMovements = () => {
    return (
        <Stack direction={'row'} gap={1} sx={{ overflowX: 'auto', whiteSpace: 'nowrap', pb: 1 }} height={83} >
            <MovementDescription />
            <MovementDescription />
            <MovementDescription />
            <MovementDescription />
            <MovementDescription />
            <MovementDescription />
            <MovementDescription />
        </Stack>
    )
}

export default TotalMovements