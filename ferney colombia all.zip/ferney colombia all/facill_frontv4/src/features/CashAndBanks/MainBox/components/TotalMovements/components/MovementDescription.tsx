import { Card, CardContent, Typography } from "@mui/material"

const MovementDescription = () => {
    return (
        <Card variant="outlined" sx={{ minWidth: 200, }} >
            <CardContent>
                <Typography variant="caption" > Traslados entrantes </Typography>
                <Typography variant="subtitle2" > $ 300.000 </Typography>
            </CardContent>
        </Card>
    )
}

export default MovementDescription