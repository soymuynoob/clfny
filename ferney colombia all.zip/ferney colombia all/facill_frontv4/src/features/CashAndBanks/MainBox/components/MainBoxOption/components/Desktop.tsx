import { Button, Stack } from "@mui/material"
import { FC, ReactNode } from "react"

interface Props {
    list: {
        name: string,
        icon: ReactNode,
        onClick: () => void
    }[]
}

const Desktop:FC<Props> = (props) => {
    const { list } = props
    return (
        <>
            <Stack direction={'row'} gap={1} >
                { list.map((item, index) => {
                    return(
                        <Button key={index} variant={(index === 0) ? "contained" : "outlined"} disableElevation size="small" startIcon={item.icon} >
                            {item.name}
                        </Button>
                    )
                }) }
            </Stack>
        </>
    )
}

export default Desktop