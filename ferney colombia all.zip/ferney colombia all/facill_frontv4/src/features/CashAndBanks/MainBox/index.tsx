import CardWrapper from "@component/CardWrapper"
import CustomizedDataGrid from "@component/CustomizedDataGrid"
import { Grid } from "@component/UI"
import { Box, Stack } from "@mui/material"
import { CircleDollarSignIcon } from "lucide-react"
import AvailableBalance from "./components/AvailableBalance"
import TotalMovements from "./components/TotalMovements"
import MainBoxOptions from "./components/MainBoxOption"

const MainBox = () => {
    return(
        <CardWrapper title="Caja principal" icon={<CircleDollarSignIcon />} >
            <Grid container spacing={1.5} >
                <Grid size={{ xl: 4, lg: 4, md: 4, sm: 4, xs: 12 }} >
                    <AvailableBalance />
                </Grid>
                <Grid size={{ xl: 6, lg: 6, md: 6, sm: 6, xs: 12 }} >
                    <Stack height={'100%'} justifyContent={'space-between'} gap={1} sx={{ width: { xl: '52vw', lg: '52vw', md: '52vw', sm: '52vw', xs: '100%' } }} >
                        <TotalMovements />
                        <MainBoxOptions />
                    </Stack>
                </Grid>
                <Grid size={12} >
                    <Box mt={1} >
                        <CustomizedDataGrid
                            columns={[
                                {field: '_', headerName: "Autor", },
                                {field: '__', headerName: "Desde", },
                                {field: '___', headerName: "Destino", },
                                {field: '____', headerName: "Monto", },
                                {field: '_____', headerName: "Descripción", },
                                {field: '______', headerName: "", },
                            ]}
                        />
                    </Box>
                </Grid>
            </Grid>
        </CardWrapper>
    )
}

export default MainBox