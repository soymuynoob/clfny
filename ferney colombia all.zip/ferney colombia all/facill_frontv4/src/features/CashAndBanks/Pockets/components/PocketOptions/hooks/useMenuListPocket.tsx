import { CurrencyExchangeRounded } from "@mui/icons-material"
import { CoinsIcon, HandCoinsIcon, } from "lucide-react"
import { ReactNode, useCallback, useMemo } from "react"

interface ListProps {
    id_name: string,
    id: number,
    name: string,
    icon: ReactNode,
    onClick: () => void
}

export const useMenuListPocket= () => {

    const list = useMemo(() => {
        const data:ListProps[] = [
            { id_name: "translateBalance", name: "Trasladar saldo", icon: <CurrencyExchangeRounded />, onClick: () => null },
            { id_name: "recordVariableExpense", name: "Registrar gasto variable", icon: <HandCoinsIcon />, onClick: () => null },
            { id_name: "payFixedExpense", name: "Pagar gasto fijo", icon: <CoinsIcon />, onClick: () => null },
        ].map((item, index) => ({...item, id: (index+1)}))
        return data
    }, [])

    const getListItem = useCallback((id_name:string): ListProps | null => {
        const listItem = list.find((item) => item.id_name === id_name ) || null
        return listItem
    }, [list])

    return { list, getListItem }
}