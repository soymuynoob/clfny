import { useBreakpoints } from "@hook/useBreakpoints"
import Desktop from "./components/Desktop"
import Mobile from "./components/Mobile"
import { useMemo } from "react"
import { Stack } from "@mui/material"
import { Button } from "@component/UI"
import { useMenuListPocket } from "./hooks/useMenuListPocket"

const PocketOptions = () => {
    const { list, getListItem } = useMenuListPocket()
    const mobileList = useMemo(() => list.filter((item) => item.id !== 1 ), [list])
    const TranslateBalance = getListItem("translateBalance")

    const { isDownSmall } = useBreakpoints()

    if( isDownSmall ){
        return(
            <Stack justifyContent={'space-between'} direction={'row'} >
                <Button startIcon={TranslateBalance?.icon} variant="contained" > {TranslateBalance?.name} </Button>
                <Mobile list={mobileList} />
            </Stack>
        )
    }else{
        return(
            <>
                <Desktop list={list} />
            </>
        )
    }

}

export default PocketOptions