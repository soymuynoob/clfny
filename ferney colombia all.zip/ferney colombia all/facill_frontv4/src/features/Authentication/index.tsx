import { useState } from "react";
import { styled } from "@mui/material/styles";
import {
  Box,
  Card,
  CardContent,
  Container as ContainerMUI,
} from "@mui/material";
import HeaderForm from "./components/HeaderForm";
import FormFields from "./components/FormFields";
import FormButtons from "./components/FormButtoms";
import FormAnimation from "./components/FormAnimation";
import Form from "@component/Form";
import { useBreakpoints } from "@hook/useBreakpoints";
import { useNavigate } from "react-router-dom";
import { ValidatorLogin } from "./utils/validation";
import { useLoginServiceMutation } from "@api/auth_service";
import { useDispatch } from "react-redux";
import {login, setLoading} from '@redux/features/auth/authSlice';

const Container = styled(ContainerMUI)(() => ({
  width: "100%",
  height: "100%",
  display: "flex",
  flexDirection: "column",
  justifyContent: "center",
}));

const Authentication = () => {
  const navigate = useNavigate();
  const { isDownSmall } = useBreakpoints();
  const [email, setEmail] = useState<string>("");
  const [password, setPassword] = useState<string>("");
  const [isError, setIsError] = useState<boolean>(false);
  const [helperText, setHelperText] = useState({});
  const [loginService] = useLoginServiceMutation();
  const dispatch = useDispatch()

  const onSubmitLogin = () => {
    const values: any = {
      email,
      password,
    };
    const validationErrors = ValidatorLogin({ values });
    if (Object.keys(validationErrors).length > 0) {
      setIsError(true);
      setHelperText(validationErrors);
    } else {
      setIsError(false);
      setHelperText({});

      dispatch(setLoading(true));

      //successfull validation
      (async () => {
        try {
          const response = await loginService({
            userEmail: email,
            password,
          }).unwrap();
          dispatch(login(response.accessToken))
          navigate('/');
        } catch (error: any) {
          setIsError(true);
          setHelperText({
            password: error?.data?.message,
          });
        } finally {
            dispatch(setLoading(false));
        }
      })();
    }
  };

  return (
    <Container maxWidth="sm">
      <Card elevation={isDownSmall ? 0 : 1}>
        <CardContent>
          <HeaderForm />
          {!isDownSmall && <FormAnimation />}
          <Box
            textAlign={"center"}
            fontWeight={"bold"}
            textTransform={"uppercase"}
            fontSize={isDownSmall ? "1rem" : "1.2rem"}
            mb={1}
          >
            Iniciar sesión
          </Box>
          <Form>
            <FormFields
              onChangeEmail={setEmail}
              onChangePassword={setPassword}
              isError={isError}
              errors={helperText}
            />
            <FormButtons
              onLogin={onSubmitLogin}
              onRegisterNavigation={() => navigate("/register")}
            />
          </Form>
        </CardContent>
      </Card>
    </Container>
  );
};

export default Authentication;
