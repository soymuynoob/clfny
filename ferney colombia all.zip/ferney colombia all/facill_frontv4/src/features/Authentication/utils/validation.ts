interface IValues {
  email?: string;
  password?: string;
}

type PropsValidator = {
  values: IValues;
};

export const ValidatorLogin = ({ values }: PropsValidator) => {
  const errors: IValues = {};

  if (!values.email) {
    errors.email = "El correo electrónico es requerido.";
  } else if (!/\S+@\S+\.\S+/.test(values.email)) {
    errors.email = "El correo electrónico no es válido.";
  }

  if (!values.password) {
    errors.password = "La contraseña es requerida.";
  } else if (values.password.length < 8) {
    errors.password = "La contraseña debe tener al menos 8 caracteres.";
  }

  return errors;
};
