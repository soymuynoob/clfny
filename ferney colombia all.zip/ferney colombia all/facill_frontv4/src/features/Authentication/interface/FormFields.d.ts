export interface Props {
    onChangeEmail: (event: string) => void;
    onChangePassword: (event: string) => void;
    isError: boolean;
    errors: any;
}

export interface IFormButtoms {
    onLogin?: () => void;
    onRegisterNavigation?: () => void;
}
