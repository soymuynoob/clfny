import { useLoginWithGoogleServiceMutation } from "@api/auth_service"
import { GoogleAccessToken } from "@api/auth_service/interface/AuthService"
import { useCallback } from "react"

export const useAuthGoogle = () => {
    const [ LoginWithGoogleServiceMutation ] = useLoginWithGoogleServiceMutation()

    const AuthenticateWithGoogle = useCallback( async (payload:GoogleAccessToken) => {
        try {
            const data = await LoginWithGoogleServiceMutation(payload).unwrap()
            const { token } = data
            console.log(token)
        } catch (error) {
            console.log(error)
        }
    }, [LoginWithGoogleServiceMutation])

    return {
        AuthenticateWithGoogle,
    }
}