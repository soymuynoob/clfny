import { CredentialResponse, GoogleLogin, GoogleOAuthProvider } from "@react-oauth/google";
import { useAuthGoogle } from "./hooks/useAuthGoogle";
import { useCallback } from "react";
import GetEnv from "@util/getEnv";

const AuthGoogleButton = () => {
  const GOOGLE_CLIENT_ID = GetEnv("VITE_GOOGLE_CLIENT_ID");
  const { AuthenticateWithGoogle } = useAuthGoogle()

  const handleSuccess = useCallback((response:CredentialResponse) => {
    const token_google = response.credential || ""
    AuthenticateWithGoogle({ token_google })
  }, [AuthenticateWithGoogle])

  const handleError = () => {
    console.error("Error en el inicio de sesión con Google");
  };

  return (
    <>
      <GoogleOAuthProvider clientId={GOOGLE_CLIENT_ID}>
        <div>
          <GoogleLogin onSuccess={handleSuccess} onError={handleError} />
        </div>
      </GoogleOAuthProvider>
    </>
  );
};

export default AuthGoogleButton;