import { useBreakpoints } from "@hook/useBreakpoints"
import { Box } from "@mui/material"

const HeaderForm = () => {
    const { isDownSmall } = useBreakpoints()

    return(
        <Box
            textAlign={isDownSmall ? "center" : undefined}
            fontWeight={'bold'}
            lineHeight={1.2}
            fontSize={'2rem'}
            sx={{ WebkitTextStroke: 1.2 }}
            position={isDownSmall ? "relative" : undefined}
            bottom={isDownSmall ? 20 : undefined}
        >
        Facill
            <Box fontSize={'1.1rem'} sx={{ WebkitTextStroke: 0 }} >
                Fácil, rápido, y seguro.
            </Box>
        </Box>
    )
}

export default HeaderForm