import { Box } from "@mui/material"
import { useLottie } from "lottie-react"
import userAnimation from '@animation/user.json'

const FormAnimation = () => {
    const { View } = useLottie({
        animationData: userAnimation,
        loop: false,
        style: {
            width: "150px"
        }
    })

    return (
        <Box display={'flex'} justifyContent={'center'} >
            {View}
        </Box>
    )
}

export default FormAnimation