import { IFormButtoms } from "../interface/FormFields";
import { Button } from "@component/UI";
import { Stack } from "@mui/material";
import { useSelector } from 'react-redux';
import AuthGoogleButton from "./AuthGoogleButton";
import { FC } from "react";
import { RootState } from "@redux/store";

const FormButtons: FC<IFormButtoms> = ({ onLogin, onRegisterNavigation }) => {
  const loading = useSelector((state: RootState) => state.auth.loading);

  return (
    <>
      <Stack gap={1} mt={2}>
        <Button
          fullWidth
          variant="contained"
          disableElevation
          size="large"
          loading={loading}
          type="submit"
          onClick={onLogin}
        >
          Ingresar
        </Button>
        <Button
          fullWidth
          variant="text"
          disableElevation
          size="large"
          onClick={onRegisterNavigation}
        >
          Crear cuenta
        </Button>
        <AuthGoogleButton />
      </Stack>
    </>
  );
};

export default FormButtons;
