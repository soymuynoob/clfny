import { useBreakpoints } from "@hook/useBreakpoints"
import { Box, Card, CardContent, Stack, Typography } from "@mui/material"
import { FC, ReactNode } from "react"

interface WrapperTitleProps {
    title?: string | ReactNode
    icon?: ReactNode
}

interface Props extends Pick<WrapperTitleProps, "title" | "icon"> {
    children?: ReactNode
}

const WrapperTitle:FC<WrapperTitleProps> = (props) => {
    const { title, icon } = props
    if( title === undefined ){
        return <></>
    }else{
        return(
            <Stack mb={2} direction={'row'} alignItems={'center'} gap={1} >
                {icon}
                <Typography variant="h4" >
                    {title}
                </Typography>
            </Stack>
        )
    }

}


const CardWrapper:FC<Props> = (props) => {
    const { children, title, icon } = props
    const { isDownSmall } = useBreakpoints()
    const Title = <WrapperTitle title={title} icon={icon} />
    if( isDownSmall ){
        return(
            <Box>
                {Title}
                {children}
            </Box>
        )
    }else{
        return(
            <Card variant="outlined" sx={{
                height: 'calc(100vh - 120px)',
                overflowY: 'scroll'
            }} >
                {Title}
                <CardContent>
                    {children}
                </CardContent>
            </Card>
        )
    }
}

export default CardWrapper