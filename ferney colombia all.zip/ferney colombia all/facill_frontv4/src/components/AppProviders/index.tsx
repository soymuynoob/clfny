import { Children } from "@interface/ChildrenProp";
import { FC } from "react";
import '@fontsource/roboto/300.css';
import '@fontsource/roboto/400.css';
import '@fontsource/roboto/500.css';
import '@fontsource/roboto/700.css';

import '@fontsource/inter/300.css';
import '@fontsource/inter/400.css';
import '@fontsource/inter/500.css';
import '@fontsource/inter/700.css';
import { CssBaseline, ThemeProvider } from "@mui/material";
import { customTheme } from "@style/theme";
import { LocalizationProvider } from "@mui/x-date-pickers";
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs'
import { Provider as ReduxProvider } from "react-redux";
import { store } from "@redux/store";

const AppProviders: FC<Children> = ({ children }) => {
    console.log(customTheme)
    return(
        <>
            <ReduxProvider store={store} >
                <ThemeProvider theme={customTheme} >
                    <CssBaseline />
                    <LocalizationProvider dateAdapter={AdapterDayjs} >
                        {children}
                    </LocalizationProvider>
                </ThemeProvider>
            </ReduxProvider>
        </>
    )
}

export default AppProviders