import { IconButton, List, ListItem, ListItemIcon, ListItemText } from "@mui/material"
import { CircleUserRoundIcon, EllipsisVerticalIcon } from "lucide-react"
import MenuOptions from "./components/MenuOptions"
import { useState } from "react"

const UserMenu = () => {
    const [anchorElem, setAnchorElem] = useState<Element | null>(null)
    return (
        <>
        <List sx={{ padding: 0 }} >
            <ListItem sx={{ padding: 0 }} >
                <ListItemIcon sx={{ marginRight: 1 }} >
                    <CircleUserRoundIcon size={35} />
                </ListItemIcon>
                <ListItemText
                    primary="Enrique Pacheco"
                    secondary="Administrador"
                    secondaryTypographyProps={{
                        sx: {
                            color: ({ palette }) => palette.grey[400] 
                        }
                    }}
                />
                <ListItemIcon sx={{ marginLeft: 4 }} >
                    <IconButton size="small" onClick={({ currentTarget }) => setAnchorElem(currentTarget)} >
                        <EllipsisVerticalIcon />
                    </IconButton>
                </ListItemIcon>
            </ListItem>
        </List>
        <MenuOptions
            anchorEl={anchorElem}
            onClose={() => setAnchorElem(null)}
            onClick={() => setAnchorElem(null)}
        />
        </>
    )
}

export default UserMenu