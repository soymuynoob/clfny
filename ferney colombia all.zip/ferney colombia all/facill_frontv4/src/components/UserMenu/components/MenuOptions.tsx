import Menu from "@component/Menu"
import { FC } from "react"
import LogoutButton from "./LogoutButton"

interface Props {
    anchorEl: Element | null,
    onClick: () => void,
    onClose: () => void
}

const MenuOptions:FC<Props> = (props) => {
    const { anchorEl, onClick, onClose } = props
    return (
        <>
            <Menu anchorEl={anchorEl} onClick={onClick} onClose={onClose} >
                <LogoutButton />
            </Menu>
        </>
    )
}

export default MenuOptions