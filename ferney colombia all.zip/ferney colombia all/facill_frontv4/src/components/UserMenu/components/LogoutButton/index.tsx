import { useLogoutServiceMutation   } from "@api/auth_service";
import { ListItemIcon, listItemIconClasses, ListItemText, MenuItem } from "@mui/material"
import { logout } from "@redux/features/auth/authSlice";
import { LogOutIcon } from "lucide-react"
import { useDispatch } from "react-redux";
import { useNavigate } from "react-router-dom";

const LogoutButton = () => {
    const [logoutService] = useLogoutServiceMutation();
    const dispatch = useDispatch();
    const navigate = useNavigate();

    const handleLogout = async () => {
        // const response = await logoutService().unwrap();
        // console.log(response);
        dispatch(logout());
        navigate('/login');
    }

    return (
        <>
            <MenuItem
                sx={{
                    [`& .${listItemIconClasses.root}`]: {
                        ml: 'auto',
                        minWidth: 0,
                    },
                    minWidth: 200
                }}
            >
                <ListItemText onClick={handleLogout}>Cerrar sesión</ListItemText>
                <ListItemIcon>
                    <LogOutIcon />
                </ListItemIcon>
            </MenuItem>
        </>
    )
}

export default LogoutButton