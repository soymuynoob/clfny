import { Children } from "@interface/ChildrenProp";

export interface Props extends Children {
    onSubmit?: (param?) => void
}