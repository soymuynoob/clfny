import { FC, FormEvent, useCallback } from "react"
import { Props } from "./interface/Form"

const Form:FC<Props> = ({ children, onSubmit }) => {

    const HandleSubmit = useCallback((event:FormEvent<HTMLFormElement> ) => {
        event.preventDefault()
        event.stopPropagation()
        if(typeof onSubmit === "function"){
            onSubmit()
        }
    }, [onSubmit])

    return(
        <form onSubmit={HandleSubmit} >
            {children}
        </form>
    )
}

export default Form