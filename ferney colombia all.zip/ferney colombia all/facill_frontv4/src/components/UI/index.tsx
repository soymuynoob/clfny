import * as MUI_Components from '@mui/material'
import * as LAB_Components from '@mui/lab'

export const {
    LoadingButton:Button,
} = LAB_Components

export const {
    Grid2:Grid,
} = MUI_Components