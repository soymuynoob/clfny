import { Menu as MenuMUI, dividerClasses, listClasses, paperClasses } from "@mui/material"
import { FC, ReactNode, useMemo } from "react"

interface Props {
    anchorEl?: Element | null,
    onClose?: () => void,
    onClick?: () => void,
    children?: ReactNode
}

const Menu:FC<Props> = (props) => {
    const { anchorEl, onClick, onClose, children } = props    
    const isOpen:boolean = useMemo(() => Boolean(anchorEl), [anchorEl])
    return (
        <>
            <MenuMUI anchorEl={anchorEl} open={isOpen} onClose={onClose} onClick={onClick}
                transformOrigin={{ horizontal: 'right', vertical: 'top' }}
                anchorOrigin={{ horizontal: 'right', vertical: 'bottom' }}
                sx={{
                    [`& .${listClasses.root}`]: {
                        padding: '4px',
                    },
                    [`& .${paperClasses.root}`]: {
                        padding: 0,
                    },
                    [`& .${dividerClasses.root}`]: {
                        margin: '4px -4px',
                    },
                }}
            >
                {children}
            </MenuMUI>
        </>
    )
}

export default Menu