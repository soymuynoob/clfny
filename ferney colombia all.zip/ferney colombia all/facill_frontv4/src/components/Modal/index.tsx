import { Dialog, DialogContent, IconButton, Stack, Typography, DialogProps } from "@mui/material"
import { X } from "lucide-react"
import { FC, ReactNode, useMemo } from "react"

interface Props extends Pick<DialogProps, "fullScreen" > {
  isOpen: boolean
  onClose: () => void
  children?: ReactNode
  title?: string
}

const Modal: FC<Props> = (props) => {
  const { isOpen, onClose, children, title, ...rest } = props
  
  const Title = useMemo(() => {
    if( title !== undefined ) {
      return(
        <Typography variant="h5" > {title} </Typography>
      )
    }else{
      return <></>
    }
  }, [title])

  return (
    <>
      <Dialog onClose={onClose} open={isOpen} fullWidth {...rest} >
        <DialogContent>
          <Stack mb={1} justifyContent={'space-between'} direction={'row'} alignItems={'center'} >
            {Title}
            <IconButton size="small" onClick={onClose} >
                <X />
            </IconButton>
          </Stack>
          {children}
        </DialogContent>
      </Dialog>
    </>
  )
}

export default Modal