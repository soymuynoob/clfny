import React from 'react';
import { Box, IconButton, Slide, Typography } from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';

interface FilterButtonProps {
  content: React.ReactNode;
  isOpen: boolean;
  onClose: () => void;
  containerRef: React.RefObject<HTMLDivElement>;
}

const FilterButton: React.FC<FilterButtonProps> = ({ content, isOpen, onClose }) => {

  const filterStyle = {
    position: 'absolute',
    right: 0,
    top: 0,
    height: '100%',
    width: '300px',
    zIndex: 1000,
  };

  return (
    <Slide direction="left" in={isOpen} mountOnEnter unmountOnExit >
      <Box
        sx={{
          ...(filterStyle as Record<string, unknown>),
          padding: '16px',
          backgroundColor: 'background.paper',
          display: 'flex',
          flexDirection: 'column',
        }}
      >
        <IconButton
          onClick={onClose}
          sx={{ position: 'absolute', right: 8, top: 8 }}
        >
          <CloseIcon />
        </IconButton>
        <Typography variant="h6" sx={{ marginBottom: '16px' }}>
          Filtros
        </Typography>
        <Box sx={{ flexGrow: 1, overflowY: 'auto' }}>
          {content}
        </Box>
      </Box>
    </Slide>
  );
};

export default FilterButton;
