import { Button } from "@component/UI"
import { IconButton, ListItem, ListItemButton, ListItemIcon, ListItemText } from "@mui/material"
import { BadgeDollarSignIcon } from "lucide-react"
import { FC } from "react"

interface Props {
    buttonType?: "button" | "listItem" | "iconButton"
}

const GoPointOfSale: FC<Props> = (props) => {
    const { buttonType = "button" } = props

    switch (buttonType) {
        case "button":
            return (
                <>
                    <Button startIcon={<BadgeDollarSignIcon />} size="small" variant="outlined" disableElevation >
                        VENDER AHORA
                    </Button>
                </>
            );
        case "iconButton":
            return (
                <>
                    <IconButton size="small" >
                        <BadgeDollarSignIcon />
                    </IconButton>
                </>
            );
        case "listItem":
            return (
                <>
                    <ListItem disablePadding sx={{ display: 'block', mb: 1 }} >
                        <ListItemButton selected >
                            <ListItemIcon>
                                <BadgeDollarSignIcon />
                            </ListItemIcon>
                            <ListItemText primary={"Vender Ahora"} />
                        </ListItemButton>
                    </ListItem>
                </>
            );
        default:
            return (
                <></>
            );
    }
}

export default GoPointOfSale