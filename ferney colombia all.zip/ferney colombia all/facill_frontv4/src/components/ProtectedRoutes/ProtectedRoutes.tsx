import { Navigate, Outlet } from "react-router-dom";
import { useSelector } from "react-redux";
import { RootState } from "src/redux/store";

const ProtectedRoutes = () => {
  const token = useSelector((state: RootState) => state.auth.token);

  if (token) {
    return <Outlet />;
  } else {
    localStorage.removeItem("token"); // Eliminar el token inválido
    return <Navigate to="/login" />;
  }
};

export default ProtectedRoutes;
