const GetEnv = (envKey:string) => {
    const data = import.meta.env[envKey]
    return data
}

export default GetEnv