import { RootState } from '@redux/store';
import { createSlice, PayloadAction } from '@reduxjs/toolkit';

interface RegisterState {
  data: any
  loading: boolean;
  error: string | null;
}

const initialState: RegisterState = {
  data: {},
  loading: false,
  error: null,
};

const registerSlice = createSlice({
  name: 'register',
  initialState,
  reducers: {
    registerRequest(state) {
      state.loading = true;
      state.error = null;
    },
    registerSuccess(state, action: PayloadAction<string>) {
      state.data = action.payload;
      state.loading = false;
    },
    registerFailure(state, action: PayloadAction<string>) {
      state.loading = false;
      state.error = action.payload;
    },
    resetRegisterState(state) {
      state.loading = false;
      state.error = null;
    },
  },
});

export const {
  registerRequest,
  registerSuccess,
  registerFailure,
  resetRegisterState,
} = registerSlice.actions;

export const selectRegister = (state: RootState) => state.register;

export default registerSlice.reducer;
