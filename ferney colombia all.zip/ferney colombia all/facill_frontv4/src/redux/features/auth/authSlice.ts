import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { Cookie } from '@util/cookie';

interface AuthState {
  isAuthenticated: boolean;
  token: string | null;
  loading: boolean;
}

const initialState: AuthState = {
  isAuthenticated: !!Cookie.get('token'),
  token: Cookie.get('token'),
  loading: false,
};

const authSlice = createSlice({
  name: 'auth',
  initialState,
  reducers: {
    login(state, action: PayloadAction<string>) {
      state.isAuthenticated = true;
      state.token = action.payload;
      Cookie.set('token', action.payload);
      state.loading = false;
    },
    logout(state) {
      state.isAuthenticated = false;
      state.token = null;
      Cookie.delete('token');
    },
    setLoading(state, action: PayloadAction<boolean>) {
      state.loading = action.payload;
    },
  },
});

export const { login, logout, setLoading } = authSlice.actions;

export default authSlice.reducer;
