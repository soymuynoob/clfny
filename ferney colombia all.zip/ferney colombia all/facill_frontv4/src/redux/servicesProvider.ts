import { user_service, auth_service } from '@api/index'

const servicesPath = {
    [auth_service.reducerPath]: auth_service.reducer,
    [user_service.reducerPath]: user_service.reducer,
}

const servicesMiddleware = [
    auth_service.middleware,
    user_service.middleware,
]

export {
    servicesPath,
    servicesMiddleware,
}