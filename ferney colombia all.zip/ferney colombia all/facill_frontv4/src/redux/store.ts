import { configureStore } from '@reduxjs/toolkit';
import { setupListeners } from '@reduxjs/toolkit/query';
import { servicesMiddleware, servicesPath } from './servicesProvider';
import authReducer from './features/auth/authSlice';
import registerReducer from './features/registration/registerSlice';

export const store = configureStore({
  reducer: {
    ...servicesPath,
    auth: authReducer,
    register: registerReducer
  },
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware().concat(...servicesMiddleware),
})

setupListeners(store.dispatch)

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
