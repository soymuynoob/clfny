import AppProviders from "@component/AppProviders";
import ProtectedRoutes from "@component/ProtectedRoutes/ProtectedRoutes";
import Authentication from "@feature/Authentication";
import MainBox from "@feature/CashAndBanks/MainBox";
import Pockets from "@feature/CashAndBanks/Pockets";
import Dashboard from "@feature/Dashboard";
import ExpenseFixed from "@feature/Expense/ExpenseFixed";
import Overheads from "@feature/Expense/Overheads";
import Categories from "@feature/Products/Categories";
import Inventory from "@feature/Products/Inventory";
import Packaging from "@feature/Products/Packaging";
import Registration from "@feature/Registration";
import Customers from "@feature/ThirdParties/Customers";
import Suppliers from "@feature/ThirdParties/Suppliers";
import Team from "@feature/ThirdParties/Team";
import Credits from "@feature/Reports/Credits";
import Delivery from "@feature/Reports/Delivery";
import Sales from "@feature/Reports/Sales";
import Deliveries from "@feature/ThirdParties/Deliveries";
import Hauliers from "@feature/ThirdParties/Hauliers";
import { BrowserRouter, Route, Routes } from "react-router-dom";

const App = () => {
  return (
    <AppProviders>
      <BrowserRouter future={{ v7_startTransition: true }}>
        <Routes>
          <Route path="/login" element={<Authentication />}></Route>
          <Route path="/register" element={<Registration />}></Route>
          <Route element={<ProtectedRoutes />}>
            <Route path="/" element={<Dashboard />}>
              <Route path="/main/box" element={<MainBox />} />
              <Route path="/pockets" element={<Pockets />} />
              <Route path="/customers" element={<Customers />} />
              <Route path="/inventory" element={<Inventory />} />
              <Route path="/categories" element={<Categories />} />
              <Route path="/packaging" element={<Packaging />} />
              <Route path="/expense-fixed" element={<ExpenseFixed />} />
              <Route path="/overheads" element={<Overheads />} />
              <Route path="/suppliers" element={<Suppliers />} />
              <Route path="/team" element={<Team />} />
              <Route path="/deliveries" element={<Deliveries />} />
              <Route path="/hauliers" element={<Hauliers />} />
              <Route path="/credits" element={<Credits />} />
              <Route path="/delivery" element={<Delivery />} />
              <Route path="/sales" element={<Sales />} />
            </Route>
          </Route>
        </Routes>
      </BrowserRouter>
    </AppProviders>
  );
};

export default App;
