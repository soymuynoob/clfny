import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import path from "path";

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  server: {
    host: true,
  },
  resolve: {
    alias: {
      "@interface": path.resolve(__dirname, "./src/interface"),
      "@component": path.resolve(__dirname, "./src/components"),
      "@feature": path.resolve(__dirname, "./src/features"),
      "@style": path.resolve(__dirname, "./src/styles"),
      "@animation": path.resolve(__dirname, "./src/styles/animations"),
      "@hook": path.resolve(__dirname, "./src/hooks"),
      "@util": path.resolve(__dirname, "./src/utils"),
      "@api": path.resolve(__dirname, "./src/api"),
      "@redux": path.resolve(__dirname, "./src/redux"),
    },
  },
});
