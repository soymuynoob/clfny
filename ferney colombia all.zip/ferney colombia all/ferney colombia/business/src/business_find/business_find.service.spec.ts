import { Test, TestingModule } from '@nestjs/testing';
import { BusinessFindService } from './business_find.service';

describe('BusinessFindService', () => {
  let service: BusinessFindService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [BusinessFindService],
    }).compile();

    service = module.get<BusinessFindService>(BusinessFindService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
