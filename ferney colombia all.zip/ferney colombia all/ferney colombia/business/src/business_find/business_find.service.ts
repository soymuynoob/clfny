import { BadRequestException, HttpStatus, Injectable, InternalServerErrorException } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { Business } from '../entities/business.entity';

@Injectable()
export class BusinessFindService {
  constructor(@InjectModel(Business.name) private readonly businessModel: Model<Business>) {}

  async findOne({ businessId }: { businessId: string }) {
    try {
      const business = await this.businessModel.findOne({ _id: businessId });

      if (!business) throw new BadRequestException({ message: `Negocio no encontrado`, state: false, error: 'Bad Request', statusCode: HttpStatus.BAD_REQUEST });

      return {
        stateCode: HttpStatus.OK,
        message: 'Negocio encontrado',
        data: business,
        state: true,
      };
    } catch (error) {
      if (error instanceof BadRequestException) throw error;

      throw new InternalServerErrorException('Ocurrió un error al encontrar el negocio');
    }
  }

  async findOneByUser({ UserId }: { UserId: string }) {
    try {
      const business = await this.businessModel.findOne({ UserId });

      if (!business) throw new BadRequestException({ message: `No se encontró el negocio del usuario`, state: false, error: 'Bad Request', statusCode: HttpStatus.BAD_REQUEST });

      return {
        stateCode: HttpStatus.OK,
        message: 'Negocio del usuario encontrado',
        data: business,
        state: true,
      };
    } catch (error) {
      if (error instanceof BadRequestException) throw error;

      throw new InternalServerErrorException('Ocurrió un error al encontrar el negocio del usuario');
    }
  }
}
