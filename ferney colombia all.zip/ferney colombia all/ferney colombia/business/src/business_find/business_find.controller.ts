import { Controller, Get, Param } from '@nestjs/common';
import { BusinessFindService } from './business_find.service';
import { BusinessFindByUserDto, BusinessFindDto } from './dto/business_find.dto';

@Controller()
export class BusinessFindController {
  constructor(private readonly businessFindService: BusinessFindService) {}
  @Get('/get/business/find/:businessId')
  findOne(@Param() props: BusinessFindDto) {
    return this.businessFindService.findOne({ businessId: props.businessId });
  }

  @Get('/get/business/find/by/user/:userId')
  findOneByUser(@Param() props: BusinessFindByUserDto) {
    return this.businessFindService.findOneByUser({ UserId: props.userId });
  }
}
