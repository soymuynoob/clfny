import { Module } from '@nestjs/common';
import { BusinessFindService } from './business_find.service';
import { BusinessFindController } from './business_find.controller';
import { MongooseModule } from '@nestjs/mongoose';
import { Business, BusinessSchema } from '../entities/business.entity';

@Module({
  imports: [MongooseModule.forFeature([{ name: Business.name, schema: BusinessSchema }])],
  controllers: [BusinessFindController],
  providers: [BusinessFindService],
})
export class BusinessFindModule {}
