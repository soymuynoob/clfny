import { Test, TestingModule } from '@nestjs/testing';
import { BusinessFindController } from './business_find.controller';
import { BusinessFindService } from './business_find.service';

describe('BusinessFindController', () => {
  let controller: BusinessFindController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [BusinessFindController],
      providers: [BusinessFindService],
    }).compile();

    controller = module.get<BusinessFindController>(BusinessFindController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
