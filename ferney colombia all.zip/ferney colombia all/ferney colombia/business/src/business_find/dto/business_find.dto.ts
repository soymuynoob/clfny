import { IsNotEmpty, IsString, Length } from 'class-validator';

export class BusinessFindDto {
  @IsString({ message: 'El ID del negocio debe ser una cadena de texto' })
  @IsNotEmpty({ message: 'El ID del negocio no puede estar vacío' })
  @Length(24, 24, { message: 'El ID del negocio debe tener 24 caracteres' })
  businessId: string;
}

export class BusinessFindByUserDto {
  @IsString({ message: 'El ID del usuario debe ser una cadena de texto' })
  @IsNotEmpty({ message: 'El ID del usuario no puede estar vacío' })
  @Length(24, 24, { message: 'El ID del usuario debe tener 24 caracteres' })
  userId: string;
}
