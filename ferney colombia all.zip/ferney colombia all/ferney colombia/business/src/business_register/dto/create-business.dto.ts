import { Transform } from 'class-transformer';
import { IsString, IsNotEmpty, IsEmail, Matches, IsOptional, IsMongoId, Length } from 'class-validator';

export class CreateBusinessDto {
  @Transform(({ value }) => value.trim())
  @IsNotEmpty({ message: 'El nombre es obligatorio' })
  @IsString({ message: 'El nombre debe ser una cadena de texto' })
  @Matches(/^\S.*\S$/, {
    message: 'El nombre no puede contener espacios en blanco al principio ni al final',
  })
  Name: string;

  @IsOptional()
  @Transform(({ value }) => value.trim())
  @IsString({ message: 'El correo electrónico debe ser una cadena de texto' })
  @IsEmail({}, { message: 'El formato del correo electrónico no es válido' })
  Email: string;

  @IsOptional()
  @Transform(({ value }) => value.trim())
  @IsString({ message: 'El número de teléfono debe ser una cadena de texto' })
  @Matches(/^[0-9]{7,10}$/, {
    message: 'El número de teléfono debe tener entre 7 y 10 dígitos',
  })
  @Transform(({ value }) => value.replace(/^\+/, ''))
  PhoneNumber: string;

  @IsOptional()
  @Transform(({ value }) => value.trim())
  @IsString({ message: 'La dirección debe ser una cadena de texto' })
  Address: string;

  @Transform(({ value }) => value.trim())
  @IsNotEmpty({ message: 'El ID del usuario es obligatorio' })
  @IsString({ message: 'El ID del usuario debe ser una cadena de texto' })
  @Length(24, 24, { message: 'El ID del usuario debe tener 24 caracteres' })
  @IsMongoId({ message: 'El ID del usuario debe ser un ID válido' })
  UserId: string;
}
