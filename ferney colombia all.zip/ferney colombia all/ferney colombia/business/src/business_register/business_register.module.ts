import { Module } from '@nestjs/common';
import { BusinessRegisterService } from './business_register.service';
import { BusinessRegisterController } from './business_register.controller';
import { MongooseModule } from '@nestjs/mongoose';
import { Business, BusinessSchema } from '../entities/business.entity';

@Module({
  imports: [MongooseModule.forFeature([{ name: Business.name, schema: BusinessSchema }])],
  controllers: [BusinessRegisterController],
  providers: [BusinessRegisterService],
  exports: [BusinessRegisterService, MongooseModule],
})
export class BusinessRegisterModule {}
