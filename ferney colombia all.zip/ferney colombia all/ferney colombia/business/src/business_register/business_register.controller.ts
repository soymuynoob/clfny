import { Controller, Post, Body } from '@nestjs/common';
import { BusinessRegisterService } from './business_register.service';
import { CreateBusinessDto } from './dto/create-business.dto';

@Controller()
export class BusinessRegisterController {
  constructor(private readonly businessRegisterService: BusinessRegisterService) {}

  @Post('/register/business')
  create(@Body() props: CreateBusinessDto) {
    return this.businessRegisterService.create(props);
  }
}
