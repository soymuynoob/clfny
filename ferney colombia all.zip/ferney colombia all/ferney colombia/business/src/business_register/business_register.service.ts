import { BadRequestException, HttpStatus, Injectable, InternalServerErrorException } from '@nestjs/common';
import { CreateBusinessDto } from './dto/create-business.dto';
import { Model } from 'mongoose';
import { Business } from '../entities/business.entity';
import { InjectModel } from '@nestjs/mongoose';

@Injectable()
export class BusinessRegisterService {
  constructor(@InjectModel(Business.name) private readonly model: Model<Business>) {}

  async create(props: CreateBusinessDto) {
    try {
      const payload = {
        ...props,
        Email: (props.Email || '').toLowerCase(),
      };
      const business = await this.model.create(payload);
      return {
        data: business,
        message: 'Negocio creado correctamente',
        state: true,
        statusCode: HttpStatus.CREATED,
      };
    } catch (error) {
      if (error instanceof BadRequestException) throw error;

      throw new InternalServerErrorException('Ocurrió un error al crear el negocio');
    }
  }
}
