import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { MongooseModule } from '@nestjs/mongoose';
import { BusinessRegisterModule } from './business_register/business_register.module';
import { BusinessFindModule } from './business_find/business_find.module';

@Module({
  imports: [MongooseModule.forRoot('mongodb://root:kike123@localhost:27027/business_db?authSource=admin'), BusinessRegisterModule, BusinessFindModule],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
