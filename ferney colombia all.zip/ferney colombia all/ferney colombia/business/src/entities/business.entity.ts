import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document, ObjectId, Types } from 'mongoose';

@Schema({ timestamps: true, versionKey: false, collection: 'businesses' })
export class Business extends Document {
  @Prop({ required: true, trim: true })
  Name: string;

  @Prop({ trim: true })
  Address: string;

  @Prop({ trim: true })
  Email: string;

  @Prop({ trim: true })
  PhoneNumber: string;

  @Prop({ required: true, default: false })
  Blocked: boolean;

  @Prop({ required: true, trim: true, type: Types.ObjectId })
  UserId: ObjectId;

  @Prop({ required: true, default: 0, min: 0 })
  Balance: number;
}
export const BusinessSchema = SchemaFactory.createForClass(Business);
