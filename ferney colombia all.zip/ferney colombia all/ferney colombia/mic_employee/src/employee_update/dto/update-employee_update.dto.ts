import { Transform } from 'class-transformer';
import { IsEmail, IsMongoId, IsNotEmpty, IsNumber, IsOptional, IsString, Length, Min } from 'class-validator';

export class UpdateEmployeeUpdateDto {
  @IsOptional()
  @Transform(({ value }) => value.trim())
  @IsString({ message: 'El nombre debe ser una cadena de texto' })
  @IsNotEmpty({ message: 'El nombre no puede estar vacío' })
  Name: string;

  @IsOptional()
  @Transform(({ value }) => value.trim())
  @IsString({ message: 'El apellido debe ser una cadena de texto' })
  @IsNotEmpty({ message: 'El apellido no puede estar vacío' })
  LastName: string;

  @IsOptional()
  @Transform(({ value }) => value.trim())
  @IsString({ message: 'El correo electrónico debe ser una cadena de texto' })
  @IsNotEmpty({ message: 'El correo electrónico no puede estar vacío' })
  @IsEmail({}, { message: 'El correo electrónico debe ser una dirección de correo válida' })
  Email: string;

  @IsOptional()
  @Transform(({ value }) => value.trim())
  @IsString({ message: 'El número de teléfono debe ser una cadena de texto' })
  @IsNotEmpty({ message: 'El número de teléfono no puede estar vacío' })
  @Transform(({ value }) => value.replace(/^\+/, ''))
  @Length(7, 10, {
    message: 'El número de teléfono debe tener entre 7 y 10 caracteres',
  })
  NumberPhone: string;

  @IsOptional()
  @IsNumber({}, { message: 'El saldo debe ser un número' })
  @IsNotEmpty({ message: 'El saldo no puede estar vacío' })
  @Min(0, { message: 'El saldo debe ser un número positivo' })
  Balance: number;
}

export class EmployeeIDDto {
  @Transform(({ value }) => value.trim())
  @Length(24, 24, {
    message: 'El ID del negocio debe tener exactamente 24 caracteres',
  })
  @IsMongoId({ message: 'El ID del negocio debe ser un ID de MongoDB válido' })
  @IsString({ message: 'El ID del empleado debe ser una cadena de texto' })
  @IsNotEmpty({ message: 'El ID del empleado no puede estar vacío' })
  employeeID: string;
}
