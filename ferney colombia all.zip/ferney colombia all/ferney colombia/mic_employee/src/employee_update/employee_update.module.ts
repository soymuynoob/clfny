import { Module } from '@nestjs/common';
import { EmployeeUpdateService } from './employee_update.service';
import { EmployeeUpdateController } from './employee_update.controller';
import { Employee, EmployeeSchema } from '../entities/employee.entity';
import { MongooseModule } from '@nestjs/mongoose';

@Module({
  imports: [MongooseModule.forFeature([{ name: Employee.name, schema: EmployeeSchema }])],
  controllers: [EmployeeUpdateController],
  providers: [EmployeeUpdateService],
  exports: [EmployeeUpdateService],
})
export class EmployeeUpdateModule {}
