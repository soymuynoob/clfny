import { HttpException, HttpStatus } from '@nestjs/common';

const Origins = [
  {
    name: 'user',
    origin: 'http://localhost:3004',
    paths: [
      { name: 'register_user', pathname: '/register/user' },
      { name: 'register_google_user', pathname: '/register/google/user' },
      { name: 'find_user_by_email', pathname: '/get/user/by/email' },
      { name: 'find_user_and_business', pathname: '/get/user/and/business' },
    ],
  },
  {
    name: 'business',
    origin: 'http://localhost:3001',
    paths: [
      { name: 'register_business', pathname: '/register/business' },
      { name: 'find_business', pathname: '/get/business/find' },
    ],
  },
];
export const GetEndPoint = ({ origin, pathname }: { origin: string; pathname: string }): string => {
  try {
    const getOrigin = Origins.find((route) => route.name === origin) || null;
    if (getOrigin === null) throw new HttpException('Forbidden', HttpStatus.FORBIDDEN);
    const pathOrigin = `${getOrigin.origin}`;

    const getPathname = getOrigin.paths.find((path) => path.name === pathname) || null;
    if (getPathname === null) throw new HttpException('Forbidden', HttpStatus.FORBIDDEN);

    const PathName = `${getPathname.pathname}`;

    return `${pathOrigin}${PathName}`;
  } catch (error) {
    throw error;
  }
};
