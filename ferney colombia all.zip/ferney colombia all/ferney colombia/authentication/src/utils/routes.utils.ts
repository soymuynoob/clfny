const BASE_URL_USER = 'http://localhost:3003';
const BASE_URL_BUSINESS = 'http://localhost:3002';

export const ROUTES_MS = {
  USERS: {
    CREATE_USER: `${BASE_URL_USER}/user/register/user`,
    CREATE_GOOGLE_USER: `${BASE_URL_USER}/user/register/google/user`,
    FIND_USER_BY_EMAIL: `${BASE_URL_USER}/user/get/user/by/email`,
    GET_ALL_USERS: `${BASE_URL_USER}/user/all/users`,
  },
  BUSINESS: {
    CREATE_BUSINESS: `${BASE_URL_BUSINESS}/business/register/business`,
  },
};
