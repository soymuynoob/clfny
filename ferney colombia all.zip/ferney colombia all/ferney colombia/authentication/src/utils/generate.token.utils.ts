import { JwtService } from '@nestjs/jwt';
import axios from 'axios';
import { GetEndPoint } from './enpoints';
import { BadRequestException, HttpException, HttpStatus } from '@nestjs/common';
import * as dotenv from 'dotenv';

dotenv.config();

const jwtService = new JwtService({
  secret: process.env.JWT_SECRET,
});

export async function generateToken({ userId }: { userId: string }): Promise<string> {
  try {
    const url = GetEndPoint({
      origin: 'user',
      pathname: 'find_user_and_business',
    });
    console.log(`${url}/${userId}`);

    const response = await axios.get(`${url}/${userId}`);
    const payload = { userId, ...response.data };

    return jwtService.sign(payload);
  } catch (error) {
    console.log(error);

    if (error.response.data?.statusCode?.includes(4)) {
      const message = Array.isArray(error.response.data.message) ? error.response.data.message[0] : error.response.data.message;
      throw new BadRequestException(message);
    }
    throw new HttpException({ message: 'Ocurrió un error al generar el token', state: false }, HttpStatus.INTERNAL_SERVER_ERROR);
  }
}
