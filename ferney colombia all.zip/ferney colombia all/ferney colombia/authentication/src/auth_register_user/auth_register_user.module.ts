import { Module } from '@nestjs/common';
import { AuthRegisterUserService } from './auth_register_user.service';
import { AuthRegisterUserController } from './auth_register_user.controller';


@Module({
  imports: [],
  controllers: [AuthRegisterUserController],
  providers: [AuthRegisterUserService],
})
export class AuthRegisterUserModule {}
