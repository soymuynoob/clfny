import { BadRequestException, Injectable, InternalServerErrorException } from '@nestjs/common';
import { CreateAuthRegisterUserDto } from './dto/create-auth_register_user.dto';
import axios from 'axios';
import { LoginInterface } from './interface/login.interface';
import { GetEndPoint } from '../utils/enpoints';
import { generateToken } from '../utils/generate.token.utils';

@Injectable()
export class AuthRegisterUserService {
  constructor() {}

  async create(props: CreateAuthRegisterUserDto): Promise<LoginInterface> {
    try {
      const { BusinessName, Email, LastName, Name, Password, PhoneNumber } = props;
      const PayloadUser = { Name, LastName, Email, PhoneNumber, Password };

      const urlUser = GetEndPoint({ origin: 'user', pathname: 'register_user' });
      const urlBusiness = GetEndPoint({ origin: 'business', pathname: 'register_business' });

      const user = await axios.post(urlUser, PayloadUser);

      const payloadBusiness = { Name: BusinessName, UserId: user.data.data._id };

      await axios.post(urlBusiness, payloadBusiness);

      // Generar token
      const Token = await generateToken({ userId: user.data.data._id });

      return {
        message: 'Usuario y negocio registrados correctamente',
        state: true,
        accessToken: Token,
      };
    } catch (error) {
      if (error instanceof BadRequestException) throw error;

      if (error.response.data.statusCode === 400)
        throw new BadRequestException(
          Array.isArray(error.response.data.message) ? error.response.data.message[0] : error.response.data.message,
        );

      throw new InternalServerErrorException('Ocurrió un error al crear el usuario');
    }
  }
}
