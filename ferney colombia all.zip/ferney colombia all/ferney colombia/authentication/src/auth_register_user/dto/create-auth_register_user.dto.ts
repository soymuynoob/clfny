import { Transform } from 'class-transformer';
import { IsEmail, IsNotEmpty, IsOptional, IsString, Matches } from 'class-validator';

export class CreateAuthRegisterUserDto {
  @Transform(({ value }) => value.trim())
  @IsString({ message: 'El nombre debe ser una cadena de texto válida' })
  @IsNotEmpty({ message: 'Por favor, ingrese un nombre' })
  Name: string;

  @IsOptional()
  @Transform(({ value }) => value.trim())
  @IsString({ message: 'El apellido debe ser una cadena de texto válida' })
  @IsNotEmpty({ message: 'Por favor, ingrese un apellido' })
  LastName: string;

  @Transform(({ value }) => value.trim())
  @IsString({ message: 'El correo electrónico debe ser una cadena de texto válida' })
  @IsNotEmpty({ message: 'Por favor, ingrese un correo electrónico' })
  @IsEmail({}, { message: 'Por favor, ingrese un correo electrónico válido' })
  Email: string;

  @IsOptional()
  @Transform(({ value }) => value.trim())
  @IsString({ message: 'El número de teléfono debe ser una cadena de texto válida' })
  @IsNotEmpty({ message: 'Por favor, ingrese un número de teléfono' })
  @IsString({ message: 'El número de teléfono debe ser una cadena de texto' })
  @Matches(/^[0-9]{10}$/, { message: 'Ingrese un numero de telefono movil valido.' })
  @Transform(({ value }) => value.replace(/^\+/, ''))
  PhoneNumber: string;

  @Transform(({ value }) => value.trim())
  @IsString({ message: 'La contraseña debe ser una cadena de texto válida' })
  @IsNotEmpty({ message: 'Por favor, ingrese una contraseña' })
  @Matches(/^.{8,}$/, { message: 'La contraseña debe tener al menos 8 caracteres' })
  Password: string;

  //   BUSINESS

  @Transform(({ value }) => value.trim())
  @IsNotEmpty({ message: 'El nombre es obligatorio' })
  @IsString({ message: 'El nombre debe ser una cadena de texto' })
  @Matches(/^\S.*\S$/, { message: 'El nombre no puede contener espacios en blanco al principio ni al final' })
  BusinessName: string;
}
