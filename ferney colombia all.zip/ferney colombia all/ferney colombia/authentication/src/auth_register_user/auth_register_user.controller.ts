import { Controller, Post, Body } from '@nestjs/common';
import { AuthRegisterUserService } from './auth_register_user.service';
import { CreateAuthRegisterUserDto } from './dto/create-auth_register_user.dto';

@Controller()
export class AuthRegisterUserController {
  constructor(private readonly authRegisterUserService: AuthRegisterUserService) {}

  @Post('/auth/register/user')
  async create(@Body() props: CreateAuthRegisterUserDto) {
    return await this.authRegisterUserService.create(props);
  }
}
