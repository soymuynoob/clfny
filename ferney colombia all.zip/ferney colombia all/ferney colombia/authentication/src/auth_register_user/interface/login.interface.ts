export interface LoginInterface {
  message: string;
  accessToken: string;
  state: boolean;
}
