import { BadRequestException, HttpException, HttpStatus, Inject, Injectable, InternalServerErrorException } from '@nestjs/common';
import { AuthUserDto } from './dto/auth-user.dto';
import * as bcrypt from 'bcryptjs';
import axios from 'axios';
import { LoginInterface } from './interface/login.interface';
import { generateToken } from '../utils/generate.token.utils';
import { GetEndPoint } from '../utils/enpoints';

@Injectable()
export class SimpleAuthService {
  constructor() {}

  async Service_AuthUser(data: AuthUserDto): Promise<LoginInterface> {
    try {
      const { password, userEmail } = data;

      const url = GetEndPoint({ origin: 'user', pathname: 'find_user_by_email' });

      const user = await axios.get(`${url}?Email=${userEmail}`);

      const userResponse = user.data;

      if (!userResponse?.state) throw new BadRequestException('Correo no asociado a una cuenta. Por favor, regístrese antes de iniciar sesión.');

      if (userResponse.blocked) throw new BadRequestException('Esta cuenta se encuentra bloqueada. Por favor, contacte al administrador');

      const isPasswordValid = await bcrypt.compare(password, userResponse.password);

      if (!isPasswordValid) throw new BadRequestException('Credenciales inválidas. Por favor, verifique su correo electrónico y contraseña');

      const Token = await generateToken({ userId: userResponse._id });

      return {
        accessToken: Token,
        message: 'Autenticación exitosa',
        state: true,
      };
    } catch (error) {
      if (error instanceof BadRequestException) throw error;

      throw new InternalServerErrorException('Ocurrió un error al autenticar el usuario');
    }
  }
}
