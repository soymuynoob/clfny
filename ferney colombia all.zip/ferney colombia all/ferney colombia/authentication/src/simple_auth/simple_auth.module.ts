import { Module } from '@nestjs/common';
import { SimpleAuthService } from './simple_auth.service';
import { SimpleAuthController } from './simple_auth.controller';

@Module({
  imports: [],
  controllers: [SimpleAuthController],
  providers: [SimpleAuthService],
  exports: [SimpleAuthService],
})
export class SimpleAuthModule {}
