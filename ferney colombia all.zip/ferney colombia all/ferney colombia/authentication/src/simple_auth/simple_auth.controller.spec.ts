import { Test, TestingModule } from '@nestjs/testing';
import { SimpleAuthController } from './simple_auth.controller';
import { SimpleAuthService } from './simple_auth.service';

describe('SimpleAuthController', () => {
  let controller: SimpleAuthController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [SimpleAuthController],
      providers: [SimpleAuthService],
    }).compile();

    controller = module.get<SimpleAuthController>(SimpleAuthController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
