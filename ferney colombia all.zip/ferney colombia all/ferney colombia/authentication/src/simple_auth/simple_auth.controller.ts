import { Body, Controller, Post } from '@nestjs/common';
import { SimpleAuthService } from './simple_auth.service';
import { AuthUserDto } from './dto/auth-user.dto';

@Controller()
export class SimpleAuthController {
  constructor(private readonly simpleAuthService: SimpleAuthService) {}

  @Post('auth/user')
  async authenticateUser(@Body() credentials: AuthUserDto) {
    return await this.simpleAuthService.Service_AuthUser(credentials);
  }
}
