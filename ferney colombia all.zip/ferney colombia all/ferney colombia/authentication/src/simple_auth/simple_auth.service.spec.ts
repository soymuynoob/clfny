import { Test, TestingModule } from '@nestjs/testing';
import { SimpleAuthService } from './simple_auth.service';
import { ConfigModule } from '@nestjs/config';

describe('SimpleAuthService', () => {
  let service: SimpleAuthService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      imports: [ConfigModule],
      providers: [SimpleAuthService],
    }).compile();

    service = module.get<SimpleAuthService>(SimpleAuthService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
