export interface LoginInterface {
  message: string;
  accessToken: string;
  state: boolean;
  isRegister: boolean;
}

export interface GoogleAuthPayload {
  email: string;
  given_name: string;
  family_name: string;
}
