import { BadRequestException, HttpException, HttpStatus, Injectable, InternalServerErrorException } from '@nestjs/common';
import { OAuth2Client } from 'google-auth-library';
import axios from 'axios';
import { GoogleAuthPayload, LoginInterface } from './interface/login.interface';
import { GetEndPoint } from '../utils/enpoints';
import { generateToken } from '../utils/generate.token.utils';
const client = new OAuth2Client(process.env['GOOGLE_CLIENT_ID']);

@Injectable()
export class AuthGoogleService {
  constructor() {}
  async verifyToken({ token_google }: { token_google: string }) {
    try {
      const ticket = await client.verifyIdToken({idToken: token_google, audience: process.env.GOOGLE_CLIENT_ID});
      
      return ticket.getPayload();

    } catch (error) {

      if (error.message.includes('Token used too late')) throw new BadRequestException('El token de Google ha expirado. Por favor, inicie sesión nuevamente.');

      if (error.message.includes('invalid')) throw new BadRequestException('El token de Google es inválido. Por favor, intente iniciar sesión nuevamente.');

      throw new InternalServerErrorException('Error al verificar el token de Google. Por favor, intente más tarde.');
    }
  }

  async authenticateGoogle(payload: GoogleAuthPayload): Promise<LoginInterface> {
    try {
      const { email, given_name, family_name } = payload;

      // Verificar si el usuario existe
      const url = GetEndPoint({ origin: 'user', pathname: 'find_user_by_email' });

      const user = await axios.get(`${url}?Email=${email}`);

      const userResponse = user.data;

      // si no tiene cuenta se le crea una y luego se genera un token
      if (userResponse.state === false) return await this.createGoogleUser({ email, given_name, family_name });

      // Usuario bloqueado
      if (userResponse.blocked) throw new BadRequestException('Usuario bloqueado. Por favor, contacte con el administrador para obtener ayuda.');

      // Si la cuenta no está vinculada a Google
      if (!userResponse.isGoogle) throw new BadRequestException('La cuenta existe pero no está vinculada a Google. Por favor, realice el inicio de sesión normal.');

      const Token = await generateToken({ userId: userResponse._id });

      return {
        accessToken: Token,
        message: 'Autenticación exitosa',
        state: true,
        isRegister: false,
      };
    } catch (error) {
      if (error instanceof BadRequestException) throw error;

      throw new InternalServerErrorException('Ocurrió un error al crear el usuario');
    }
  }

  async createGoogleUser(props: GoogleAuthPayload) {
    try {
      const { email, given_name, family_name } = props;

      const url = GetEndPoint({ origin: 'user', pathname: 'register_google_user' });

      const payload = {
        Email: email,
        Name: given_name,
        LastName: family_name,
      };

      const newUserResponse = await axios.post(url, payload);

      const newUser = newUserResponse.data.data;

      if (!newUser?._id) throw new BadRequestException('Error al crear nuevo usuario');

      const Token = await generateToken({ userId: newUser._id });

      return {
        accessToken: Token,
        message: 'Autenticación exitosa',
        state: true,
        isRegister: true,
      };
    } catch (error) {
      if (error instanceof BadRequestException) throw error;

      throw new InternalServerErrorException('Ocurrió un error al crear el usuario');
    }
  }
}
