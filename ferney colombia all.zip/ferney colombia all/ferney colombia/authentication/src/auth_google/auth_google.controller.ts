import { Body, Controller, Post } from '@nestjs/common';
import { AuthGoogleService } from './auth_google.service';
import { SecureAuthenticateGoogleDto } from './dto/AuthGoogleDto';
import { GoogleAuthPayload } from './interface/login.interface';

@Controller()
export class AuthGoogleController {
  constructor(private readonly authGoogleService: AuthGoogleService) {}

  @Post('/secure/authenticate/google')
  async AuthGoogle(@Body() props: SecureAuthenticateGoogleDto) {
    const { token_google } = props;

    const payload = await this.authGoogleService.verifyToken({ token_google });

    return await this.authGoogleService.authenticateGoogle(payload as GoogleAuthPayload);
  }
}
