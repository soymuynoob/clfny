import { Test, TestingModule } from '@nestjs/testing';
import { AuthGoogleController } from './auth_google.controller';
import { AuthGoogleService } from './auth_google.service';

describe('AuthGoogleController', () => {
  let controller: AuthGoogleController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [AuthGoogleController],
      providers: [AuthGoogleService],
    }).compile();

    controller = module.get<AuthGoogleController>(AuthGoogleController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
