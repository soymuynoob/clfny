import { Transform } from 'class-transformer';
import { IsNotEmpty, IsString } from 'class-validator';

export class SecureAuthenticateGoogleDto {
  @Transform(({ value }) => value.trim())
  @IsString({ message: 'El token de Google debe ser una cadena de texto' })
  @IsNotEmpty({ message: 'El token de Google no puede estar vacío' })
  token_google: string;
}
