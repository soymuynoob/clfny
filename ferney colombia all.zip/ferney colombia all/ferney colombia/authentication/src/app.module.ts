import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { MongooseModule } from '@nestjs/mongoose';
import { SimpleAuthModule } from './simple_auth/simple_auth.module';
import { SimpleAuthService } from './simple_auth/simple_auth.service';
import { SimpleAuthController } from './simple_auth/simple_auth.controller';
import { AuthGoogleModule } from './auth_google/auth_google.module';
import { AuthGoogleController } from './auth_google/auth_google.controller';
import { AuthGoogleService } from './auth_google/auth_google.service';
import { AuthRegisterUserModule } from './auth_register_user/auth_register_user.module';
import { AuthRegisterUserService } from './auth_register_user/auth_register_user.service';
import { AuthRegisterUserController } from './auth_register_user/auth_register_user.controller';


@Module({
  imports: [
    MongooseModule.forRoot('mongodb://root:kike123@localhost:27027/auth_db?authSource=admin'),
    SimpleAuthModule,
    AuthGoogleModule,
    AuthRegisterUserModule,
  ],
  controllers: [AppController, SimpleAuthController, AuthGoogleController, AuthRegisterUserController],
  providers: [AppService, SimpleAuthService, AuthGoogleService, AuthRegisterUserService],
})
export class AppModule {}
