import { Module } from '@nestjs/common';
import { MicProductsArchivateService } from './mic_products_archivate.service';
import { MicProductsArchivateController } from './mic_products_archivate.controller';
import { MongooseModule } from '@nestjs/mongoose';
import { Products, ProductSchema } from '../entities/mic_product.entity';
import { FilesModule } from '../files/files.module';

@Module({
  imports: [MongooseModule.forFeature([{ name: Products.name, schema: ProductSchema }]), FilesModule],
  controllers: [MicProductsArchivateController],
  providers: [MicProductsArchivateService],
  exports: [MicProductsArchivateService, MongooseModule],
})
export class MicProductsArchivateModule {}
