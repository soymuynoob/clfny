import { Controller, Param, Put } from '@nestjs/common';
import { MicProductsArchivateService } from './mic_products_archivate.service';
import { FindProductArchivateDto } from './dto/find-mic_products_archivate.dto';

@Controller()
export class MicProductsArchivateController {
  constructor(private readonly micProductsArchivateService: MicProductsArchivateService) {}

  @Put('/update/archive/product/:id')
  updateArchiveProduct(@Param() param: FindProductArchivateDto) {
    return this.micProductsArchivateService.updateArchiveProduct({ id: param.id });
  }
}
