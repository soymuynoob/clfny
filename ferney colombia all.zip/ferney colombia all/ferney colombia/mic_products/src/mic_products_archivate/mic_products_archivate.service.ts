import { BadRequestException, HttpStatus, Injectable, InternalServerErrorException } from '@nestjs/common';
import { Model } from 'mongoose';
import { Products } from '../entities/mic_product.entity';
import { InjectModel } from '@nestjs/mongoose';
import { FindProductArchivateDto } from './dto/find-mic_products_archivate.dto';

@Injectable()
export class MicProductsArchivateService {
  constructor(@InjectModel(Products.name) private readonly productModel: Model<Products>) {}

  async updateArchiveProduct({ id }: FindProductArchivateDto) {
    try {
      const findProduct = await this.productModel.findById(id);

      if (!findProduct) throw new BadRequestException('Producto no encontrado');

      await this.productModel.findByIdAndUpdate(id, { IsArchived: !findProduct.IsArchived });

      return {
        message: findProduct.IsArchived ? 'Producto activado exitosamente' : 'Producto archivado exitosamente',
        state: !findProduct.IsArchived,
        statusCode: HttpStatus.OK,
      };
    } catch (error) {
      if (error instanceof BadRequestException) throw error;

      throw new InternalServerErrorException('Ocurrió un error al archivar el producto');
    }
  }
}
