import { Controller, Body, UseInterceptors, UploadedFiles, Param, Put } from '@nestjs/common';
import { MicProductsUpdateService } from './mic_products_update.service';
import { FilesInterceptor } from '@nestjs/platform-express';
import { fileFilter, storageConfig } from 'src/files/helpers/file.helpers';
import { UpdateMicProductDto } from './dto/update-mic_product.dto';
import { IDDto } from './dto/find-mic_product.dto';

@Controller()
export class MicProductsUpdateController {
  constructor(private readonly micProductsUpdateService: MicProductsUpdateService) {}

  @Put('/update/product/:id')
  @UseInterceptors(
    FilesInterceptor('files', undefined, {
      fileFilter: fileFilter, // Asegúrate de tener esto definido
      storage: storageConfig,
    }),
  )
  update(@UploadedFiles() files: Express.Multer.File[], @Param() Param: IDDto, @Body() props: UpdateMicProductDto) {
    return this.micProductsUpdateService.update({ id: Param.id, props, files });
  }
}
