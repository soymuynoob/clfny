import { BadRequestException, HttpStatus, Injectable, InternalServerErrorException } from '@nestjs/common';
import { Model } from 'mongoose';
import { Products } from '../entities/mic_product.entity';
import { InjectModel } from '@nestjs/mongoose';
import { UpdateMicProductDto } from './dto/update-mic_product.dto';
import { verifyPrices } from './middlewares/functions.services.middewares';
import { promises as fs } from 'fs';
import * as path from 'path';

@Injectable()
export class MicProductsUpdateService {
  constructor(@InjectModel(Products.name) private readonly productModel: Model<Products>) {}

  async update({ id, props, files }: { id: string; props: UpdateMicProductDto; files: Express.Multer.File[] }) {
    try {
      const { Cost, Prices } = props;

      const formattedPrices = verifyPrices({ Prices, Cost });

      const findProduct = await this.productModel.findById(id);
      if (!findProduct) throw new BadRequestException('Producto no encontrado');

      const Images = [];

      if (files.length > 0) {
        const productDir = path.join(__dirname, '..', '..', 'public', 'images', 'companies', findProduct.BusinessID.toString(), id);

        // Eliminar la carpeta del producto si existe
        await fs.rm(productDir, { recursive: true, force: true });

        for (const file of files) {
          const oldPath = file.path;
          const newPath = path.join(__dirname, '..', '..', 'public', 'images', 'companies', findProduct.BusinessID.toString(), id, file.filename);

          Images.push(newPath.replaceAll('\\', '/'));

          // Crear los directorios si no existen y mover las imágenes
          await fs.mkdir(path.dirname(newPath), { recursive: true });
          await fs.rename(oldPath, newPath);
        }
      }

      const findProductAfter = await this.productModel.findById(id);
      const UpdatedProduct = {
        ...props,
        Prices: formattedPrices,
        Images: Images.length > 0 ? Images : findProductAfter.Images,
      };

      const product = await this.productModel.findByIdAndUpdate(id, UpdatedProduct, { new: true });

      return {
        message: 'Producto actualizado exitosamente',
        data: product,
        state: true,
        statusCode: HttpStatus.OK,
      };
    } catch (error) {
      console.log(error, 'error');

      if (error instanceof BadRequestException) throw error;

      throw new InternalServerErrorException('Ocurrió un error al actualizar el producto');
    }
  }
}
