import { Transform, Type } from 'class-transformer';
import { ArrayNotEmpty, IsArray, IsNotEmpty, IsNumber, IsOptional, IsString, Max, Min, ValidateNested } from 'class-validator';

export class PriceDto {
  @Type(() => Number)
  @IsNumber({ allowNaN: false }, { message: 'El stock debe ser un número válido.' })
  @IsNotEmpty({ message: 'El precio de venta es obligatorio.' })
  @Min(0, { message: 'El precio de venta no puede ser negativo.' })
  SellPrice: number;

  @Type(() => Number)
  @IsNumber({ allowNaN: false }, { message: 'El stock debe ser un número válido.' })
  @IsNotEmpty({ message: 'La ganancia es obligatoria.' })
  @Min(0, { message: 'La ganancia no puede ser negativa.' })
  Profit: number;

  @Type(() => Number)
  @IsNumber({ allowNaN: false }, { message: 'El stock debe ser un número válido.' })
  @IsNotEmpty({ message: 'El margen es obligatorio.' })
  @Min(0, { message: 'El margen no puede ser negativo.' })
  @Max(100, { message: 'El margen no puede ser mayor a 100%.' })
  Margin: number;
}

export class CreateMicProductDto {
  @IsString({ message: 'El ID del negocio debe ser una cadena de texto.' })
  @Transform(({ value }) => value.trim())
  @IsNotEmpty({
    message: 'Por favor, proporciona el ID del negocio asociado a este producto. Este dato es fundamental.',
  })
  BusinessID: string;

  @IsString({ message: 'El nombre del producto debe ser una cadena de texto.' })
  @Transform(({ value }) => value.trim())
  @IsNotEmpty({
    message: 'Parece que olvidaste nombrar tu producto. ¿Cuál será su nombre?',
  })
  Name: string;

  @Type(() => Number)
  @IsNumber(
    { allowNaN: false },
    {
      message: 'El stock debe ser un número válido. Por favor, verifica e intenta nuevamente.',
    },
  )
  @IsNotEmpty({
    message: 'Indícanos cuántas unidades hay disponibles en stock. ¡Este dato es esencial para gestionar tu inventario!',
  })
  Stock: number;

  @Type(() => Number)
  @IsNumber(
    { allowNaN: false },
    {
      message: 'El costo debe ser un número válido. Asegúrate de ingresar un monto correcto.',
    },
  )
  @IsNotEmpty({
    message: 'Por favor, ingresa el costo de este producto. Es importante para calcular tus márgenes de ganancia.',
  })
  @Min(0, {
    message: 'El costo no puede ser negativo. Verifica el monto e ingrésalo nuevamente.',
  })
  Cost: number;

  @IsOptional()
  @IsString({ message: 'El código SKU debe ser una cadena de texto.' })
  @Transform(({ value }) => value.trim())
  @IsNotEmpty({
    message: 'Si tienes un código SKU, no lo dejes vacío. Es clave para identificar tu producto de manera eficiente.',
  })
  SkuCode?: string;

  @IsOptional()
  @IsString({ message: 'El código de barras debe ser una cadena de texto.' })
  @Transform(({ value }) => value.trim())
  @IsNotEmpty({
    message: 'Por favor, proporciona un código de barras válido si tu producto lo tiene. Esto ayudará a facilitar el proceso de venta.',
  })
  BarCode?: string;

  @IsArray({ message: 'La lista de precios debe ser un array.' })
  @ArrayNotEmpty({
    message: 'La lista de precios no puede estar vacía. Asegúrate de agregar al menos un precio.',
  })
  @ValidateNested({ each: true })
  @Type(() => PriceDto)
  Prices: PriceDto[];

  @IsOptional() // Esto permitirá que el campo files sea opcional
  files?: Express.Multer.File[];
}
