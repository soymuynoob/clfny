import { Transform } from 'class-transformer';
import { IsMongoId, IsNotEmpty, IsString, Length } from 'class-validator';

export class IDDto {
  @Transform(({ value }) => value.trim())
  @Length(24, 24, {
    message: 'El ID del negocio debe tener exactamente 24 caracteres',
  })
  @IsMongoId({ message: 'El ID del negocio debe ser un ID de MongoDB válido' })
  @IsString({ message: 'El ID del empleado debe ser una cadena de texto' })
  @IsNotEmpty({ message: 'El ID del empleado no puede estar vacío' })
  id: string;
}
