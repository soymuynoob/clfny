import { PartialType } from '@nestjs/mapped-types';
import { ArrayNotEmpty, IsArray, IsNotEmpty, IsNumber, IsOptional, IsString, Max, Min, ValidateNested } from 'class-validator';
import { Transform, Type } from 'class-transformer';
import { CreateMicProductDto } from './create-mic_product.dto';

export class PriceDto {
  @Type(() => Number)
  @IsNumber({ allowNaN: false }, { message: 'El stock debe ser un número válido.' })
  @IsNotEmpty({ message: 'El precio de venta es obligatorio.' })
  @Min(0, { message: 'El precio de venta no puede ser negativo.' })
  SellPrice: number;

  @Type(() => Number)
  @IsNumber({ allowNaN: false }, { message: 'El stock debe ser un número válido.' })
  @IsNotEmpty({ message: 'La ganancia es obligatoria.' })
  @Min(0, { message: 'La ganancia no puede ser negativa.' })
  Profit: number;

  @Type(() => Number)
  @IsNumber({ allowNaN: false }, { message: 'El stock debe ser un número válido.' })
  @IsNotEmpty({ message: 'El margen es obligatorio.' })
  @Min(0, { message: 'El margen no puede ser negativo.' })
  @Max(100, { message: 'El margen no puede ser mayor a 100%.' })
  Margin: number;
}

export class UpdateMicProductDto extends PartialType(CreateMicProductDto) {
  @IsString({ message: 'El nombre debe ser una cadena de texto.' })
  @IsNotEmpty({ message: 'El nombre es obligatorio.' })
  Name: string;

  @IsNumber(
    { allowNaN: false },
    {
      message: 'El stock debe ser un número válido. Por favor, verifica e intenta nuevamente.',
    },
  )
  @IsNotEmpty({
    message: 'Indícanos cuántas unidades hay disponibles en stock. ¡Este dato es esencial para gestionar tu inventario!',
  })
  Stock?: number;

  @Type(() => Number)
  @IsNumber(
    { allowNaN: false },
    {
      message: 'El costo debe ser un número válido. Asegúrate de ingresar un monto correcto.',
    },
  )
  @IsNotEmpty({
    message: 'Por favor, ingresa el costo de este producto. Es importante para calcular tus márgenes de ganancia.',
  })
  Cost?: number;

  @IsOptional()
  @IsString({ message: 'El código SKU debe ser una cadena de texto.' })
  @Transform(({ value }) => value.trim())
  @IsNotEmpty({
    message: 'Si tienes un código SKU, no lo dejes vacío. Es clave para identificar tu producto de manera eficiente.',
  })
  SkuCode?: string;

  @IsOptional()
  @IsString({ message: 'El código de barras debe ser una cadena de texto.' })
  @Transform(({ value }) => value.trim())
  @IsNotEmpty({
    message: 'Por favor, proporciona un código de barras válido si tu producto lo tiene. Esto ayudará a facilitar el proceso de venta.',
  })
  BarCode?: string;

  @IsOptional()
  @IsArray({ message: 'La lista de precios debe ser un array.' })
  @ArrayNotEmpty({
    message: 'La lista de precios no puede estar vacía. Asegúrate de agregar al menos un precio.',
  })
  @ValidateNested({ each: true })
  @Type(() => PriceDto)
  Prices: PriceDto[];
}
