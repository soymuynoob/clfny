import { Module } from '@nestjs/common';
import { MicProductsUpdateService } from './mic_products_update.service';
import { MicProductsUpdateController } from './mic_products_update.controller';
import { MongooseModule } from '@nestjs/mongoose';
import { Products, ProductSchema } from '../entities/mic_product.entity';
import { FilesModule } from '../files/files.module';

@Module({
  imports: [MongooseModule.forFeature([{ name: Products.name, schema: ProductSchema }]), FilesModule],
  controllers: [MicProductsUpdateController],
  providers: [MicProductsUpdateService],
  exports: [MicProductsUpdateService, MongooseModule],
})
export class MicProductsUpdateModule {}
