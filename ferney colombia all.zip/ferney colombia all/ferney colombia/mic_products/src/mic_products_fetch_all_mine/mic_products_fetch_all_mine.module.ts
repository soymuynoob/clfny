import { Module } from '@nestjs/common';
import { MicProductsFetchAllMineService } from './mic_products_fetch_all_mine.service';
import { MicProductsFetchAllMineController } from './mic_products_fetch_all_mine.controller';
import { MongooseModule } from '@nestjs/mongoose';
import { Products, ProductSchema } from '../entities/mic_product.entity';
import { FilesModule } from '../files/files.module';

@Module({
  imports: [MongooseModule.forFeature([{ name: Products.name, schema: ProductSchema }]), FilesModule],
  controllers: [MicProductsFetchAllMineController],
  providers: [MicProductsFetchAllMineService],
  exports: [MicProductsFetchAllMineService, MongooseModule],
})
export class MicProductsFetchAllMineModule {}
