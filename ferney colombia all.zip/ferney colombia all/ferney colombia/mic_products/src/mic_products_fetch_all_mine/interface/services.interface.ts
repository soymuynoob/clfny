import { Products } from 'src/entities/mic_product.entity';

export interface ProductResponse {
  message: string;
  limit: number;
  page: number;
  totalCount: number;
  data: Products[];
  statusCode: number;
}
