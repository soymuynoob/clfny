import { Transform } from 'class-transformer';
import { IsBoolean, IsNumber, IsOptional, IsString } from 'class-validator';

export class GetMyMicProductsDto {
  @Transform(({ value }) => parseInt(value))
  @IsNumber({}, { message: 'La página debe ser un número' })
  @IsOptional({ message: 'El campo página es opcional' })
  page: number;

  @Transform(({ value }) => parseInt(value))
  @IsNumber({}, { message: 'El límite debe ser un número' })
  @IsOptional()
  limit: number;

  @Transform(({ value }) => value.trim())
  @IsString({ message: 'La búsqueda debe ser una cadena de texto' })
  @IsOptional()
  search: string;

  @IsBoolean({ message: 'El estado de archivado debe ser un valor booleano' })
  @IsOptional()
  IsArchived: boolean;
}
