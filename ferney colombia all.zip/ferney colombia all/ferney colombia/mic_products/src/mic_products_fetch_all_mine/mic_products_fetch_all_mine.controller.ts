import { Body, Controller, Param, Post, Put } from '@nestjs/common';
import { MicProductsFetchAllMineService } from './mic_products_fetch_all_mine.service';
import { GetMyMicProductsDto } from './dto/get-my-mic_products';

@Controller()
export class MicProductsFetchAllMineController {
  constructor(private readonly micProductsFetchAllMineService: MicProductsFetchAllMineService) {}

  @Post('fetch/all/mine')
  fetchAllMine(@Body() props: GetMyMicProductsDto) {
    return this.micProductsFetchAllMineService.fetchAllMine(props);
  }
}
