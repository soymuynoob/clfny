import { BadRequestException, HttpStatus, Injectable, InternalServerErrorException } from '@nestjs/common';
import { Model } from 'mongoose';
import { Products } from '../entities/mic_product.entity';
import { InjectModel } from '@nestjs/mongoose';
import { GetMyMicProductsDto } from './dto/get-my-mic_products';
import { ProductResponse } from './interface/services.interface';

@Injectable()
export class MicProductsFetchAllMineService {
  constructor(@InjectModel(Products.name) private readonly productModel: Model<Products>) {}

  async fetchAllMine(props: GetMyMicProductsDto): Promise<ProductResponse> {
    try {
      // TODO:conseguir del tiken el id del negocio
      const { page = 1, limit = 100, search, IsArchived } = props;

      const skip = (page - 1) * limit;
      const query: any = {};

      if (search) {
        query.$or = [{ Name: { $regex: search, $options: 'i' } }, { SkuCode: { $regex: search, $options: 'i' } }, { BarCode: { $regex: search, $options: 'i' } }];
      }
      if (IsArchived !== undefined) query.IsArchived = IsArchived;

      const [products, totalCount] = await Promise.all([this.productModel.find(query).skip(skip).limit(limit).sort({ createdAt: -1 }), this.productModel.countDocuments(query)]);

      return {
        message: 'Productos obtenidos exitosamente',
        limit,
        page,
        totalCount,
        data: products,
        statusCode: HttpStatus.OK,
      } as ProductResponse;
    } catch (error) {
      if (error instanceof BadRequestException) throw error;

      throw new InternalServerErrorException('Ocurrió un error al obtener los productos');
    }
  }
}
