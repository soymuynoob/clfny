import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { MongooseModule } from '@nestjs/mongoose';
import { ServeStaticModule } from '@nestjs/serve-static';
import { join } from 'path';
import { FilesModule } from './files/files.module';
import { MicProductsArchivateModule } from './mic_products_archivate/mic_products_archivate.module';
import { MicProductsRegisterModule } from './mic_products_register/mic_products_register.module';
import { MicProductsUpdateModule } from './mic_products_update/mic_products_update.module';
import { MicProductsRegisterService } from './mic_products_register/mic_products_register.service';
import { MicProductsUpdateService } from './mic_products_update/mic_products_update.service';
import { MicProductsArchivateService } from './mic_products_archivate/mic_products_archivate.service';
import { MicProductsRegisterController } from './mic_products_register/mic_products_register.controller';
import { MicProductsUpdateController } from './mic_products_update/mic_products_update.controller';
import { MicProductsArchivateController } from './mic_products_archivate/mic_products_archivate.controller';
import { MicProductsFetchAllMineModule } from './mic_products_fetch_all_mine/mic_products_fetch_all_mine.module';
import { MicProductsFetchAllMineService } from './mic_products_fetch_all_mine/mic_products_fetch_all_mine.service';
import { MicProductsFetchAllMineController } from './mic_products_fetch_all_mine/mic_products_fetch_all_mine.controller';

@Module({
  imports: [
    MongooseModule.forRoot('mongodb://root:kike123@localhost:27027/mic_products_db?authSource=admin'),
    ServeStaticModule.forRoot({ rootPath: join(__dirname, '..', 'public'), serveRoot: '/public/' }),
    FilesModule,
    MicProductsRegisterModule,
    MicProductsUpdateModule,
    MicProductsArchivateModule,
    MicProductsFetchAllMineModule,
  ],
  controllers: [AppController, MicProductsRegisterController, MicProductsUpdateController, MicProductsArchivateController, MicProductsFetchAllMineController],
  providers: [AppService, MicProductsRegisterService, MicProductsUpdateService, MicProductsArchivateService, MicProductsFetchAllMineService],
})
export class AppModule {}
