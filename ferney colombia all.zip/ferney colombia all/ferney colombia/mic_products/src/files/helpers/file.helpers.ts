import { BadRequestException } from '@nestjs/common';
import { v4 as uuid } from 'uuid';
import { diskStorage } from 'multer';
import { join } from 'path';
import * as fs from 'fs';
export const fileFilter = (req: Express.Request, file: Express.Multer.File, callback: (error: Error, acceptFile: boolean) => void) => {
  if (!file) return callback(new BadRequestException(['Por favor, proporciona un archivo válido']), false);

  const fileExtension = file.mimetype.split('/')[1];
  const validExtensions = ['jpg', 'jpeg', 'png', 'gif'];

  if (validExtensions.includes(fileExtension)) return callback(null, true);

  return callback(new BadRequestException('Asegúrate de que esto sea una imagen de tipo jpg, jpeg, png o gif'), false);
};

export const fileNamer = (req: Express.Request, file: Express.Multer.File, callback: (error: Error | null, fileName: string) => void) => {
  if (!file) return callback(new BadRequestException(['Por favor, proporciona un archivo válido']), '');

  const fileExtension = file.mimetype.split('/')[1];
  const fileName = `${uuid()}.${fileExtension}`;

  callback(null, fileName);
};

// Función para definir el destino dinámico
export const fileDestination = (req, file, cb) => {
  if (!file) return cb(new BadRequestException(['Por favor, proporciona un archivo válido']), '');

  const BusinessID = req.body.BusinessID.trim();

  if (!BusinessID) {
    return cb(new BadRequestException(['Por favor, proporciona el ID del negocio asociado a este producto. Este dato es fundamental.']), '');
  }
  const dir: string = join(__dirname, `../../../public/images/companies/${BusinessID}`);

  // Verifica si el directorio existe, si no lo crea
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }

  cb(null, dir);
};

// Configuración del almacenamiento de archivos usando diskStorage
export const storageConfig = diskStorage({
  destination: fileDestination,
  filename: (req, file, cb) => {
    const uniqueSuffix = uuid();
    const fileName = `${uniqueSuffix}-${file.originalname}`;
    cb(null, fileName);
  },
});
