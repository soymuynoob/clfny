interface Image {
  Fieldname: string;
  Originalname: string;
  Encoding: string;
  Mimetype: string;
  Destination: string;
  Filename: string;
  Path: string;
  Size: number;
  State: boolean;
}

export interface Images extends Array<Image> {}

// verificar el array de prices
export interface Price {
  SellPrice: number;
  Profit: number;
  Margin: number;
}
