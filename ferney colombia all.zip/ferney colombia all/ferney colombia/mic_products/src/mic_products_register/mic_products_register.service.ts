import { BadRequestException, HttpException, HttpStatus, Injectable, InternalServerErrorException } from '@nestjs/common';
import { CreateMicProductDto } from './dto/create-mic_product.dto';
import { Model } from 'mongoose';
import { Products } from '../entities/mic_product.entity';
import { InjectModel } from '@nestjs/mongoose';
import { verifyPrices } from './middlewares/functions.services.middewares';
import { promises as fs } from 'fs';
import * as path from 'path';

@Injectable()
export class MicProductsRegisterService {
  constructor(@InjectModel(Products.name) private readonly productModel: Model<Products>) {}
  async create(props: CreateMicProductDto, files: Express.Multer.File[]) {
    try {
      const { Cost, BusinessID, Prices } = props;

      // Verificar los precios
      const formattedPrices = verifyPrices({ Prices, Cost });

      // Obtener consecutivo único
      const consecutivo = await this.obtenerConsecutivoUnico(BusinessID.trim());

      const payloadProduct = {
        ...props,
        Consecutive: +consecutivo,
        Cost: +Cost.toFixed(2),
        BusinessID: BusinessID.trim(),
        Prices: formattedPrices,
      };

      // Crear producto en la base de datos sin transacciones
      const product = await this.productModel.create(payloadProduct);

      // Manejar las imágenes
      if (files.length > 0) {
        const Images = [];

        for (const file of files) {
          const oldPath = file.path;
          const newPath = path.join(__dirname, '..', '..', 'public', 'images', 'companies', BusinessID.trim(), product.id.toString(), file.filename);
          Images.push(newPath.replaceAll('\\', '/'));

          // Crear los directorios si no existen y mover las imágenes
          await fs.mkdir(path.dirname(newPath), { recursive: true });
          await fs.rename(oldPath, newPath);
        }

        // Actualizar el producto con las rutas de las imágenes
        await this.productModel.findByIdAndUpdate(product.id.toString(), {
          Images,
        });
      }
      const findProduct = await this.productModel.findById(product.id.toString());

      return {
        message: 'Producto creado exitosamente',
        data: findProduct,
        state: true,
        statusCode: HttpStatus.CREATED,
      };
    } catch (error) {
      if (error instanceof BadRequestException) throw error;

      throw new InternalServerErrorException('Ocurrió un error al crear el producto');
    }
  }

  // Obtener consecutivo único
  async obtenerConsecutivoUnico(BusinessID: string, intentos: number = 0): Promise<number> {
    try {
      if (intentos >= 5) {
        throw new BadRequestException({
          message: `No se pudo obtener un número consecutivo único.`,
          state: false,
          error: 'Bad Request',
          statusCode: HttpStatus.BAD_REQUEST,
        });
      }

      const conteoProductos = await this.productModel.countDocuments({
        BusinessID,
      });
      const posibleConsecutivo = conteoProductos + 1;

      const productoExistente = await this.productModel.findOne({ BusinessID, Consecutive: posibleConsecutivo });
      if (productoExistente) return await this.obtenerConsecutivoUnico(BusinessID, intentos + 1);

      return posibleConsecutivo;
    } catch (error) {
      if (error instanceof BadRequestException) throw error;

      throw new InternalServerErrorException('Ocurrió un error al obtener el consecutivo único');
    }
  }
}
