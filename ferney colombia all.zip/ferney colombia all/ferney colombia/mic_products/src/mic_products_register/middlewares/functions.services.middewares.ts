// Middlewares para las funciones de los servicios

import { BadRequestException, HttpStatus } from '@nestjs/common';
import { PriceDto } from '../dto/create-mic_product.dto';

export function verifyPrices({ Prices, Cost }: { Prices: PriceDto[]; Cost: number }) {
  try {
    const formattedPrices: PriceDto[] = [];
    if (Prices.length === 0) {
      throw new BadRequestException({
        message: ['No se han proporcionado precios para el producto. Debe proporcionar al menos un precio.'],
        state: false,
        error: 'No se han proporcionado precios',
        statusCode: HttpStatus.BAD_REQUEST,
      });
    }

    for (const price of Prices) {
      if (price.SellPrice <= Cost) {
        // El precio de venta no puede ser menor o igual al costo.
        throw new BadRequestException({
          message: ['El precio de venta no puede ser menor o igual al costo.'],
          state: false,
          error: 'Cálculos incorrectos',
          statusCode: HttpStatus.BAD_REQUEST,
        });
      }
      if (!(typeof price.SellPrice === 'number' && price.SellPrice >= 0 && typeof price.Profit === 'number' && price.Profit >= 0 && typeof price.Margin === 'number' && price.Margin >= 0)) {
        throw new BadRequestException({
          message: ['Todos los precios deben ser números válidos y no negativos.'],
          state: false,
          error: 'Cálculos incorrectos',
          statusCode: HttpStatus.BAD_REQUEST,
        });
      }

      // Calculamos la ganancia y el margen
      const calculatedProfit = +(price.SellPrice - Cost).toFixed(2);
      const calculatedMargin = +((calculatedProfit / price.SellPrice) * 100).toFixed(2);

      // Verificamos si los montos de ganancia y margen coinciden con los calculados
      if (calculatedProfit !== price.Profit || calculatedMargin !== price.Margin) {
        throw new BadRequestException({
          message: ['Los montos de ganancia o margen no coinciden con los cálculos esperados.'],
          state: false,
          error: 'Cálculos incorrectos',
          statusCode: HttpStatus.BAD_REQUEST,
        });
      }
      formattedPrices.push({
        SellPrice: parseFloat(price.SellPrice.toFixed(2)), // Redondea a 2 decimales y convierte a número
        Profit: parseFloat(price.Profit.toFixed(2)), // Redondea a 2 decimales y convierte a número
        Margin: parseFloat(price.Margin.toFixed(2)), // Redondea a 2 decimales y convierte a número
      });
    }
    return formattedPrices;
  } catch (error) {
    throw error;
  }
}
