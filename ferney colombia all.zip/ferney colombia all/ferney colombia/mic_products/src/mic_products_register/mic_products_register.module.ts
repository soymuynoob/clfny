import { Module } from '@nestjs/common';
import { MicProductsRegisterService } from './mic_products_register.service';
import { MicProductsRegisterController } from './mic_products_register.controller';
import { MongooseModule } from '@nestjs/mongoose';
import { Products, ProductSchema } from '../entities/mic_product.entity';
import { FilesModule } from '../files/files.module';

@Module({
  imports: [MongooseModule.forFeature([{ name: Products.name, schema: ProductSchema }]), FilesModule],
  controllers: [MicProductsRegisterController],
  providers: [MicProductsRegisterService],
  exports: [MicProductsRegisterService, MongooseModule],
})
export class MicProductsRegisterModule {}
