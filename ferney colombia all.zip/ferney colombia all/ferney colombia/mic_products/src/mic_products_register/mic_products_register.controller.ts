import { Controller, Post, Body, UseInterceptors, UploadedFiles } from '@nestjs/common';
import { MicProductsRegisterService } from './mic_products_register.service';
import { CreateMicProductDto } from './dto/create-mic_product.dto';
import { FilesInterceptor } from '@nestjs/platform-express';
import { fileFilter, storageConfig } from 'src/files/helpers/file.helpers';

@Controller()
export class MicProductsRegisterController {
  constructor(private readonly micProductsRegisterService: MicProductsRegisterService) {}

  @Post('/register/product')
  @UseInterceptors(
    FilesInterceptor('files', undefined, {
      fileFilter: fileFilter,
      storage: storageConfig,
    }),
  )
  create(@UploadedFiles() files: Express.Multer.File[], @Body() props: CreateMicProductDto) {
    return this.micProductsRegisterService.create(props, files);
  }
}
