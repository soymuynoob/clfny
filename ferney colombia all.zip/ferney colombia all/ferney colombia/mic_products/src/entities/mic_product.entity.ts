import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document, ObjectId, Types } from 'mongoose';

@Schema({ timestamps: true, versionKey: false, collection: 'products' })
export class Products extends Document {
  @Prop({ required: true, type: Types.ObjectId, trim: true })
  BusinessID: ObjectId;

  @Prop({ required: true, trim: true })
  Name: string;

  @Prop({ required: true })
  Stock: number;

  @Prop({ required: true, min: 0 })
  Cost: number;

  @Prop({
    type: [
      {
        SellPrice: { type: Number, required: true, min: 0 },
        Profit: { type: Number, required: true, min: 0 },
        Margin: { type: Number, required: true, min: 0, max: 100 },
        _id: false,
      },
    ],
    required: true,
  })
  Prices: Array<{
    SellPrice: number;
    Profit: number;
    Margin: number;
  }>;

  @Prop({ trim: true })
  SkuCode: string;

  @Prop({ trim: true })
  BarCode: string;

  @Prop({ required: true, min: 1 })
  Consecutive: number;

  @Prop({ type: [String] })
  Images: string[];

  @Prop({ required: true, default: false })
  IsArchived: boolean;

  @Prop({ required: true, default: false })
  IsDeleted: boolean;
}
export const ProductSchema = SchemaFactory.createForClass(Products);
