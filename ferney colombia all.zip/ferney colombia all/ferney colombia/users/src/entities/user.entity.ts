import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

@Schema({
  timestamps: true,
  versionKey: false,
  collection: 'users',
})
export class Users extends Document {
  @Prop({ required: true, trim: true })
  Name: string;

  @Prop({ trim: true })
  LastName: string;

  @Prop({ required: true, unique: true })
  Email: string;

  @Prop({ trim: true })
  PhoneNumber: string;

  @Prop({ required: false })
  Password: string;

  @Prop({ required: true })
  AccountCancellation: Date;

  @Prop({ trim: true })
  LastConnection: Date;

  @Prop({ required: true, enum: ['OK', 'BLOCK'], default: 'OK' })
  Status: string;

  @Prop({ required: true })
  IsGoogle: boolean;
}
export const UserSchema = SchemaFactory.createForClass(Users);
