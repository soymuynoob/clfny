import { HttpException, HttpStatus } from '@nestjs/common';

const Origins = [
  {
    name: 'business',
    origin: 'http://localhost:3001',
    paths: [
      { name: 'find_business_by_user', pathname: '/get/business/find/by/user' },
    ],
  },
];
export const GetEndPoint = ({ origin, pathname }: { origin: string; pathname: string }): string => {
  try {
    const getOrigin = Origins.find((route) => route.name === origin) || null;
    if (getOrigin === null) throw new HttpException('Forbidden', HttpStatus.FORBIDDEN);
    const pathOrigin = `${getOrigin.origin}`;

    const getPathname = getOrigin.paths.find((path) => path.name === pathname) || null;
    if (getPathname === null) throw new HttpException('Forbidden', HttpStatus.FORBIDDEN);

    const PathName = `${getPathname.pathname}`;

    return `${pathOrigin}${PathName}`;
  } catch (error) {
    throw error;
  }
};
