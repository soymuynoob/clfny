import { BadRequestException, HttpStatus, Injectable, InternalServerErrorException } from '@nestjs/common';
import { Model } from 'mongoose';
import { Users } from '../entities/user.entity';
import { UserCreationResponse, UserResponse } from './interface/interface';
import { InjectModel } from '@nestjs/mongoose';
import { CreateGoogleUserDto } from './dto/create-user.dto';

@Injectable()
export class UserRegisterGoogleService {
  constructor(@InjectModel(Users.name) private readonly userModel: Model<Users>) {}

  // CREAR USER GOOGLE
  async createGoogleUser(props: CreateGoogleUserDto): Promise<UserCreationResponse> {
    try {
      const { Email } = props;
      // Buscar si el email ya está registrado
      const userResponseExist = await this.userModel.findOne({ Email }).exec();

      if (userResponseExist) {
        throw new BadRequestException({
          message: `El correo electrónico ${Email} ya está registrado en nuestro sistema. Por favor, utilice otro correo o inicie sesión si ya tiene una cuenta.`,
          state: false,
          error: 'Bad Request',
          statusCode: HttpStatus.BAD_REQUEST,
        });
      }

      // Crear nuevo usuario con campos adicionales
      const registrationDate = new Date();
      const cancellationDate = new Date(registrationDate);
      cancellationDate.setDate(registrationDate.getDate() + 15);

      const newUser = new this.userModel({
        ...props,
        Email: (Email.toLowerCase() || '').trim(),
        AccountCancellation: cancellationDate.toISOString(),
        Status: 'OK',
        IsGoogle: true,
      });

      // Guardar y retornar el nuevo usuario
      const savedUser = await newUser.save();

      // Convertir ObjectId a string y retornar el usuario sin contraseña
      const userResponse: UserResponse = {
        ...savedUser.toObject(),
        _id: savedUser._id.toString(),
      };

      return {
        message: `Usuario creado correctamente`,
        data: userResponse,
        state: true,
        statusCode: HttpStatus.CREATED,
      };
    } catch (error) {
      if (error instanceof BadRequestException) throw error;
      throw new InternalServerErrorException('Ocurrió un error al crear el usuario');
    }
  }
}
