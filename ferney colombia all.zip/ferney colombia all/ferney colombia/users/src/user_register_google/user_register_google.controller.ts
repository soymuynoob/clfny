import { Body, Controller, Post } from '@nestjs/common';
import { UserRegisterGoogleService } from './user_register_google.service';
import { CreateGoogleUserDto } from './dto/create-user.dto';

@Controller()
export class UserRegisterGoogleController {
  constructor(private readonly userRegisterGoogleService: UserRegisterGoogleService) {}

  // CREAR USER GOOGLE
  @Post('/register/google/user')
  async createGoogleUser(@Body() props: CreateGoogleUserDto) {
    return this.userRegisterGoogleService.createGoogleUser(props);
  }
}
