// ENDPOINT RESPONSE USER CREATE
export interface UserResponse {
  _id?: string;
  Name: string;
  LastName: string;
  Email: string;
  PhoneNumber?: string;
  AccountCancellation: Date;
  LastConnection: Date;
  Status: string;
  CreatedAt?: Date;
  UpdatedAt?: Date;
}
export interface UserCreationResponse {
  message: string;
  data: UserResponse;
  state: boolean;
  statusCode: number;
}
