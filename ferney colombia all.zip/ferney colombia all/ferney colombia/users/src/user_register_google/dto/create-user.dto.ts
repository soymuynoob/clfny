import { IsString, IsNotEmpty, IsEmail, Matches, IsOptional } from 'class-validator';
import { Transform } from 'class-transformer';

export class CreateGoogleUserDto {
  @Transform(({ value }) => value.trim())
  @IsString({ message: 'El nombre debe ser una cadena de texto válida' })
  @IsNotEmpty({ message: 'Por favor, ingrese un nombre' })
  Name: string;

  @IsOptional()
  @Transform(({ value }) => value.trim())
  @IsString({ message: 'El apellido debe ser una cadena de texto válida' })
  @IsNotEmpty({ message: 'Por favor, ingrese un apellido' })
  LastName: string;

  @Transform(({ value }) => value.trim())
  @IsString({
    message: 'El correo electrónico debe ser una cadena de texto válida',
  })
  @IsNotEmpty({ message: 'Por favor, ingrese un correo electrónico' })
  @IsEmail({}, { message: 'Por favor, ingrese un correo electrónico válido' })
  Email: string;

  @IsOptional()
  @Transform(({ value }) => value.trim())
  @IsString({
    message: 'El número de teléfono debe ser una cadena de texto válida',
  })
  @IsNotEmpty({ message: 'Por favor, ingrese un número de teléfono' })
  @IsString({ message: 'El número de teléfono debe ser una cadena de texto' })
  @Matches(/^[0-9]{10}$/, {
    message: 'El número de teléfono debe contener exactamente 10 dígitos',
  })
  @Transform(({ value }) => value.replace(/^\+/, ''))
  PhoneNumber: string;
}
