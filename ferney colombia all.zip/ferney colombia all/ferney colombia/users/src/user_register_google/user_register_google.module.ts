import { Module } from '@nestjs/common';
import { UserRegisterGoogleService } from './user_register_google.service';
import { UserRegisterGoogleController } from './user_register_google.controller';
import { Users, UserSchema } from '../entities/user.entity';
import { MongooseModule } from '@nestjs/mongoose';
import { ConfigModule } from '@nestjs/config';
@Module({
  imports: [ConfigModule, MongooseModule.forFeature([{ name: Users.name, schema: UserSchema }])],
  controllers: [UserRegisterGoogleController],
  providers: [UserRegisterGoogleService],
  exports: [UserRegisterGoogleService, MongooseModule],
})
export class UserRegisterGoogleModule {}
