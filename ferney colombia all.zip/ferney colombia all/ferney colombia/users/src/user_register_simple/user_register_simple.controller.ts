import { Body, Controller, Post } from '@nestjs/common';
import { UserRegisterSimpleService } from './user_register_simple.service';
import { CreateUserDto } from './dto/create-user.dto';

@Controller()
export class UserRegisterSimpleController {
  constructor(private readonly userRegisterSimpleService: UserRegisterSimpleService) {}

  // CREAR USER
  @Post('/register/user')
  async createUser(@Body() props: CreateUserDto) {
    return this.userRegisterSimpleService.createUser(props);
  }
}
