import { Module } from '@nestjs/common';
import { UserRegisterSimpleService } from './user_register_simple.service';
import { UserRegisterSimpleController } from './user_register_simple.controller';
import { Users, UserSchema } from '../entities/user.entity';
import { MongooseModule } from '@nestjs/mongoose';
import { ConfigModule } from '@nestjs/config';
@Module({
  imports: [ConfigModule, MongooseModule.forFeature([{ name: Users.name, schema: UserSchema }])],
  controllers: [UserRegisterSimpleController],
  providers: [UserRegisterSimpleService],
  exports: [UserRegisterSimpleService, MongooseModule],
})
export class UserRegisterSimpleModule {}
