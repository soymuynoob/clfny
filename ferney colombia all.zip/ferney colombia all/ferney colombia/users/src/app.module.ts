import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { MongooseModule } from '@nestjs/mongoose';
import { UserFindModule } from './user_find/user_find.module';
import { UserFindService } from './user_find/user_find.service';
import { UserRegisterSimpleService } from './user_register_simple/user_register_simple.service';
import { UserRegisterGoogleService } from './user_register_google/user_register_google.service';
import { UserRegisterSimpleModule } from './user_register_simple/user_register_simple.module';
import { UserRegisterGoogleModule } from './user_register_google/user_register_google.module';
import { UserFindController } from './user_find/user_find.controller';
import { UserRegisterSimpleController } from './user_register_simple/user_register_simple.controller';
import { UserRegisterGoogleController } from './user_register_google/user_register_google.controller';

@Module({
  imports: [
    MongooseModule.forRoot(
      'mongodb://root:kike123@localhost:27027/users_db?authSource=admin',
    ),
    UserRegisterSimpleModule,
    UserRegisterGoogleModule,
    UserFindModule,
  ],
  controllers: [
    AppController,
    UserFindController,
    UserRegisterSimpleController,
    UserRegisterGoogleController,
  ],
  providers: [
    AppService,
    UserFindService,
    UserRegisterSimpleService,
    UserRegisterGoogleService,
  ],
})
export class AppModule {}
