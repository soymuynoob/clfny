// ENDPOINT RESPONSE USER BY EMAIL
export interface UserResponseByEmail {
  _id: string;
  email: string;
  password: string;
  blocked: boolean;
  message: string;
  state: boolean;
  isGoogle: boolean;
}
export interface UserResponseByEmailNotFound {
  state: boolean;
  message: string;
}

export interface UserWithBusiness {
  businessId: string;
  userEmail: string;
  userName: string;
  userLastName: string;
  userId: string;
}
