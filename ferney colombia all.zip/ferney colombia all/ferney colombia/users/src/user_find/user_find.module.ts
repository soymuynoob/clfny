import { Module } from '@nestjs/common';
import { UserFindService } from './user_find.service';
import { UserFindController } from './user_find.controller';
import { Users, UserSchema } from '../entities/user.entity';
import { MongooseModule } from '@nestjs/mongoose';
import { ConfigModule } from '@nestjs/config';
@Module({
  imports: [ConfigModule, MongooseModule.forFeature([{ name: Users.name, schema: UserSchema }])],
  controllers: [UserFindController],
  providers: [UserFindService],
  exports: [UserFindService, MongooseModule],
})
export class UserFindModule {}
