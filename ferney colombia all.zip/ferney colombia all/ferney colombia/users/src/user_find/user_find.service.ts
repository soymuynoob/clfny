import { BadRequestException, HttpStatus, Injectable, InternalServerErrorException } from '@nestjs/common';
import { Model } from 'mongoose';
import { Users } from '../entities/user.entity';
import { UserResponseByEmail, UserResponseByEmailNotFound, UserWithBusiness } from './interface/interface';
import { InjectModel } from '@nestjs/mongoose';
import { FindUserByEmailDto } from './dto/find-user.dto';
import { GetEndPoint } from '../utils/enpoints';
import axios from 'axios';

@Injectable()
export class UserFindService {
  constructor(@InjectModel(Users.name) private readonly userModel: Model<Users>) {}

  // BUSCAR USUARIO POR EMAIL
  async getUserByEmail(props: FindUserByEmailDto): Promise<UserResponseByEmail | UserResponseByEmailNotFound> {
    try {
      const { Email } = props;

      const user = await this.userModel.findOne({ Email }, '_id Email Password Status IsGoogle').exec();

      if (!user) return { state: false, message: 'Usuario no encontrado' };

      return {
        _id: user._id.toString(),
        email: user.Email,
        password: user.Password,
        blocked: user.Status === 'BLOCK',
        message: user.Status === 'BLOCK' ? 'Acceso denegado: cuenta bloqueada' : 'Usuario encontrado con éxito',
        state: true,
        isGoogle: user.IsGoogle || false,
      };
    } catch (error) {
      if (error instanceof BadRequestException) throw error;

      throw new InternalServerErrorException('Ocurrió un error al buscar el usuario');
    }
  }

  // Obtener usuario y negocio
  async getUserAndBusiness({ userId }: { userId: string }): Promise<UserWithBusiness> {
    try {
      // Buscar el usuario
      const user = await this.userModel.findOne({ _id: userId }, 'Email Name LastName');

      if (!user) throw new BadRequestException({ message: 'Usuario no encontrado', state: false, statusCode: HttpStatus.NOT_FOUND });

      // Buscar el negocio del usuario
      const url = GetEndPoint({ origin: 'business', pathname: 'find_business_by_user' });

      const business = await axios.get(`${url}/${userId}`);

      // Crear el objeto con el usuario y su negocio
      const userWithBusiness = {
        userEmail: user.Email,
        userName: user.Name,
        userLastName: user.LastName,
        userId: user._id,
        businessId: business.data.data._id,
      } as UserWithBusiness;

      return userWithBusiness;
    } catch (error) {
      if (error instanceof BadRequestException) throw error;

      if (error.response.data.statusCode === 400) throw new BadRequestException(Array.isArray(error.response.data.message) ? error.response.data.message[0] : error.response.data.message);

      throw new InternalServerErrorException('Ocurrió un error al buscar el usuario y su negocio');
    }
  }
}
