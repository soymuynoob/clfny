import { Controller, Get, Param, Query } from '@nestjs/common';
import { FindUserByEmailDto, UserAndBusinessFindByUserDto } from './dto/find-user.dto';
import { UserResponseByEmail, UserResponseByEmailNotFound, UserWithBusiness } from './interface/interface';
import { UserFindService } from './user_find.service';

@Controller()
export class UserFindController {
  constructor(private readonly userFindService: UserFindService) {}

  // BUSCAR USUARIO POR EMAIL
  @Get('/get/user/by/email')
  async getUserByEmail(@Query() props: FindUserByEmailDto): Promise<UserResponseByEmail | UserResponseByEmailNotFound> {
    return this.userFindService.getUserByEmail(props);
  }

  // OBTENER USUARIO Y NEGOCIO
  @Get('/get/user/and/business/:userId')
  async getUserAndBusiness(@Param() props: UserAndBusinessFindByUserDto): Promise<UserWithBusiness> {
    return this.userFindService.getUserAndBusiness({ userId: props.userId });
  }
}
